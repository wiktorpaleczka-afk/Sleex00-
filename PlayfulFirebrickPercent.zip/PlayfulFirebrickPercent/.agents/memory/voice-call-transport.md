---
name: Voice-call transport
description: Privacy and reliability constraints for Sleex audio calls.
---

Sleex voice calls send audio peer-to-peer with WebRTC. The application server only carries authenticated signaling, and audio must not be recorded or persisted.

**Why:** This preserves the agreed privacy model. The current STUN-only setup can fail on restrictive networks, so it must not be presented as universally reliable.

**How to apply:** Keep call history limited to status events and timestamps. Add a TURN service and credentials before claiming reliable connectivity across all customer networks.