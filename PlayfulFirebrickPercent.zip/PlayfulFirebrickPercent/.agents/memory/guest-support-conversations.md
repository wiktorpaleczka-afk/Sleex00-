---
name: Guest support conversations
description: Why support tickets can be continued before a customer completes OTP login.
---

New support requests are allowed to continue in chat without requiring an account session; access is granted through a short-lived, httpOnly browser capability cookie tied to the ticket.

**Why:** The support form is intentionally available to visitors, while OTP login remains the separate identity-verification flow. Requiring an authenticated session immediately after submitting the form would make the promised “write to administration” experience fail for guests.

**How to apply:** Preserve the ticket capability check when changing support read/send routes or frontend ticket selection. Do not expose the raw capability value in API responses.