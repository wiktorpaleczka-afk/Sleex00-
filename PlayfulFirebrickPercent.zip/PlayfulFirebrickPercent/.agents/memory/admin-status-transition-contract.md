---
name: Admin status transition contract
description: Keeps admin action names separate from persisted order statuses and notification types.
---

Admin action identifiers are not always valid persisted statuses: the claim action must map to `claimed` before writing the order, event, notification, outbox payload, or API response.

**Why:** Treating a UI action name as the database status can make the response schema reject the result and terminate the API process after a successful-looking click.

**How to apply:** When adding or changing an admin order transition, define the target status once and use it consistently for storage, event history, notifications, Discord logs, and response validation.