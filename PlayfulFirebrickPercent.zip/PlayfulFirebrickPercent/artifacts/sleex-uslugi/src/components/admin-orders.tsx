import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { 
  useListAdminOrders, useClaimOrder, useRejectOrder, useStartOrder, 
  useCompleteOrder, useScheduleCall, getListAdminOrdersQueryKey,
  useGetAdminOrder, getGetAdminOrderQueryKey,
  type Order
} from '@workspace/api-client-react';
import { SkeletonBlock, EmptyState, ErrorNotice } from '@/components/app-shell';
import { formatDate, formatPrice } from '@/components/service-visual';
import { Search, Package, PhoneCall, Calendar, ChevronDown, ChevronUp, Paperclip } from 'lucide-react';

export default function AdminOrders() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  
  const queryClient = useQueryClient();
  const { data: orders, isLoading, isError } = useListAdminOrders(
    { ...(search ? { search } : {}), ...(statusFilter ? { status: statusFilter } : {}) }, 
    { query: { queryKey: getListAdminOrdersQueryKey({ search: search || undefined, status: statusFilter || undefined }) } }
  );

  const [expandedOrderId, setExpandedOrderId] = useState<number | null>(null);
  
  const adminOrderQuery = useGetAdminOrder(expandedOrderId!, {
    query: {
      enabled: !!expandedOrderId,
      queryKey: getGetAdminOrderQueryKey(expandedOrderId!)
    }
  });

  const claimOrder = useClaimOrder();
  const startOrder = useStartOrder();
  const completeOrder = useCompleteOrder();
  const [actionError, setActionError] = useState<{ id: number, message: string } | null>(null);

  const parseError = (err: any) => {
    if (err?.error) return err.error;
    if (err?.message) return err.message;
    return 'Wystąpił błąd. Spróbuj ponownie.';
  };

  const handleAction = (mutation: any, orderId: number) => {
    setActionError(null);
    mutation.mutate({ orderId }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() }),
      onError: (err: any) => {
        if (err?.status === 409 || err?.status === 404) {
          queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        }
        setActionError({ id: orderId, message: parseError(err) });
      }
    });
  };

  const [rejectId, setRejectId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectError, setRejectError] = useState('');
  const rejectMutation = useRejectOrder();
  
  const submitReject = () => {
    if (!rejectId || !rejectReason.trim()) return;
    setRejectError('');
    rejectMutation.mutate({ orderId: rejectId, data: { reason: rejectReason } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        setRejectId(null);
        setRejectReason('');
      },
      onError: (err: any) => {
        if (err?.status === 409) queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        setRejectError(parseError(err));
      }
    });
  };

  const [scheduleId, setScheduleId] = useState<number | null>(null);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleError, setScheduleError] = useState('');
  const scheduleMutation = useScheduleCall();

  const submitSchedule = () => {
    if (!scheduleId || !scheduleDate) return;
    setScheduleError('');
    scheduleMutation.mutate({ data: { orderId: scheduleId, scheduledAt: new Date(scheduleDate).toISOString() } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        setScheduleId(null);
        setScheduleDate('');
      },
      onError: (err: any) => {
        if (err?.status === 409) queryClient.invalidateQueries({ queryKey: getListAdminOrdersQueryKey() });
        setScheduleError(parseError(err));
      }
    });
  };

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">Panel operacyjny</p>
          <h2 className="display text-2xl font-semibold text-white">Kolejka zamówień</h2>
        </div>
      </div>
      
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
          <input 
            type="text" 
            placeholder="Szukaj po e-mail, ID..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-slate-800 bg-slate-900 py-3 pl-11 pr-4 text-sm text-white outline-none transition focus:border-cyan-500" 
          />
        </div>
        <select 
          value={statusFilter} 
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-xl border border-slate-800 bg-slate-900 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-500 min-w-[200px]"
        >
          <option value="">Wszystkie statusy</option>
          <option value="new">Nowe</option>
          <option value="claimed">Przypisane</option>
          <option value="in_progress">W realizacji</option>
          <option value="completed">Zakończone</option>
          <option value="rejected">Odrzucone</option>
        </select>
      </div>

      {isLoading ? (
        <div className="grid gap-3"><SkeletonBlock className="h-32" /><SkeletonBlock className="h-32" /></div>
      ) : isError ? (
        <ErrorNotice message="Nie udało się pobrać listy zamówień." />
      ) : orders?.length ? (
        <div className="grid gap-4">
          {orders.map(order => (
            <div key={order.id} className="rounded-2xl border border-slate-800 bg-slate-900 p-6 flex flex-col gap-4">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-white text-lg">{order.serviceName}</h3>
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase border ${order.status === 'completed' ? 'border-emerald-900/50 bg-emerald-950/40 text-emerald-400' : order.status === 'rejected' ? 'border-red-900/50 bg-red-950/40 text-red-400' : order.status === 'in_progress' ? 'border-cyan-900/50 bg-cyan-950/40 text-cyan-400' : order.status === 'claimed' ? 'border-indigo-900/50 bg-indigo-950/40 text-indigo-400' : 'border-amber-900/50 bg-amber-950/40 text-amber-400'}`}>
                      {order.status}
                    </span>
                  </div>
                  
                  <div className="flex flex-wrap gap-4 text-sm text-slate-400 mb-4">
                    <span>ID: <strong className="text-white font-mono">{order.id}</strong></span>
                    <span>Śledzenie: <strong className="text-white font-mono">{order.trackingId}</strong></span>
                    <span>Klient: <strong className="text-white">{order.email}</strong> / {order.customerPhone}</span>
                    <span>Utworzono: <strong className="text-white">{formatDate(order.createdAt)}</strong></span>
                  </div>
                  
                  <div className="grid gap-3 sm:grid-cols-2 text-sm bg-slate-950/50 p-4 rounded-xl border border-slate-800">
                    <div><span className="text-slate-500">Płatność:</span> <span className="text-slate-300 font-bold">{order.paymentMethod}</span></div>
                    <div><span className="text-slate-500">Sprzęt:</span> <span className="text-slate-300">{order.ramGb} GB RAM, {order.laptopAgeYears} lat</span></div>
                    {order.promoCode && <div className="sm:col-span-2"><span className="text-slate-500">Promocja:</span> <span className="text-fuchsia-400 font-bold">{order.promoCode}</span></div>}
                  </div>
                </div>

                <div className="flex flex-wrap items-start gap-2 lg:flex-col lg:items-end">
                  <div className="text-lg font-bold text-white mb-2">{formatPrice(order.finalPricePln)}</div>
                  
                  {order.status === 'new' && (
                    <>
                      <button onClick={() => handleAction(claimOrder, order.id)} disabled={claimOrder.isPending} className="rounded-xl gradient-ink px-4 py-2.5 text-sm font-bold text-white transition hover:-translate-y-0.5">Przejmij</button>
                      <button onClick={() => setRejectId(order.id)} className="rounded-xl border border-red-900/50 bg-red-950/20 px-4 py-2.5 text-sm font-bold text-red-400 transition hover:bg-red-950/40">Odrzuć</button>
                    </>
                  )}
                  {order.status === 'claimed' && (
                    <>
                      <button onClick={() => handleAction(startOrder, order.id)} disabled={startOrder.isPending} className="rounded-xl border border-cyan-500 bg-cyan-950/30 px-4 py-2.5 text-sm font-bold text-cyan-400 transition hover:bg-cyan-900/50">Rozpocznij realizację</button>
                      <button onClick={() => setScheduleId(order.id)} className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-bold text-slate-300 transition hover:text-white"><Calendar size={16} /> Zaplanuj rozmowę</button>
                    </>
                  )}
                  {order.status === 'in_progress' && (
                    <>
                      <button onClick={() => handleAction(completeOrder, order.id)} disabled={completeOrder.isPending} className="rounded-xl border border-emerald-500 bg-emerald-950/30 px-4 py-2.5 text-sm font-bold text-emerald-400 transition hover:bg-emerald-900/50">Zakończ pomyślnie</button>
                    </>
                  )}
                  
                  <button onClick={() => setExpandedOrderId(expandedOrderId === order.id ? null : order.id)} data-testid={`button-order-details-${order.id}`} className="mt-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-cyan-400 transition">
                    Szczegóły {expandedOrderId === order.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </button>
                  {actionError?.id === order.id && (
                    <div className="mt-2 text-xs text-red-400 bg-red-950/40 border border-red-900/50 px-3 py-2 rounded-lg flex items-center justify-between w-full">
                      <span>{actionError.message}</span>
                      <button onClick={() => setActionError(null)} className="text-red-300 hover:text-white ml-2">✕</button>
                    </div>
                  )}
                </div>
              </div>

              {expandedOrderId === order.id && (
                <div className="mt-4 border-t border-slate-800 pt-6 bg-slate-950/30 -mx-6 -mb-6 p-6 rounded-b-2xl">
                  {adminOrderQuery.isLoading ? (
                    <SkeletonBlock className="h-40" />
                  ) : adminOrderQuery.isError ? (
                    <ErrorNotice message="Nie udało się pobrać szczegółów zamówienia." />
                  ) : adminOrderQuery.data && (
                    <div className="space-y-6">
                      <div className="grid gap-4 sm:grid-cols-2 text-sm">
                        <div className="sm:col-span-2"><span className="text-slate-500 block mb-1">Opis usterki:</span> <p className="text-slate-200 bg-slate-800/50 p-3 rounded-lg border border-slate-800 leading-relaxed whitespace-pre-wrap">{adminOrderQuery.data.damageDescription}</p></div>
                        <div className="sm:col-span-2"><span className="text-slate-500 block mb-1">Okoliczności i kontekst:</span> <p className="text-slate-200 bg-slate-800/50 p-3 rounded-lg border border-slate-800 leading-relaxed whitespace-pre-wrap">{adminOrderQuery.data.incidentDescription}</p></div>
                        
                        {adminOrderQuery.data.attachments && adminOrderQuery.data.attachments.length > 0 && (
                          <div className="sm:col-span-2">
                            <span className="text-slate-500 block mb-2">Załączniki:</span>
                            <div className="grid gap-2 sm:grid-cols-2">
                              {adminOrderQuery.data.attachments.map(att => (
                                <a key={att.id} href={att.downloadUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 p-3 rounded-lg border border-slate-700 bg-slate-800/50 hover:bg-slate-800 transition">
                                  <Paperclip size={16} className="text-cyan-500" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-white truncate">{att.filename}</p>
                                    <p className="text-xs text-slate-400">{(att.size / 1024 / 1024).toFixed(2)} MB</p>
                                  </div>
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {adminOrderQuery.data.events && adminOrderQuery.data.events.length > 0 && (
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">Oś czasu operacji</h4>
                          <div className="relative border-l border-slate-800 ml-2 space-y-4">
                            {adminOrderQuery.data.events.map((ev: any) => (
                              <div key={ev.id} className="relative pl-5">
                                <span className="absolute -left-[5px] top-1.5 h-2 w-2 rounded-full bg-cyan-500 ring-4 ring-slate-900" />
                                <p className="text-sm font-bold text-white">{ev.type}</p>
                                <p className="text-xs text-slate-400 mt-0.5">{formatDate(ev.createdAt)} {ev.actorUserId ? `(ID Aktora: ${ev.actorUserId})` : ''}</p>
                                {ev.note && <p className="mt-2 text-xs text-slate-300 bg-slate-800/50 p-2 rounded border border-slate-800">{ev.note}</p>}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="Brak zamówień" body="Nie ma zamówień pasujących do Twoich kryteriów." />
      )}

      {rejectId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="display text-xl font-semibold text-white mb-2">Odrzuć zamówienie</h3>
            <p className="text-sm text-slate-400 mb-4">Podaj powód odrzucenia (będzie widoczny dla klienta).</p>
            <textarea 
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Powód odrzucenia..."
              className="min-h-24 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-500"
            />
            {rejectError && <p className="mt-3 text-sm text-red-400">{rejectError}</p>}
            <div className="mt-5 flex gap-3">
              <button onClick={() => setRejectId(null)} className="flex-1 rounded-xl border border-slate-700 bg-transparent px-4 py-2.5 text-sm font-bold text-slate-300 hover:bg-slate-800">Anuluj</button>
              <button onClick={submitReject} disabled={!rejectReason.trim() || rejectMutation.isPending} className="flex-1 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-red-500 disabled:opacity-50">Odrzuć</button>
            </div>
          </div>
        </div>
      )}

      {scheduleId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="display text-xl font-semibold text-white mb-2">Zaplanuj rozmowę</h3>
            <p className="text-sm text-slate-400 mb-4">Ustal termin rozmowy technicznej z klientem. Otrzyma on powiadomienie e-mail.</p>
            <input 
              type="datetime-local" 
              value={scheduleDate}
              onChange={(e) => setScheduleDate(e.target.value)}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-500"
            />
            {scheduleError && <p className="mt-3 text-sm text-red-400">{scheduleError}</p>}
            <div className="mt-5 flex gap-3">
              <button onClick={() => setScheduleId(null)} className="flex-1 rounded-xl border border-slate-700 bg-transparent px-4 py-2.5 text-sm font-bold text-slate-300 hover:bg-slate-800">Anuluj</button>
              <button onClick={submitSchedule} disabled={!scheduleDate || scheduleMutation.isPending} className="flex-1 rounded-xl gradient-ink px-4 py-2.5 text-sm font-bold text-white hover:-translate-y-0.5 disabled:opacity-50">Zapisz termin</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}