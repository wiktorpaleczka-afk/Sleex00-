import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { 
  useListAdminCalls, useStartCall, useEndCall, useCancelCall, getListAdminCallsQueryKey
} from '@workspace/api-client-react';
import { SkeletonBlock, EmptyState, ErrorNotice } from '@/components/app-shell';
import { formatDate } from '@/components/service-visual';
import { PhoneCall, PhoneOff, PlayCircle, Calendar, Play } from 'lucide-react';
import CallRoom from '@/components/call-room';

export default function AdminCalls() {
  const queryClient = useQueryClient();
  const { data: calls, isLoading, isError } = useListAdminCalls({ 
    query: { refetchInterval: 10000, queryKey: getListAdminCallsQueryKey() }
  });

  const [activeCallId, setActiveCallId] = useState<number | null>(null);
  const startCall = useStartCall();
  const endCall = useEndCall();
  const cancelCall = useCancelCall();
  const [actionError, setActionError] = useState<{ id: number, message: string } | null>(null);

  const parseError = (err: any) => {
    if (err?.error) return err.error;
    if (err?.message) return err.message;
    return 'Wystąpił błąd.';
  };

  const handleStart = (callId: number) => {
    setActionError(null);
    startCall.mutate({ callId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() });
        setActiveCallId(callId);
      },
      onError: (err: any) => {
        if (err?.status === 409 || err?.status === 404) queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() });
        setActionError({ id: callId, message: parseError(err) });
      }
    });
  };

  const handleCancel = (callId: number) => {
    if (!window.confirm('Na pewno anulować tę rozmowę?')) return;
    setActionError(null);
    cancelCall.mutate({ callId }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() }),
      onError: (err: any) => {
        if (err?.status === 409 || err?.status === 404) queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() });
        setActionError({ id: callId, message: parseError(err) });
      }
    });
  };
  
  const handleEnd = (callId: number) => {
    if (!window.confirm('Zakończyć trwającą rozmowę?')) return;
    setActionError(null);
    endCall.mutate({ callId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() });
        if (activeCallId === callId) setActiveCallId(null);
      },
      onError: (err: any) => {
        if (err?.status === 409 || err?.status === 404) queryClient.invalidateQueries({ queryKey: getListAdminCallsQueryKey() });
        setActionError({ id: callId, message: parseError(err) });
      }
    });
  };

  if (activeCallId) {
    return <CallRoom callId={activeCallId} onLeave={() => setActiveCallId(null)} isAdmin={true} />;
  }

  const activeOrWaiting = calls?.filter(c => c.status === 'active' || c.status === 'waiting') || [];
  const scheduled = calls?.filter(c => c.status === 'scheduled') || [];
  const history = calls?.filter(c => c.status === 'ended' || c.status === 'cancelled') || [];

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">Pokoje i harmonogram</p>
          <h2 className="display text-2xl font-semibold text-white">Rozmowy z klientami</h2>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-4"><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /></div>
      ) : isError ? (
        <ErrorNotice message="Nie udało się pobrać listy rozmów." />
      ) : calls?.length ? (
        <div className="space-y-8">
          {activeOrWaiting.length > 0 && (
            <div>
              <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2"><div className="h-2 w-2 bg-cyan-500 rounded-full animate-pulse" /> W toku</h3>
              <div className="grid gap-3">
                {activeOrWaiting.map(call => (
                  <div key={call.id} className="rounded-2xl border border-cyan-900/50 bg-cyan-950/20 p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <p className="font-semibold text-white text-lg">Rozmowa #{call.id} (Zamówienie #{call.orderId})</p>
                      <p className="mt-1 text-sm text-cyan-400/80">Status: {call.status === 'waiting' ? 'Klient czeka w poczekalni' : 'Rozmowa aktywna'}</p>
                      <p className="mt-1 text-xs text-slate-500">Zaplanowano na: {formatDate(call.scheduledAt)}</p>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleEnd(call.id)} 
                        disabled={endCall.isPending}
                        className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm font-bold text-slate-300 hover:text-white transition hover:bg-slate-700"
                      >
                        Zakończ z poziomu systemu
                      </button>
                      <button 
                        onClick={() => setActiveCallId(call.id)}
                        className="rounded-xl bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-400 shadow-lg shadow-cyan-900/30 transition hover:-translate-y-0.5 flex items-center gap-2"
                      >
                        <PhoneCall size={16} /> Otwórz panel audio
                      </button>
                    </div>
                    {actionError?.id === call.id && <p className="mt-2 text-sm text-red-400 w-full text-right">{actionError.message}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {scheduled.length > 0 && (
            <div>
              <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-500">Zaplanowane</h3>
              <div className="grid gap-3">
                {scheduled.map(call => (
                  <div key={call.id} className="rounded-2xl border border-slate-800 bg-slate-900 p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="grid h-12 w-12 place-items-center rounded-xl bg-slate-800 text-slate-400">
                        <Calendar size={20} />
                      </div>
                      <div>
                        <p className="font-semibold text-white">Rozmowa #{call.id} (Zamówienie #{call.orderId})</p>
                        <p className="mt-1 text-sm text-slate-400">{formatDate(call.scheduledAt)}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleCancel(call.id)} 
                        disabled={cancelCall.isPending}
                        className="rounded-xl border border-red-900/50 bg-red-950/20 px-4 py-2.5 text-sm font-bold text-red-400 hover:bg-red-950/40 transition"
                      >
                        Anuluj
                      </button>
                      <button 
                        onClick={() => handleStart(call.id)}
                        disabled={startCall.isPending}
                        className="rounded-xl border border-cyan-500 bg-cyan-950/30 px-4 py-2.5 text-sm font-bold text-cyan-400 hover:bg-cyan-900/50 transition flex items-center gap-2"
                      >
                        <Play size={16} /> Rozpocznij teraz
                      </button>
                    </div>
                    {actionError?.id === call.id && <p className="mt-2 text-sm text-red-400 w-full text-right">{actionError.message}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {history.length > 0 && (
            <div>
              <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-500">Historia</h3>
              <div className="grid gap-3">
                {history.map(call => (
                  <div key={call.id} className="flex items-center justify-between rounded-xl border border-slate-800/50 bg-slate-900/30 p-4">
                    <div>
                      <p className="font-medium text-slate-300">Rozmowa #{call.id} (Zamówienie #{call.orderId})</p>
                      <p className="mt-1 text-xs text-slate-500">{formatDate(call.scheduledAt)} {call.startedAt && ` — rozpoczęto: ${formatDate(call.startedAt)}`}</p>
                    </div>
                    <span className={`text-xs font-bold uppercase ${call.status === 'ended' ? 'text-emerald-500' : 'text-slate-500'}`}>
                      {call.status === 'ended' ? 'Zakończona' : 'Anulowana'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <EmptyState title="Brak rozmów" body="Harmonogram jest pusty." />
      )}
    </section>
  );
}