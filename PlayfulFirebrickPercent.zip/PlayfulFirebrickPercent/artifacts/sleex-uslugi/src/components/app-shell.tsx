import { useState, useRef, useEffect, type ReactNode } from 'react';
import { Link, useLocation } from 'wouter';
import { LogOut, Menu, MessageCircle, Package, ShieldCheck, Sparkles, X, Bell, BellOff, Check, AlertTriangle, Info, BellRing } from 'lucide-react';
import { useGetSession, useLogout, useListNotifications, useMarkNotificationRead, getListNotificationsQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { formatDate } from '@/components/service-visual';

let notificationAudioContext: AudioContext | null = null;

function unlockNotificationAudio() {
  const AudioContextConstructor = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextConstructor) return;
  notificationAudioContext ??= new AudioContextConstructor();
  if (notificationAudioContext.state === 'suspended') {
    void notificationAudioContext.resume();
  }
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" data-testid="link-home-logo" className="flex items-center gap-3">
      <span className="grid h-10 w-10 place-items-center rounded-xl gradient-ink text-white shadow-lg shadow-cyan-900/20">
        <Sparkles size={19} strokeWidth={2.5} />
      </span>
      {!compact && <span className="display text-lg font-semibold tracking-tight text-white">sleex<span className="text-cyan-400">.</span></span>}
    </Link>
  );
}

function playNotificationSound() {
  try {
    const ctx = notificationAudioContext;
    if (!ctx || ctx.state !== 'running') return;
    const osc = ctx.createOscillator();
    const gainNode = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.1);
    gainNode.gain.setValueAtTime(0, ctx.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
    osc.connect(gainNode);
    gainNode.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  } catch {
    // Audio is an enhancement; browser restrictions must not disrupt notifications.
  }
}

function NotificationBell({ authenticated }: { authenticated: boolean }) {
  const [open, setOpen] = useState(false);
  const [muted, setMuted] = useState(() => localStorage.getItem('sleex_mute') === '1');
  const queryClient = useQueryClient();
  const { data: notifications } = useListNotifications({
    query: {
      enabled: authenticated,
      queryKey: getListNotificationsQueryKey(),
      refetchInterval: 15000
    }
  });
  const markRead = useMarkNotificationRead();
  const unread = notifications?.filter(n => !n.readAt) || [];
  const lastUnreadIds = useRef<Set<number> | null>(null);

  useEffect(() => {
    if (!notifications) return;
    const currentUnreadIds = new Set(unread.map(n => n.id));
    const savedIds = new Set<number>(
      JSON.parse(localStorage.getItem('sleex_seen_notification_ids') ?? '[]') as number[],
    );
    if (lastUnreadIds.current === null) {
      lastUnreadIds.current = currentUnreadIds;
      const initialSeen = [...new Set([...savedIds, ...currentUnreadIds])].slice(-100);
      localStorage.setItem('sleex_seen_notification_ids', JSON.stringify(initialSeen));
      return;
    }
    const newAudible = unread.some(
      n => n.audible && !lastUnreadIds.current?.has(n.id) && !savedIds.has(n.id),
    );
    if (newAudible && !muted) {
      playNotificationSound();
    }
    lastUnreadIds.current = currentUnreadIds;
    const updatedSeen = [...new Set([...savedIds, ...currentUnreadIds])].slice(-100);
    localStorage.setItem('sleex_seen_notification_ids', JSON.stringify(updatedSeen));
  }, [notifications, muted, unread]);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    localStorage.setItem('sleex_mute', next ? '1' : '0');
  };

  const handleMarkRead = (id: number) => {
    markRead.mutate({ notificationId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
      }
    });
  };

  if (!authenticated) return null;

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} data-testid="button-notifications" className="relative grid h-10 w-10 place-items-center rounded-xl border border-slate-800 bg-slate-900 text-slate-300 transition hover:border-slate-700 hover:text-white">
        <Bell size={18} />
        {unread.length > 0 && <span className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full border-2 border-[#030712] bg-cyan-500 text-[10px] font-bold text-white">{unread.length}</span>}
      </button>
      {open && (
        <div className="absolute -right-12 top-full z-50 mt-2 w-[calc(100vw-2.5rem)] max-w-[320px] overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 shadow-xl sm:right-0 sm:max-w-[384px]">
          <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/50 px-4 py-3">
            <h3 className="text-sm font-semibold text-white">Powiadomienia</h3>
            <button onClick={toggleMute} data-testid="button-toggle-mute" className="text-slate-400 transition hover:text-white" title={muted ? 'Włącz dźwięki' : 'Wycisz dźwięki'}>
              {muted ? <BellOff size={16} /> : <BellRing size={16} />}
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto p-2">
            {!notifications?.length ? (
              <p className="p-6 text-center text-sm text-slate-500">Brak nowych powiadomień.</p>
            ) : (
              notifications.map((note) => (
                <div key={note.id} data-testid={`notification-${note.id}`} className={`mb-1 flex gap-3 rounded-xl p-3 last:mb-0 ${note.readAt ? 'opacity-60' : 'bg-slate-800/50'}`}>
                  <div className={`mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg border ${note.type === 'ban' ? 'border-red-900/50 bg-red-950/40 text-red-400' : note.type === 'warning' ? 'border-amber-900/50 bg-amber-950/40 text-amber-400' : 'border-cyan-900/50 bg-cyan-950/40 text-cyan-400'}`}>
                    {note.type === 'ban' ? <AlertTriangle size={14} /> : note.type === 'warning' ? <AlertTriangle size={14} /> : <Info size={14} />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{note.title}</p>
                    <p className="mt-1 text-xs text-slate-400">{note.body}</p>
                    <p className="mt-2 text-[10px] text-slate-500">{formatDate(note.createdAt)}</p>
                  </div>
                  {!note.readAt && (
                    <button onClick={() => handleMarkRead(note.id)} disabled={markRead.isPending} data-testid={`button-read-${note.id}`} className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-slate-500 transition hover:bg-slate-800 hover:text-white" title="Oznacz jako przeczytane">
                      <Check size={16} />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const { data: session } = useGetSession();
  const logout = useLogout();
  const close = () => setOpen(false);
  const isBanned = session?.user?.banned === true;

  useEffect(() => {
    const unlock = () => unlockNotificationAudio();
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  const nav = [
    { href: '/', label: 'Katalog usług', icon: Package },
    { href: '/status-zamowienia', label: 'Status zamówienia', icon: ShieldCheck },
    { href: '/help', label: 'Pomoc i kontakt', icon: MessageCircle },
    ...(session?.authenticated ? [{ href: '/account', label: 'Moje zamówienia', icon: ShieldCheck }] : []),
    ...(session?.user?.role === 'admin' ? [{ href: '/admin', label: 'Panel admina', icon: ShieldCheck }] : []),
  ];
  const handleLogout = () => logout.mutate(undefined, { onSuccess: close });

  return (
    <div className="noise min-h-[100dvh] bg-[#030712]">
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#030712]/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 lg:px-8">
          <Logo />
          {!isBanned && (
            <nav className="hidden items-center gap-1 md:flex" aria-label="Główna nawigacja">
              {nav.map(({ href, label }) => (
                <Link key={href} href={href} data-testid={`link-nav-${label}`} className={`rounded-xl px-4 py-2.5 text-sm font-semibold transition ${location === href ? 'bg-slate-800 text-cyan-400 shadow-sm' : 'text-slate-400 hover:bg-slate-800/75 hover:text-white'}`}>
                  {label}
                </Link>
              ))}
            </nav>
          )}
          <div className="hidden items-center gap-3 md:flex">
            {session?.authenticated ? (
              <>
                <NotificationBell authenticated={session.authenticated} />
                <span data-testid="text-session-email" className="max-w-[190px] truncate text-sm text-slate-400">{session.user?.email}</span>
                <button onClick={handleLogout} data-testid="button-logout" className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-3.5 py-2 text-sm font-semibold text-slate-300 transition hover:border-slate-700 hover:text-white">
                  <LogOut size={15} /> Wyloguj
                </button>
              </>
            ) : (
              <Link href="/login" data-testid="link-login-header" className="rounded-xl gradient-ink px-4 py-2.5 text-sm font-semibold text-white shadow-md shadow-cyan-900/20 transition hover:-translate-y-0.5">
                Zaloguj się
              </Link>
            )}
          </div>
          <div className="flex items-center gap-3 md:hidden">
            <NotificationBell authenticated={!!session?.authenticated} />
            <button onClick={() => setOpen(!open)} data-testid="button-mobile-menu" className="rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-slate-300">
              {open ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="border-t border-slate-800 bg-slate-900 px-5 py-4 md:hidden">
            <nav className="grid gap-1">
              {!isBanned && nav.map(({ href, label }) => <Link key={href} href={href} onClick={close} data-testid={`link-mobile-${label}`} className={`rounded-xl px-4 py-3 text-sm font-semibold ${location === href ? 'bg-slate-800 text-cyan-400' : 'text-slate-400'}`}>{label}</Link>)}
              {session?.authenticated ? <button onClick={handleLogout} data-testid="button-mobile-logout" className="flex items-center gap-2 rounded-xl px-4 py-3 text-left text-sm font-semibold text-slate-400"><LogOut size={16} /> Wyloguj się</button> : <Link href="/login" onClick={close} data-testid="link-mobile-login" className="rounded-xl bg-slate-800 px-4 py-3 text-sm font-semibold text-cyan-400">Zaloguj się</Link>}
            </nav>
          </div>
        )}
      </header>
      <main className="relative z-10">
        {isBanned ? (
          <div className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
            <div className="mx-auto max-w-2xl rounded-3xl border border-red-900/50 bg-red-950/20 p-8 text-center sm:p-12">
              <div className="mx-auto mb-6 grid h-16 w-16 place-items-center rounded-full bg-red-950 text-red-500">
                <AlertTriangle size={32} />
              </div>
              <h1 className="display text-3xl font-semibold text-white sm:text-4xl">Zostałeś zbanowany.</h1>
              <p className="mt-4 text-base leading-7 text-slate-400">
                Twoje konto naruszyło regulamin platformy lub zostało ograniczone przez administratora.
                {session.user?.banReason && <span className="mt-4 block rounded-xl border border-red-900/30 bg-red-950/30 p-4 text-sm font-medium text-red-300">Powód: {session.user.banReason}</span>}
              </p>
            </div>
          </div>
        ) : children}
      </main>
      {!isBanned && (
        <footer className="border-t border-slate-800 bg-[#030712] relative z-10">
          <div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-8 text-sm text-slate-400 md:flex-row md:items-center md:justify-between lg:px-8">
            <div className="flex items-center gap-3"><Logo compact /><span>Pomoc, która dowozi wynik.</span></div>
            <div className="flex gap-5"><Link href="/help" data-testid="link-footer-help" className="hover:text-cyan-400 transition">Centrum pomocy</Link><Link href="/login" data-testid="link-footer-login" className="hover:text-cyan-400 transition">Logowanie</Link></div>
          </div>
        </footer>
      )}
    </div>
  );
}

export function PageTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="mb-2 text-xs font-bold uppercase tracking-[.18em] text-cyan-500">{eyebrow}</p><h1 className="display text-4xl font-semibold tracking-tight text-white md:text-5xl">{title}</h1>{description && <p className="mt-3 max-w-2xl text-base leading-7 text-slate-400">{description}</p>}</div>{action}</div>;
}

export function ErrorNotice({ message = 'Nie udało się pobrać danych. Spróbuj ponownie.' }: { message?: string }) {
  return <div data-testid="status-error" className="rounded-2xl border border-red-900/50 bg-red-950/20 px-5 py-4 text-sm font-medium text-red-400">{message}</div>;
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return <div data-testid="state-empty" className="rounded-3xl border border-dashed border-slate-800 bg-slate-900/50 px-6 py-16 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-slate-800 text-cyan-400"><Sparkles size={20} /></div><h3 className="display text-xl font-semibold text-white">{title}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-400">{body}</p>{action}</div>;
}

export function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`pulse-soft rounded-2xl bg-slate-800 ${className}`} aria-label="Ładowanie" data-testid="state-loading" />;
}
