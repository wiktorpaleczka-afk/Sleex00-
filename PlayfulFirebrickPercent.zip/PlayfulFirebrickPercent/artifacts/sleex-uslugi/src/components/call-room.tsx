import { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, PhoneOff, Pause, Play, AlertCircle, PhoneCall, Loader2, User, Video, VideoOff } from 'lucide-react';
import { useGetSession, useJoinAuthorizeCall, useGetCall, getGetCallQueryKey, useEndCall } from '@workspace/api-client-react';

export default function CallRoom({ callId, onLeave, isAdmin = false }: { callId: number; onLeave: () => void; isAdmin?: boolean }) {
  const { data: session } = useGetSession();
  const joinAuth = useJoinAuthorizeCall();
  const endCall = useEndCall();
  const { data: callDetail, error: callError } = useGetCall(callId, { query: { queryKey: getGetCallQueryKey(callId), refetchInterval: 10000 } });
  
  const [error, setError] = useState('');
  const [status, setStatus] = useState<'initializing' | 'waiting' | 'connecting' | 'connected' | 'ended'>('initializing');
  const [muted, setMuted] = useState(false);
  const [hold, setHold] = useState(false);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [remoteMuted, setRemoteMuted] = useState(false);
  const [remoteHold, setRemoteHold] = useState(false);
  const [remoteCameraEnabled, setRemoteCameraEnabled] = useState(false);
  const [remotePresent, setRemotePresent] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  
  const peerRef = useRef<RTCPeerConnection | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const videoSenderRef = useRef<RTCRtpSender | null>(null);
  const needsRenegotiation = useRef(false);

  const renegotiate = async () => {
    if (isAdmin && peerRef.current && peerRef.current.signalingState !== 'closed') {
      try {
        if (peerRef.current.signalingState !== 'stable') {
          needsRenegotiation.current = true;
          return;
        }
        const offer = await peerRef.current.createOffer();
        await peerRef.current.setLocalDescription(offer);
        wsRef.current?.send(JSON.stringify({ type: 'offer', offer }));
      } catch (err) {
        console.error('Renegotiation failed', err);
      }
    }
  };

  useEffect(() => {
    let timer: number;
    if (status === 'connected') {
      timer = window.setInterval(() => setElapsed(e => e + 1), 1000);
    }
    return () => window.clearInterval(timer);
  }, [status]);

  useEffect(() => {
    let mounted = true;
    
    const init = async () => {
      try {
        // Authorize
        const call = await joinAuth.mutateAsync({ callId });
        if (!mounted) return;
        
        if (call.status === 'ended' || call.status === 'cancelled') {
          setStatus('ended');
          return;
        }

        // Get Mic
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        if (!mounted) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }
        streamRef.current = stream;

        // Peer Connection
        const pc = new RTCPeerConnection({
          iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
        });
        peerRef.current = pc;
        let iceQueue: RTCIceCandidateInit[] = [];
        videoSenderRef.current = pc.addTransceiver('video', { direction: 'sendrecv' }).sender;
        
        stream.getTracks().forEach(t => pc.addTrack(t, stream));

        pc.ontrack = (event) => {
          if (event.track.kind === 'audio' && audioRef.current) {
            audioRef.current.srcObject = new MediaStream([event.track]);
          }
          if (event.track.kind === 'video' && remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = new MediaStream([event.track]);
          }
        };

        pc.onsignalingstatechange = () => {
          if (pc.signalingState === 'stable' && needsRenegotiation.current) {
            needsRenegotiation.current = false;
            renegotiate();
          }
        };

        pc.oniceconnectionstatechange = () => {
          if (pc.iceConnectionState === 'connected') setStatus('connected');
          if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') {
            setStatus('waiting');
          }
        };

        // WebSocket
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const ws = new WebSocket(`${protocol}//${window.location.host}/api/calls/ws?callId=${callId}`);
        wsRef.current = ws;

        ws.onopen = () => {
          if (!mounted) return;
          setStatus('waiting');
          ws.send(JSON.stringify({ type: 'join' }));
        };

        ws.onmessage = async (msg) => {
          if (!mounted) return;
          try {
            const data = JSON.parse(msg.data);
            switch (data.type) {
            case 'presence':
              setRemotePresent(data.present);
              if (data.present && isAdmin) {
                // Admin initiates offer when peer is present
                renegotiate();
              }
              break;
            case 'offer':
              if (!isAdmin) {
                await pc.setRemoteDescription(data.offer);
                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);
                ws.send(JSON.stringify({ type: 'answer', answer }));
                iceQueue.forEach(c => pc.addIceCandidate(c).catch(console.error));
                iceQueue = [];
              }
              break;
            case 'answer':
              if (isAdmin) {
                await pc.setRemoteDescription(data.answer);
                iceQueue.forEach(c => pc.addIceCandidate(c).catch(console.error));
                iceQueue = [];
              }
              break;
            case 'ice':
              if (data.candidate) {
                if (pc.remoteDescription) {
                  await pc.addIceCandidate(data.candidate).catch(console.error);
                } else {
                  iceQueue.push(data.candidate);
                }
              }
              break;
            case 'mute':
              setRemoteMuted(data.muted);
              break;
            case 'hold':
              setRemoteHold(data.hold);
              break;
            case 'camera':
              setRemoteCameraEnabled(data.enabled);
              if (isAdmin) renegotiate();
              break;
            case 'end':
              setStatus('ended');
              break;
            }
          } catch (messageError) {
            console.error('Nie udało się obsłużyć sygnału rozmowy', messageError);
          }
        };

        pc.onicecandidate = (event) => {
          if (event.candidate && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ice', candidate: event.candidate }));
          }
        };

      } catch (err: any) {
        if (!mounted) return;
        if (err.name === 'NotAllowedError') {
          setError('Brak uprawnień do mikrofonu. Odblokuj dostęp w ustawieniach przeglądarki.');
        } else {
          setError('Wystąpił błąd podczas łączenia: ' + (err.message || 'Nieznany błąd'));
        }
        setStatus('ended');
      }
    };

    init();

    return () => {
      mounted = false;
      wsRef.current?.close();
      peerRef.current?.close();
      streamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, [callId, isAdmin]); // intentionally missing joinAuth to avoid re-trigger

  const toggleMute = () => {
    if (streamRef.current) {
      const audioTrack = streamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMuted(!audioTrack.enabled);
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(JSON.stringify({ type: 'mute', muted: !audioTrack.enabled }));
        }
      }
    }
  };

  const toggleHold = () => {
    const nextHold = !hold;
    setHold(nextHold);
    
    // Toggle outgoing
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach(t => t.enabled = !nextHold && !muted);
    }
    
    // Toggle incoming
    if (audioRef.current) {
      audioRef.current.muted = nextHold;
    }

    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'hold', hold: nextHold }));
    }
  };

  const toggleCamera = async () => {
    setCameraError('');
    try {
      if (cameraEnabled) {
        const track = streamRef.current?.getVideoTracks()[0];
        if (track) {
          track.stop();
          streamRef.current?.removeTrack(track);
          await videoSenderRef.current?.replaceTrack(null);
        }
        if (localVideoRef.current) localVideoRef.current.srcObject = null;
        setCameraEnabled(false);
        wsRef.current?.send(JSON.stringify({ type: 'camera', enabled: false }));
        if (isAdmin) renegotiate();
      } else {
        const vStream = await navigator.mediaDevices.getUserMedia({ video: true });
        const track = vStream.getVideoTracks()[0];
        if (streamRef.current) {
          streamRef.current.addTrack(track);
          await videoSenderRef.current?.replaceTrack(track);
        }
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = new MediaStream([track]);
        }
        setCameraEnabled(true);
        wsRef.current?.send(JSON.stringify({ type: 'camera', enabled: true }));
        if (isAdmin) renegotiate();
      }
    } catch (err: any) {
      console.error('Camera error:', err);
      setCameraError(err?.name === 'NotAllowedError'
        ? 'Brak dostępu do kamery. Zezwól na kamerę w ustawieniach przeglądarki.'
        : 'Nie udało się uruchomić kamery. Sprawdź, czy urządzenie nie jest używane przez inną aplikację.');
    }
  };

  const handleLeave = () => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'leave' }));
    }
    if (isAdmin && status !== 'ended') {
      endCall.mutate({ callId }, {
        onSettled: () => onLeave()
      });
    } else {
      onLeave();
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60).toString().padStart(2, '0');
    const s = (seconds % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="rounded-3xl border border-slate-800 bg-slate-900 overflow-hidden flex flex-col min-h-[400px]">
      <audio ref={audioRef} autoPlay playsInline className="hidden" />
      
      <div className="border-b border-slate-800 bg-slate-950/50 p-6 flex items-center justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-cyan-500 mb-1">Pokój rozmów</p>
          <h2 className="display text-xl font-semibold text-white">Rozmowa #{callId}</h2>
        </div>
        <div className="flex gap-2 text-sm text-slate-400">
          <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-full border border-slate-800">
            <span className={`h-2 w-2 rounded-full ${status === 'connected' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]' : status === 'waiting' ? 'bg-amber-500' : status === 'ended' ? 'bg-red-500' : 'bg-slate-500'}`} />
            {status === 'initializing' ? 'Inicjalizacja...' : status === 'waiting' ? 'Poczekalnia' : status === 'connecting' ? 'Łączenie...' : status === 'connected' ? 'Połączono' : 'Zakończono'}
          </div>
          {status === 'connected' && (
            <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-full border border-slate-800 font-mono text-cyan-400">
              {formatTime(elapsed)}
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        {error || callError ? (
          <div className="max-w-md text-center">
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-red-950 text-red-500"><AlertCircle size={32} /></div>
            <p className="text-red-400 font-medium">{error || 'Nie masz dostępu do tej rozmowy.'}</p>
          </div>
        ) : status === 'ended' ? (
          <div className="text-center">
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-slate-800 text-slate-400"><PhoneOff size={32} /></div>
            <p className="text-slate-300">Rozmowa została zakończona.</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-8 w-full">
            <div className="flex flex-wrap justify-center gap-6 w-full max-w-5xl">
              <div className="flex flex-col items-center gap-3">
                <div className="relative">
                  <div className={`grid place-items-center bg-slate-800 border-2 border-slate-700 text-slate-400 overflow-hidden transition-all duration-500 ${cameraEnabled ? 'w-64 max-w-full aspect-video rounded-2xl' : 'h-24 w-24 rounded-full'}`}>
                    <User size={40} className={cameraEnabled ? 'hidden' : ''} />
                    <video ref={localVideoRef} autoPlay playsInline muted className={`w-full h-full object-cover ${cameraEnabled ? '' : 'hidden'}`} />
                  </div>
                  {muted && <div className="absolute -bottom-2 -right-2 grid h-8 w-8 place-items-center rounded-full bg-red-950 border border-red-900/50 text-red-500"><MicOff size={14} /></div>}
                </div>
                <span className="text-sm font-semibold text-white">Ty</span>
              </div>
              
              <div className="flex flex-col items-center gap-3">
                <div className="relative">
                  <div className={`grid place-items-center border-2 overflow-hidden transition-all duration-500 ${remotePresent && remoteCameraEnabled ? 'w-64 max-w-full aspect-video rounded-2xl bg-slate-900 border-slate-800' : remotePresent ? 'h-24 w-24 rounded-full bg-cyan-950 border-cyan-800 text-cyan-400' : 'h-24 w-24 rounded-full bg-slate-800 border-slate-700 text-slate-500'}`}>
                    {remotePresent && !remoteCameraEnabled ? <PhoneCall size={40} className={status === 'connected' && !remoteHold ? 'animate-pulse' : ''} /> : 
                     !remotePresent ? <Loader2 size={40} className="animate-spin" /> : null}
                    <video ref={remoteVideoRef} autoPlay playsInline className={`w-full h-full object-cover ${remoteCameraEnabled ? '' : 'hidden'}`} />
                  </div>
                  {remoteHold && remotePresent && <div className="absolute -bottom-2 -right-2 grid h-8 w-8 place-items-center rounded-full bg-amber-950 border border-amber-900/50 text-amber-500"><Pause size={14} /></div>}
                  {remoteMuted && !remoteHold && remotePresent && <div className="absolute -bottom-2 -right-2 grid h-8 w-8 place-items-center rounded-full bg-red-950 border border-red-900/50 text-red-500"><MicOff size={14} /></div>}
                </div>
                <span className="text-sm font-semibold text-white">{isAdmin ? 'Klient' : 'Ekspert Sleex'}</span>
              </div>
            </div>
            
            {status === 'waiting' && <p className="text-slate-400 animate-pulse">{remotePresent ? 'Oczekiwanie na połączenie p2p...' : isAdmin ? 'Klient jeszcze nie dołączył...' : 'Ekspert zaraz się połączy...'}</p>}
          </div>
        )}
      </div>

      <div className="border-t border-slate-800 bg-slate-950/80 p-6 flex justify-center gap-4">
        {cameraError && <p role="alert" className="absolute -mt-16 rounded-lg border border-red-900/50 bg-red-950 px-3 py-2 text-xs text-red-300">{cameraError}</p>}
        <button 
          onClick={toggleCamera} 
          disabled={status === 'ended'}
          data-testid="button-call-camera"
          aria-label={cameraEnabled ? 'Wyłącz kamerę' : 'Włącz kamerę'}
          title={cameraEnabled ? 'Wyłącz kamerę' : 'Włącz kamerę'}
          className={`grid h-14 w-14 place-items-center rounded-full transition ${cameraEnabled ? 'bg-cyan-950 border-2 border-cyan-900 text-cyan-500' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'} disabled:opacity-50`}
        >
          {cameraEnabled ? <Video size={24} /> : <VideoOff size={24} />}
        </button>
        <button 
          onClick={toggleMute} 
          disabled={status === 'ended'}
          data-testid="button-call-mute"
          aria-label={muted ? 'Włącz mikrofon' : 'Wycisz mikrofon'}
          title={muted ? 'Włącz mikrofon' : 'Wycisz mikrofon'}
          className={`grid h-14 w-14 place-items-center rounded-full transition ${muted ? 'bg-red-950 border-2 border-red-900 text-red-500' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'} disabled:opacity-50`}
        >
          {muted ? <MicOff size={24} /> : <Mic size={24} />}
        </button>
        <button 
          onClick={toggleHold} 
          disabled={status === 'ended'}
          data-testid="button-call-hold"
          aria-label={hold ? 'Wznów rozmowę' : 'Zawieś rozmowę (Hold)'}
          title={hold ? 'Wznów rozmowę' : 'Zawieś rozmowę (Hold)'}
          className={`grid h-14 w-14 place-items-center rounded-full transition ${hold ? 'bg-amber-950 border-2 border-amber-900 text-amber-500' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'} disabled:opacity-50`}
        >
          {hold ? <Play size={24} /> : <Pause size={24} />}
        </button>
        <button 
          onClick={handleLeave} 
          data-testid="button-call-leave"
          aria-label={isAdmin ? 'Opuść i zakończ rozmowę' : 'Opuść rozmowę'}
          title={isAdmin ? 'Opuść i zakończ rozmowę' : 'Opuść rozmowę'}
          className="grid h-14 px-8 place-items-center rounded-full bg-red-600 hover:bg-red-500 text-white shadow-lg transition hover:-translate-y-0.5"
        >
          <span className="font-bold">Opuść {isAdmin ? 'i zakończ' : ''}</span>
        </button>
      </div>
    </div>
  );
}
