import { Calculator, Code2, Database, FileSpreadsheet, Laptop2, Sigma } from 'lucide-react';

const icons = [Code2, Calculator, Database, FileSpreadsheet, Laptop2, Sigma];
const tones = ['from-blue-900 to-cyan-600', 'from-indigo-950 to-blue-600', 'from-cyan-900 to-sky-500', 'from-blue-950 to-indigo-600', 'from-sky-900 to-cyan-500', 'from-indigo-900 to-cyan-600'];

export function ServiceVisual({ index = 0, imageUrl, name }: { index?: number; imageUrl?: string | null; name: string }) {
  const Icon = icons[index % icons.length];
  if (imageUrl) return <img src={imageUrl} alt={name} className="h-full w-full object-cover" />;
  return <div className={`relative flex h-full w-full items-center justify-center overflow-hidden bg-gradient-to-br ${tones[index % tones.length]}`}><div className="absolute -right-10 -top-12 h-40 w-40 rounded-full border-[18px] border-white/10" /><div className="absolute -bottom-16 -left-8 h-44 w-44 rounded-full border-[26px] border-white/5" /><Icon className="relative text-white/90" size={42} strokeWidth={1.35} /><span className="absolute bottom-4 left-5 font-mono text-[10px] uppercase tracking-[.24em] text-white/60">sleex / lab_{String(index + 1).padStart(2, '0')}</span></div>;
}

export function formatPrice(price: number) {
  return new Intl.NumberFormat('pl-PL', { style: 'currency', currency: 'PLN' }).format(price);
}

export function formatDate(date: string) {
  return new Intl.DateTimeFormat('pl-PL', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(date));
}
