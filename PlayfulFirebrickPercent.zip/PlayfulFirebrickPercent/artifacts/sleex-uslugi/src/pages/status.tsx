import { useState, useEffect } from 'react';
import { getLookupOrderStatusQueryKey, useLookupOrderStatus } from '@workspace/api-client-react';
import { AppShell, EmptyState, PageTitle, SkeletonBlock, ErrorNotice } from '@/components/app-shell';
import { Search, Package, Clock3, Info, Paperclip } from 'lucide-react';
import { formatDate, formatPrice } from '@/components/service-visual';

export default function Status() {
  const [trackingId, setTrackingId] = useState('');
  const [searchId, setSearchId] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    if (id && id.length === 16) {
      const upperId = id.toUpperCase();
      setTrackingId(upperId);
      setSearchId(upperId);
    }
  }, []);

  const lookup = useLookupOrderStatus(searchId, {
    query: {
      enabled: searchId.length === 16,
      retry: false,
      queryKey: getLookupOrderStatusQueryKey(searchId)
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackingId.length === 16) {
      setSearchId(trackingId.toUpperCase());
    }
  };

  return (
    <AppShell>
      <title>Status zamówienia — Sleex Usługi</title>
      <div className="mx-auto max-w-3xl px-5 py-14 lg:px-8">
        <PageTitle 
          eyebrow="Śledzenie" 
          title="Sprawdź status." 
          description="Podaj 16-znakowy identyfikator śledzenia (Tracking ID), aby zobaczyć szczegóły i oś czasu."
        />
        
        <form onSubmit={handleSubmit} className="mb-10 flex gap-3">
          <input 
            value={trackingId}
            onChange={e => setTrackingId(e.target.value.toUpperCase())}
            data-testid="input-tracking-id"
            placeholder="NP. A1B2C3D4E5F6G7H8"
            maxLength={16}
            className="flex-1 rounded-xl border border-slate-800 bg-slate-900 px-5 py-4 font-mono text-lg text-white outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition"
          />
          <button 
            type="submit"
            disabled={trackingId.length !== 16}
            data-testid="button-check-status"
            className="rounded-xl gradient-ink px-6 font-bold text-white shadow-lg transition hover:-translate-y-0.5 disabled:opacity-50"
          >
            Sprawdź
          </button>
        </form>

        {lookup.isFetching ? (
          <div className="grid gap-4"><SkeletonBlock className="h-40" /><SkeletonBlock className="h-64" /></div>
        ) : lookup.isError ? (
          <ErrorNotice message="Nie znaleziono zamówienia z tym identyfikatorem lub nie masz do niego dostępu." />
        ) : lookup.data ? (
          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-800 bg-slate-900 overflow-hidden">
              <div className="border-b border-slate-800 p-6 bg-slate-950/30">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="display text-2xl font-semibold text-white">{lookup.data.serviceName}</h2>
                  <span className={`inline-flex rounded-full border px-3 py-1.5 text-sm font-bold ${lookup.data.status === 'completed' ? 'border-emerald-900/50 bg-emerald-950/40 text-emerald-400' : lookup.data.status === 'rejected' ? 'border-red-900/50 bg-red-950/40 text-red-400' : lookup.data.status === 'in_progress' ? 'border-cyan-900/50 bg-cyan-950/40 text-cyan-400' : 'border-amber-900/50 bg-amber-950/40 text-amber-400'}`}>
                    {lookup.data.status}
                  </span>
                </div>
                <div className="flex flex-wrap gap-6 text-sm text-slate-400">
                  <span>ID: <strong className="text-white font-mono">{lookup.data.id}</strong></span>
                  <span>Kwota: <strong className="text-white">{formatPrice(lookup.data.finalPricePln)}</strong></span>
                  <span>Data: <strong className="text-white">{formatDate(lookup.data.createdAt)}</strong></span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">Twoje zgłoszenie</h3>
                <div className="grid gap-4 sm:grid-cols-2 text-sm">
                  <div><span className="text-slate-500">RAM:</span> <span className="text-slate-200">{lookup.data.ramGb} GB</span></div>
                  <div><span className="text-slate-500">Wiek sprzętu:</span> <span className="text-slate-200">{lookup.data.laptopAgeYears} lat</span></div>
                  <div className="sm:col-span-2"><span className="text-slate-500 block mb-1">Opis usterki:</span> <p className="text-slate-200 bg-slate-800/50 p-3 rounded-lg leading-relaxed whitespace-pre-wrap">{lookup.data.damageDescription}</p></div>
                  <div className="sm:col-span-2"><span className="text-slate-500 block mb-1">Okoliczności:</span> <p className="text-slate-200 bg-slate-800/50 p-3 rounded-lg leading-relaxed whitespace-pre-wrap">{lookup.data.incidentDescription}</p></div>
                  
                  {lookup.data.attachments && lookup.data.attachments.length > 0 && (
                    <div className="sm:col-span-2">
                      <span className="text-slate-500 block mb-2">Załączniki:</span>
                      <div className="grid gap-2 sm:grid-cols-2">
                        {lookup.data.attachments.map(att => (
                          <a key={att.id} href={att.downloadUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 p-3 rounded-lg border border-slate-700 bg-slate-800/50 hover:bg-slate-800 transition">
                            <Paperclip size={16} className="text-cyan-500" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-white truncate">{att.filename}</p>
                              <p className="text-xs text-slate-400">{(att.size / 1024 / 1024).toFixed(2)} MB</p>
                            </div>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {lookup.data.events && lookup.data.events.length > 0 && (
              <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-6">Historia zamówienia</h3>
                <div className="relative border-l border-slate-800 ml-3 space-y-6">
                  {lookup.data.events.map((ev: any) => (
                    <div key={ev.id} className="relative pl-6">
                      <span className="absolute -left-[5px] top-1 h-2.5 w-2.5 rounded-full bg-cyan-500 ring-4 ring-slate-900" />
                      <p className="text-sm font-bold text-white">{ev.type}</p>
                      <p className="text-xs text-slate-400 mt-1">{formatDate(ev.createdAt)}</p>
                      {ev.note && <p className="mt-2 text-sm text-slate-300 bg-slate-800/50 p-3 rounded-lg border border-slate-800">{ev.note}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}
