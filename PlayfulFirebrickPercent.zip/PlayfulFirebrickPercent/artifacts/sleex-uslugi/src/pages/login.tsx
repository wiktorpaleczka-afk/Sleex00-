import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, ArrowRight, KeyRound, Mail, ShieldCheck, Sparkles } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import {
  getGetSessionQueryKey,
  useAdminLogin,
  useGetSession,
  useRequestOtp,
  useVerifyOtp,
} from '@workspace/api-client-react';
import { AppShell } from '@/components/app-shell';

type LoginMode = 'customer' | 'admin';

function Login() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: session } = useGetSession();
  const [mode, setMode] = useState<LoginMode>('customer');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [step, setStep] = useState<'email' | 'code'>('email');
  const [adminLogin, setAdminLogin] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [notice, setNotice] = useState('');
  const requestOtp = useRequestOtp();
  const verifyOtp = useVerifyOtp();
  const adminSignIn = useAdminLogin();

  useEffect(() => {
    if (session?.authenticated) {
      setLocation(session.user?.role === 'admin' ? '/admin' : '/account');
    }
  }, [session, setLocation]);

  const refreshSession = async () => {
    await queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey() });
  };

  const sendCode = () => {
    setNotice('');
    requestOtp.mutate(
      { data: { email: email.trim() } },
      {
        onSuccess: (result) => {
          setNotice(result.message);
          setStep('code');
        },
        onError: () => setNotice('Nie udało się wysłać kodu. Sprawdź adres e-mail i spróbuj ponownie.'),
      },
    );
  };

  const verifyCode = () => {
    setNotice('');
    verifyOtp.mutate(
      { data: { email: email.trim(), code } },
      {
        onSuccess: async () => {
          await refreshSession();
          setLocation('/account');
        },
        onError: () => setNotice('Kod jest nieprawidłowy lub wygasł. Poproś o nowy i spróbuj ponownie.'),
      },
    );
  };

  const submitAdminLogin = () => {
    setNotice('');
    adminSignIn.mutate(
      { data: { login: adminLogin, password: adminPassword } },
      {
        onSuccess: async () => {
          await refreshSession();
          setLocation('/admin');
        },
        onError: () => setNotice('Nieprawidłowy login lub hasło administratora.'),
      },
    );
  };

  return (
    <AppShell>
      <title>Logowanie — Sleex Usługi</title>
      <meta name="description" content="Zaloguj się do Sleex kodem jednorazowym albo jako administrator." />
      <div className="shell-grid min-h-[calc(100dvh-72px)] px-5 py-12 lg:px-8">
        <div className="mx-auto grid max-w-5xl gap-10 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
          <div className="hidden lg:block">
            <p className="text-xs font-bold uppercase tracking-[.2em] text-cyan-500">Sleex / dostęp</p>
            <h1 className="display mt-4 text-6xl font-semibold leading-[.95] text-white">
              Twoje miejsce<br /><span className="gradient-text">do ogarniania.</span>
            </h1>
            <p className="mt-6 max-w-sm text-base leading-7 text-slate-400">
              Klienci logują się kodem z wiadomości e-mail. Administrator może użyć osobnego, chronionego dostępu.
            </p>
            <div className="mt-10 flex items-center gap-3 text-sm font-semibold text-slate-400">
              <ShieldCheck size={18} className="text-cyan-500" /> Bezpieczna sesja i chronione dane logowania.
            </div>
          </div>

          <div className="mx-auto w-full max-w-md rounded-[2rem] border border-slate-800 bg-slate-900/80 p-7 shadow-2xl shadow-black/50 backdrop-blur-xl sm:p-9">
            <Link href="/" data-testid="link-login-back" className="mb-8 flex w-fit items-center gap-2 text-sm font-semibold text-slate-400 transition hover:text-cyan-400">
              <ArrowLeft size={15} /> Wróć do katalogu
            </Link>
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl gradient-ink text-white shadow-lg shadow-cyan-900/20">
              {mode === 'admin' ? <KeyRound size={21} /> : <Sparkles size={21} />}
            </div>
            <h2 className="display mt-6 text-3xl font-semibold text-white">
              {mode === 'admin' ? 'Panel administratora.' : step === 'email' ? 'Witaj z powrotem.' : 'Sprawdź swoją skrzynkę.'}
            </h2>
            <p className="mt-3 text-sm leading-6 text-slate-400">
              {mode === 'admin'
                ? 'Użyj danych administratora zapisanych bezpiecznie w konfiguracji aplikacji.'
                : step === 'email'
                  ? 'Podaj e-mail. Wyślemy Ci jednorazowy kod dostępu.'
                  : `Kod dla ${email} jest ważny przez kilka minut.`}
            </p>

            <div className="mt-6 grid grid-cols-2 rounded-xl border border-slate-800 bg-slate-950 p-1">
              <button
                onClick={() => { setMode('customer'); setNotice(''); }}
                data-testid="button-login-mode-customer"
                className={`rounded-lg px-3 py-2.5 text-sm font-bold transition ${mode === 'customer' ? 'gradient-ink text-white' : 'text-slate-400 hover:text-white'}`}
              >
                Klient
              </button>
              <button
                onClick={() => { setMode('admin'); setNotice(''); }}
                data-testid="button-login-mode-admin"
                className={`rounded-lg px-3 py-2.5 text-sm font-bold transition ${mode === 'admin' ? 'gradient-ink text-white' : 'text-slate-400 hover:text-white'}`}
              >
                Administrator
              </button>
            </div>

            {mode === 'admin' ? (
              <div className="mt-6 grid gap-4">
                <label className="text-sm font-semibold text-slate-300">
                  Login
                  <input
                    value={adminLogin}
                    onChange={(event) => setAdminLogin(event.target.value)}
                    data-testid="input-admin-login"
                    autoComplete="username"
                    className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3.5 text-sm text-white outline-none transition focus:ring-2 focus:ring-cyan-500"
                  />
                </label>
                <label className="text-sm font-semibold text-slate-300">
                  Hasło
                  <input
                    type="password"
                    value={adminPassword}
                    onChange={(event) => setAdminPassword(event.target.value)}
                    onKeyDown={(event) => event.key === 'Enter' && submitAdminLogin()}
                    data-testid="input-admin-password"
                    autoComplete="current-password"
                    className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3.5 text-sm text-white outline-none transition focus:ring-2 focus:ring-cyan-500"
                  />
                </label>
                <button
                  onClick={submitAdminLogin}
                  disabled={!adminLogin || !adminPassword || adminSignIn.isPending}
                  data-testid="button-admin-login"
                  className="mt-1 flex w-full items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white shadow-md shadow-cyan-900/20 transition hover:-translate-y-0.5 disabled:opacity-50"
                >
                  {adminSignIn.isPending ? 'Logowanie...' : 'Wejdź do panelu'} <ArrowRight size={16} />
                </button>
              </div>
            ) : step === 'email' ? (
              <>
                <label className="mt-7 block text-sm font-semibold text-slate-300">
                  Adres e-mail
                  <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} data-testid="input-login-email" placeholder="ty@przyklad.pl" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3.5 text-sm text-white outline-none transition focus:ring-2 focus:ring-cyan-500" />
                </label>
                <button onClick={sendCode} disabled={!email.includes('@') || requestOtp.isPending} data-testid="button-request-otp" className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white disabled:opacity-50">
                  {requestOtp.isPending ? 'Wysyłamy kod...' : 'Wyślij kod dostępu'} <ArrowRight size={16} />
                </button>
              </>
            ) : (
              <>
                <label className="mt-7 block text-sm font-semibold text-slate-300">
                  Kod jednorazowy
                  <input inputMode="numeric" maxLength={6} value={code} onChange={(event) => setCode(event.target.value.replace(/\D/g, ''))} data-testid="input-otp-code" placeholder="000 000" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3.5 text-center font-mono text-lg tracking-[.3em] text-white outline-none focus:ring-2 focus:ring-cyan-500" />
                </label>
                <button onClick={verifyCode} disabled={code.length !== 6 || verifyOtp.isPending} data-testid="button-verify-otp" className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white disabled:opacity-50">
                  {verifyOtp.isPending ? 'Sprawdzamy...' : 'Wejdź do konta'} <ArrowRight size={16} />
                </button>
                <button onClick={() => { setStep('email'); setCode(''); setNotice(''); }} data-testid="button-change-email" className="mt-4 w-full text-sm font-semibold text-slate-400 transition hover:text-cyan-400">
                  Użyj innego adresu
                </button>
              </>
            )}

            {notice && (
              <p data-testid="status-login-message" className="mt-5 rounded-xl border border-slate-700 bg-slate-800/80 px-4 py-3 text-sm leading-5 text-slate-300">
                <Mail size={15} className="mr-2 inline text-cyan-400" />{notice}
              </p>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

export default Login;