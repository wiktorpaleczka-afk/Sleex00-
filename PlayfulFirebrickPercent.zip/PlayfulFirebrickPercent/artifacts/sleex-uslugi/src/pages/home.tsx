import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { ArrowRight, Check, Clock3, Headphones, ShieldCheck, Sparkles, X, Paperclip, UploadCloud } from 'lucide-react';
import { useCreateOrder, useGetSession, useListServices, useValidatePromotion } from '@workspace/api-client-react';
import type { Service, OrderInputPaymentMethod } from '@workspace/api-client-react';
import { AppShell, EmptyState, ErrorNotice, PageTitle, SkeletonBlock } from '@/components/app-shell';
import { ServiceVisual, formatPrice } from '@/components/service-visual';
import { useQueryClient } from '@tanstack/react-query';
import { getListOrdersQueryKey } from '@workspace/api-client-react';
import { useUpload } from '@workspace/object-storage-web';

type FileState = {
  id: string;
  file: File;
  status: 'pending' | 'uploading' | 'success' | 'error';
  progress: number;
  objectPath?: string;
  error?: string;
};

function FileItem({ item, updateFile, removeFile }: { item: FileState, updateFile: (id: string, updates: Partial<FileState>) => void, removeFile: (id: string) => void }) {
  const { uploadFile, progress } = useUpload({ purpose: 'order_attachment' });

  useEffect(() => {
    if (item.status === 'pending') {
      doUpload();
    }
  }, [item.status]);

  const doUpload = async () => {
    updateFile(item.id, { status: 'uploading', progress: 0, error: undefined });
    const res = await uploadFile(item.file);
    if (res) {
      updateFile(item.id, { status: 'success', objectPath: res.objectPath, progress: 100 });
    } else {
      updateFile(item.id, { status: 'error', error: 'Błąd wgrywania pliku' });
    }
  };

  return (
    <div className="flex flex-col gap-2 rounded-xl border border-slate-800 bg-slate-950/50 p-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-hidden">
          <Paperclip size={16} className="text-cyan-500 shrink-0" />
          <span className="text-sm font-medium text-slate-200 truncate">{item.file.name}</span>
          <span className="text-xs text-slate-500 shrink-0">{(item.file.size / 1024 / 1024).toFixed(2)} MB</span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {item.status === 'error' && (
            <button type="button" onClick={doUpload} className="text-xs font-bold text-amber-400 hover:text-amber-300">Ponów</button>
          )}
          <button type="button" onClick={() => removeFile(item.id)} data-testid={`button-remove-file-${item.id}`} aria-label="Usuń plik" className="text-slate-500 hover:text-red-400 transition"><X size={16} /></button>
        </div>
      </div>
      {item.status === 'uploading' && (
        <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-cyan-500 transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      )}
      {item.status === 'error' && (
        <span className="text-xs text-red-400">{item.error}</span>
      )}
      {item.status === 'success' && (
        <span className="text-xs text-emerald-400">Przesłano pomyślnie</span>
      )}
    </div>
  );
}

function OrderDialog({ service, onClose }: { service: Service; onClose: () => void }) {
  const { data: session } = useGetSession();
  
  const [promoCode, setPromoCode] = useState('');
  const [promoMessage, setPromoMessage] = useState('');
  
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<OrderInputPaymentMethod>('BLIK');
  const [ramGb, setRamGb] = useState('');
  const [laptopAgeYears, setLaptopAgeYears] = useState('');
  const [damageDescription, setDamageDescription] = useState('');
  const [incidentDescription, setIncidentDescription] = useState('');
  const [files, setFiles] = useState<FileState[]>([]);
  
  const [validationError, setValidationError] = useState('');

  const validate = useValidatePromotion();
  const createOrder = useCreateOrder();
  const queryClient = useQueryClient();

  const updateFile = (id: string, updates: Partial<FileState>) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  };
  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const newFiles = Array.from(e.target.files);
    const remainingSlots = 5 - files.length;
    const toAdd = newFiles.slice(0, remainingSlots).filter(f => f.size <= 10485760);
    
    if (newFiles.length > remainingSlots || newFiles.some(f => f.size > 10485760)) {
      setValidationError('Niektóre pliki zostały pominięte (przekraczają 10MB lub limit 5 plików).');
    } else {
      setValidationError('');
    }

    const newStates = toAdd.map(f => ({
      id: Math.random().toString(36).substring(7),
      file: f,
      status: 'pending' as const,
      progress: 0
    }));
    
    setFiles(prev => [...prev, ...newStates]);
    e.target.value = '';
  };

  const submit = () => {
    setValidationError('');
    if (!customerPhone || customerPhone.length < 5) return setValidationError('Podaj poprawny numer telefonu.');
    if (!ramGb) return setValidationError('Podaj ilość pamięci RAM.');
    if (!laptopAgeYears) return setValidationError('Podaj wiek sprzętu.');
    if (damageDescription.length < 50) return setValidationError(`Opis problemu musi mieć min. 50 znaków (brakuje ${50 - damageDescription.length}).`);
    if (incidentDescription.length < 30) return setValidationError(`Opis okoliczności musi mieć min. 30 znaków (brakuje ${30 - incidentDescription.length}).`);
    
    if (files.some(f => f.status === 'uploading' || f.status === 'pending')) {
      return setValidationError('Poczekaj na zakończenie wgrywania plików.');
    }
    if (files.some(f => f.status === 'error')) {
      return setValidationError('Usuń lub ponów pliki z błędem przed wysłaniem.');
    }

    const attachmentPaths = files.filter(f => f.status === 'success' && f.objectPath).map(f => f.objectPath!);

    createOrder.mutate({ 
      data: { 
        serviceId: service.id, 
        email: session?.user?.email || '',
        customerPhone,
        paymentMethod,
        ramGb: Number(ramGb),
        laptopAgeYears: Number(laptopAgeYears),
        damageDescription,
        incidentDescription,
        promoCode: promoCode.trim() || null,
        attachmentPaths
      } 
    }, {
      onSuccess: () => { 
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() }); 
      },
    });
  };

  const checkPromo = () => {
    if (!promoCode.trim()) return;
    validate.mutate({ data: { code: promoCode.trim(), serviceId: service.id } }, { onSuccess: (result) => setPromoMessage(result.message) });
  };

  if (!session?.authenticated) return <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-5"><div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-800 p-7 shadow-2xl"><div className="flex justify-between"><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-500">Wymagane logowanie</p><button onClick={onClose} data-testid="button-close-order-login" className="text-slate-400 hover:text-white"><X size={19} /></button></div><h2 className="display mt-3 text-2xl font-semibold text-white">Zapiszmy to zamówienie.</h2><p className="mt-2 text-sm leading-6 text-slate-400">Zaloguj się kodem jednorazowym, abyśmy mogli przypisać pomoc do Twojego konta.</p><Link href="/login" data-testid="link-order-login" className="mt-6 flex items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white shadow-lg shadow-cyan-900/20">Przejdź do logowania <ArrowRight size={16} /></Link></div></div>;

  if (createOrder.isSuccess) {
    return (
      <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-5 overflow-y-auto">
        <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-emerald-900/50 p-8 shadow-2xl text-center my-8">
          <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-emerald-950 text-emerald-400">
            <Check size={32} />
          </div>
          <h2 className="display text-2xl font-semibold text-white">Zamówienie przyjęte</h2>
          <p className="mt-3 text-sm leading-6 text-slate-400">
            Szczegóły wysłaliśmy na <strong className="text-slate-300">{session?.user?.email}</strong>.
          </p>
          <div className="mt-6 rounded-2xl bg-slate-950 p-5 border border-slate-800">
            <p className="text-xs uppercase tracking-widest text-slate-500 font-bold mb-2">Twój kod śledzenia</p>
            <p className="font-mono text-2xl text-cyan-400 font-bold tracking-wider select-all">{createOrder.data.trackingId}</p>
          </div>
          <div className="mt-6 flex flex-col gap-3">
            <Link href={`/status-zamowienia?id=${createOrder.data.trackingId}`} data-testid="link-track-order" className="w-full inline-flex justify-center rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white shadow-lg transition hover:-translate-y-0.5">Śledź status</Link>
            <button onClick={onClose} data-testid="button-close-success" className="w-full rounded-xl border border-slate-800 bg-slate-900 px-4 py-3.5 text-sm font-bold text-slate-300 transition hover:bg-slate-800">Zamknij</button>
          </div>
        </div>
      </div>
    );
  }

  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-5"><div className="w-full max-w-lg max-h-[90dvh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-800 p-7 shadow-2xl scrollbar-hide"><div className="flex items-start justify-between sticky top-0 bg-slate-900 z-10 pb-4 border-b border-slate-800 mb-5"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-500">Nowe zamówienie</p><h2 className="display mt-2 text-2xl font-semibold text-white">{service.name}</h2></div><button onClick={onClose} data-testid="button-close-order" className="text-slate-400 hover:text-white"><X size={19} /></button></div>
  
  <div className="space-y-5">
    <div className="rounded-2xl bg-slate-800/50 p-4"><div className="flex justify-between text-sm text-slate-400"><span>Cena bazowa</span><strong className="text-white">{formatPrice(service.pricePln)}</strong></div></div>
    
    <label className="block text-sm font-semibold text-slate-300">Twój e-mail<input value={session.user?.email || ''} readOnly className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950/50 px-4 py-3 text-slate-500 outline-none cursor-not-allowed" /></label>
    
    <label className="block text-sm font-semibold text-slate-300">Numer telefonu<input value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} data-testid="input-customer-phone" placeholder="Wpisz numer kontaktowy" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition" /></label>

    <div className="grid grid-cols-2 gap-4">
      <label className="block text-sm font-semibold text-slate-300">Ilość RAM (GB)<input type="number" value={ramGb} onChange={e => setRamGb(e.target.value)} data-testid="input-ram-gb" placeholder="np. 16" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition" /></label>
      <label className="block text-sm font-semibold text-slate-300">Wiek sprzętu (lata)<input type="number" value={laptopAgeYears} onChange={e => setLaptopAgeYears(e.target.value)} data-testid="input-laptop-age" placeholder="np. 3" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition" /></label>
    </div>

    <label className="block text-sm font-semibold text-slate-300">Opis problemu (min. 50 znaków)
      <textarea value={damageDescription} onChange={e => setDamageDescription(e.target.value)} data-testid="textarea-damage" placeholder="Co dokładnie się dzieje?" className="mt-2 w-full min-h-[100px] rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition" />
      <div className="mt-1 flex justify-end"><span className={`text-xs ${damageDescription.length < 50 ? 'text-slate-500' : 'text-emerald-500'}`}>{damageDescription.length} / 50</span></div>
    </label>

    <label className="block text-sm font-semibold text-slate-300">Okoliczności (min. 30 znaków)
      <textarea value={incidentDescription} onChange={e => setIncidentDescription(e.target.value)} data-testid="textarea-incident" placeholder="Kiedy to się stało? W jakiej sytuacji?" className="mt-2 w-full min-h-[80px] rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition" />
      <div className="mt-1 flex justify-end"><span className={`text-xs ${incidentDescription.length < 30 ? 'text-slate-500' : 'text-emerald-500'}`}>{incidentDescription.length} / 30</span></div>
    </label>

    <div className="space-y-3">
      <span className="block text-sm font-semibold text-slate-300">Załączniki (opcjonalnie)</span>
      {files.length > 0 && (
        <div className="grid gap-2">
          {files.map(f => <FileItem key={f.id} item={f} updateFile={updateFile} removeFile={removeFile} />)}
        </div>
      )}
      {files.length < 5 && (
        <label className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-slate-700 bg-slate-900/50 px-4 py-4 text-sm font-semibold text-slate-400 transition hover:border-cyan-500 hover:bg-slate-800 hover:text-white">
          <UploadCloud size={18} />
          <span>Załącz pliki (max 5, do 10MB)</span>
          <input type="file" multiple className="hidden" data-testid="input-file-picker" onChange={handleFiles} accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt" />
        </label>
      )}
    </div>

    <label className="block text-sm font-semibold text-slate-300">Preferowana płatność (opcjonalna informacja dla nas)
      <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as OrderInputPaymentMethod)} data-testid="select-payment" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-500 transition">
        <option value="BLIK">BLIK</option>
        <option value="LTC">Litecoin (LTC)</option>
        <option value="PSC">Paysafecard (PSC)</option>
      </select>
    </label>

    <label className="block text-sm font-semibold text-slate-300">Kod promocyjny <span className="font-normal text-slate-500">(opcjonalnie)</span><div className="mt-2 flex gap-2"><input value={promoCode} onChange={(e) => setPromoCode(e.target.value.toUpperCase())} data-testid="input-promo-code" placeholder="NP. START15" className="min-w-0 flex-1 rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-sm text-white outline-none focus:border-cyan-500 transition" /><button type="button" onClick={checkPromo} data-testid="button-check-promo" className="rounded-xl border border-slate-700 bg-slate-800 px-4 text-sm font-bold text-cyan-400 hover:bg-slate-700/80 transition">{validate.isPending ? '...' : 'Sprawdź'}</button></div></label>{promoMessage && <p data-testid="text-promo-result" className="text-sm text-cyan-400">{promoMessage}</p>}
    
    {validationError && <p className="rounded-xl bg-red-950/30 px-4 py-3 text-sm text-red-400 border border-red-900/50">{validationError}</p>}
    {(createOrder.error || validate.error) && <p data-testid="status-order-error" className="rounded-xl bg-red-950/30 px-4 py-3 text-sm text-red-400 border border-red-900/50">Nie udało się przetworzyć zamówienia. Sprawdź dane i spróbuj ponownie.</p>}
    
    <button onClick={submit} disabled={createOrder.isPending} data-testid="button-submit-order" className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white shadow-lg shadow-cyan-900/20 transition hover:-translate-y-0.5 disabled:opacity-60">{createOrder.isPending ? 'Przetwarzamy...' : 'Potwierdź zamówienie'} <ArrowRight size={16} /></button>
  </div>
  </div></div>;
}

function Home() {
  const { data: services, isLoading, isError } = useListServices();
  const [selected, setSelected] = useState<Service | null>(null);
  return <AppShell><title>Sleex Usługi — pomoc z informatyki i matematyki</title><meta name="description" content="Wybierz konkretną pomoc z informatyki lub matematyki. Sleex to szybkie, przejrzyste usługi edukacyjne po polsku." /><section className="shell-grid relative overflow-hidden"><div className="mx-auto grid max-w-7xl gap-12 px-5 pb-20 pt-16 lg:grid-cols-[1.06fr_.94fr] lg:items-center lg:px-8 lg:pb-28 lg:pt-24"><div className="fade-up"><div className="mb-6 inline-flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900/80 px-3 py-1.5 text-xs font-bold uppercase tracking-[.13em] text-cyan-400"><span className="h-2 w-2 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.8)]" /> edukacja bez zbędnego tarcia</div><h1 className="display max-w-3xl text-5xl font-semibold leading-[.98] text-white md:text-7xl">Trudne tematy.<br /><span className="gradient-text">Prostszy następny krok.</span></h1><p className="mt-7 max-w-xl text-lg leading-8 text-slate-400">Zamów konkretną pomoc z informatyki lub matematyki. Jasny zakres, uczciwa cena i człowiek po drugiej stronie, kiedy go potrzebujesz.</p><div className="mt-8 flex flex-wrap gap-3"><a href="#katalog" data-testid="link-hero-catalog" className="flex items-center gap-2 rounded-xl gradient-ink px-5 py-3.5 text-sm font-bold text-white shadow-lg shadow-cyan-900/20 transition hover:-translate-y-0.5">Zobacz katalog <ArrowRight size={17} /></a><Link href="/help" data-testid="link-hero-help" className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-5 py-3.5 text-sm font-bold text-slate-300 transition hover:border-slate-700 hover:text-white"><Headphones size={17} /> Porozmawiaj z nami</Link></div><div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-sm text-slate-500"><span className="flex items-center gap-2"><ShieldCheck size={16} className="text-cyan-500" /> Bezpieczne logowanie OTP</span><span className="flex items-center gap-2"><Clock3 size={16} className="text-cyan-500" /> Odpowiedź bez kolejek</span></div></div><div className="relative fade-up fade-up-delay-2"><div className="absolute -inset-8 rounded-[3rem] bg-cyan-500/10 blur-3xl" /><div className="relative rounded-[2rem] border border-slate-800/70 bg-slate-900/75 p-3 shadow-2xl shadow-black/50 backdrop-blur"><div className="gradient-ink relative min-h-[360px] overflow-hidden rounded-[1.5rem] p-7 text-white"><div className="absolute right-[-20%] top-[-16%] h-72 w-72 rounded-full border-[40px] border-white/5" /><div className="absolute bottom-[-22%] left-[-8%] h-80 w-80 rounded-full border-[56px] border-cyan-300/5" /><div className="relative flex items-center justify-between"><span className="font-mono text-[10px] uppercase tracking-[.24em] text-white/60">SLEEX / SESSION_001</span><Sparkles size={18} className="text-cyan-300" /></div><div className="relative mt-24 max-w-xs"><p className="font-mono text-xs uppercase tracking-[.2em] text-cyan-300">Twoja tablica</p><p className="display mt-3 text-4xl font-medium leading-tight">Mniej chaosu.<br />Więcej pewności.</p></div><div className="absolute bottom-7 left-7 right-7 flex items-end justify-between"><div><p className="text-xs text-white/55">dostępne teraz</p><p className="mt-1 text-2xl font-semibold">{services?.length ?? '—'} usług</p></div><div className="flex -space-x-2"><span className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#0d3b78] bg-cyan-500 text-[10px] font-bold text-slate-950">IT</span><span className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#0d3b78] bg-indigo-400 text-[10px] font-bold text-white">∑</span><span className="grid h-8 w-8 place-items-center rounded-full border-2 border-[#0d3b78] bg-slate-200 text-[10px] font-bold text-blue-900">+</span></div></div></div></div></div></div></section><section id="katalog" className="mx-auto max-w-7xl px-5 py-20 lg:px-8"><PageTitle eyebrow="Katalog" title="Wybierz swój temat." description="Nie musisz wiedzieć, jak nazwać problem. Zacznij od obszaru, a resztę ustalimy razem." /><div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{isLoading ? [1,2,3].map((i) => <SkeletonBlock key={i} className="h-[370px]" />) : isError ? <div className="md:col-span-2 lg:col-span-3"><ErrorNotice /></div> : services?.length ? services.map((service, index) => <article key={service.id} data-testid={`card-service-${service.id}`} className="lift overflow-hidden rounded-3xl border border-slate-800 bg-slate-900/50 backdrop-blur-sm"><div className="h-48 border-b border-slate-800"><ServiceVisual index={index} imageUrl={service.imageUrl} name={service.name} /></div><div className="p-5"><div className="flex items-start justify-between gap-3"><h2 className="display text-xl font-semibold leading-tight text-white">{service.name}</h2><span className="shrink-0 rounded-lg bg-slate-800 px-2.5 py-1 font-mono text-xs font-bold text-cyan-400">{formatPrice(service.pricePln)}</span></div><p className="mt-3 min-h-[66px] text-sm leading-6 text-slate-400">{service.description}</p><button onClick={() => setSelected(service)} data-testid={`button-order-service-${service.id}`} className="mt-5 flex w-full items-center justify-between rounded-xl bg-slate-800 px-4 py-3 text-sm font-bold text-white transition hover:bg-slate-700"><span>Zamów pomoc</span><ArrowRight size={16} /></button></div></article>) : <div className="md:col-span-2 lg:col-span-3"><EmptyState title="Katalog jest właśnie aktualizowany" body="Wróć za chwilę — dodajemy nowe obszary wsparcia." /></div>}</div></section><section className="border-y border-slate-800/50 bg-slate-900/40 relative z-10"><div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 md:grid-cols-3 lg:px-8"><div><p className="font-mono text-xs font-bold uppercase tracking-[.15em] text-cyan-500">01 / wybierz</p><p className="mt-3 text-lg font-semibold text-slate-200">Konkretny zakres, nie ogólny abonament.</p></div><div><p className="font-mono text-xs font-bold uppercase tracking-[.15em] text-cyan-500">02 / zamów</p><p className="mt-3 text-lg font-semibold text-slate-200">Jeden prosty formularz i jasna cena.</p></div><div><p className="font-mono text-xs font-bold uppercase tracking-[.15em] text-cyan-500">03 / działaj</p><p className="mt-3 text-lg font-semibold text-slate-200">Sprawdź status w swoim koncie lub napisz do nas.</p></div></div></section>{selected && <OrderDialog service={selected} onClose={() => setSelected(null)} />}</AppShell>;
}

export default Home;
