import { Link } from 'wouter';
import { ArrowLeft, SearchX } from 'lucide-react';

export default function NotFound() {
  return <div className="shell-grid grid min-h-[100dvh] place-items-center bg-[#030712] px-5"><div className="text-center"><div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl gradient-ink text-white shadow-lg shadow-cyan-900/20"><SearchX size={24} /></div><p className="mt-7 font-mono text-xs font-bold uppercase tracking-[.2em] text-cyan-500">404 / poza trasą</p><h1 className="display mt-3 text-5xl font-semibold text-white">Tej strony tu nie ma.</h1><p className="mx-auto mt-4 max-w-md text-sm leading-6 text-slate-400">Wróć do katalogu i wybierz kolejny krok.</p><Link href="/" data-testid="link-not-found-home" className="mt-7 inline-flex items-center gap-2 rounded-xl gradient-ink px-5 py-3 text-sm font-bold text-white shadow-md shadow-cyan-900/20 transition hover:-translate-y-0.5"><ArrowLeft size={16} /> Wróć do katalogu</Link></div></div>;
}
