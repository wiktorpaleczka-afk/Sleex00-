import { useState } from 'react';
import { BarChart3, Check, ChevronRight, ImagePlus, Mail, MessageCircle, Package, Plus, Send, ShieldAlert, Tag, Trash2, Search, Users, ShieldBan, ShieldCheck as ShieldCheckIcon, RefreshCw, Reply, PhoneCall, Calendar, Clock, Video } from 'lucide-react';
import { 
  useBanSupportUser, useCreatePromotion, useCreateService, useDeleteService, useDeleteSupportTicket, 
  useGetAdminOverview, useJoinSupportChat, useLeaveSupportChat, useListAdminSupportTickets, 
  useListPromotions, useListServices, useSendCustomEmail, useListAdminUsers, useWarnAdminUser, 
  useBanAdminUser, useUnbanAdminUser, useListEmailThreads, useGetEmailThread, useSyncGmailInbox, 
  useReplyEmailThread, getGetEmailThreadQueryKey, getListAdminUsersQueryKey, getListEmailThreadsQueryKey,
  useListAdminOrders, useClaimOrder, useRejectOrder, useStartOrder, useCompleteOrder, useScheduleCall,
  getListAdminOrdersQueryKey, useListAdminCalls, useStartCall, useEndCall, useCancelCall, getListAdminCallsQueryKey
} from '@workspace/api-client-react';
import { getGetAdminOverviewQueryKey, getListAdminSupportTicketsQueryKey, getListPromotionsQueryKey, getListServicesQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { AppShell, EmptyState, ErrorNotice, PageTitle, SkeletonBlock } from '@/components/app-shell';
import { formatDate, formatPrice } from '@/components/service-visual';

import AdminOrders from '@/components/admin-orders';
import AdminCalls from '@/components/admin-calls';

type Tab = 'overview' | 'orders' | 'calls' | 'services' | 'promotions' | 'tickets' | 'email' | 'moderation';
const tabs: { id: Tab; label: string; icon: typeof BarChart3 }[] = [
  { id: 'overview', label: 'Przegląd', icon: BarChart3 }, 
  { id: 'orders', label: 'Zamówienia', icon: Package }, 
  { id: 'calls', label: 'Rozmowy', icon: PhoneCall }, 
  { id: 'services', label: 'Usługi', icon: Package }, 
  { id: 'promotions', label: 'Promocje', icon: Tag }, 
  { id: 'tickets', label: 'Zgłoszenia', icon: MessageCircle }, 
  { id: 'email', label: 'Kontakt poprzez maila', icon: Mail },
  { id: 'moderation', label: 'Moderacja', icon: Users }
];

function Admin() {
  const [tab, setTab] = useState<Tab>('overview');
  const overview = useGetAdminOverview();
  return <AppShell><title>Panel administratora — Sleex Usługi</title><meta name="description" content="Panel operacyjny Sleex: usługi, promocje, zgłoszenia i wiadomości e-mail." /><div className="mx-auto max-w-7xl px-5 py-10 lg:px-8"><PageTitle eyebrow="Sleex / operacje" title="Panel sterowania." description="Jedno miejsce do prowadzenia katalogu, klientów i codziennej obsługi." /><div className="mb-8 flex gap-1 overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 p-1.5 scrollbar-hide">{tabs.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setTab(id)} data-testid={`button-admin-tab-${id}`} className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition ${tab === id ? 'gradient-ink text-white shadow-md' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}><Icon size={16} />{label}</button>)}</div>{tab === 'overview' && <Overview overview={overview.data} loading={overview.isLoading} error={overview.isError} onOpenTickets={() => setTab('tickets')} />}
{tab === 'orders' && <AdminOrders />}
{tab === 'calls' && <AdminCalls />}
{tab === 'services' && <Services />}{tab === 'promotions' && <Promotions />}{tab === 'tickets' && <Tickets />}{tab === 'email' && <EmailInterface />}{tab === 'moderation' && <Moderation />}</div></AppShell>;
}

function Overview({ overview, loading, error, onOpenTickets }: { overview?: { serviceCount: number; openTickets: number; newOrders: number; promoRedemptions: number; recentOrders: { id: number; serviceName: string; email: string; finalPricePln: number; createdAt: string }[] }; loading: boolean; error: boolean; onOpenTickets: () => void }) {
  if (loading) return <div className="grid gap-4 md:grid-cols-4"><SkeletonBlock className="h-32" /><SkeletonBlock className="h-32" /><SkeletonBlock className="h-32" /><SkeletonBlock className="h-32" /></div>;
  if (error || !overview) return <ErrorNotice message="Nie udało się pobrać danych panelu. Upewnij się, że masz uprawnienia administratora." />;
  const metrics = [{ label: 'Aktywne usługi', value: overview.serviceCount, icon: Package, tone: 'border-slate-800 bg-slate-800/50 text-cyan-400' }, { label: 'Otwarte zgłoszenia', value: overview.openTickets, icon: MessageCircle, tone: 'border-slate-800 bg-slate-800/50 text-indigo-400' }, { label: 'Nowe zamówienia', value: overview.newOrders, icon: BarChart3, tone: 'border-slate-800 bg-slate-800/50 text-emerald-400' }, { label: 'Użycia promocji', value: overview.promoRedemptions, icon: Tag, tone: 'border-slate-800 bg-slate-800/50 text-fuchsia-400' }];
  return <div className="space-y-6"><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{metrics.map(({ label, value, icon: Icon, tone }) => <div key={label} data-testid={`metric-${label}`} className="rounded-3xl border border-slate-800 bg-slate-900 p-5 shadow-sm"><div className={`grid h-10 w-10 border place-items-center rounded-xl ${tone}`}><Icon size={18} /></div><p className="mt-5 text-sm text-slate-400">{label}</p><p className="display mt-1 text-3xl font-semibold text-white">{value}</p></div>)}</div><section className="rounded-3xl border border-slate-800 bg-slate-900 p-6"><div className="flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-500">Ostatni ruch</p><h2 className="display mt-2 text-2xl font-semibold text-white">Nowe zamówienia</h2></div><button onClick={onOpenTickets} data-testid="button-overview-tickets" className="flex items-center gap-1 text-sm font-bold text-cyan-400 hover:text-cyan-300 transition">Obsłuż zgłoszenia <ChevronRight size={16} /></button></div>{overview.recentOrders?.length ? <div className="mt-6 divide-y divide-slate-800">{overview.recentOrders.map((order) => <div key={order.id} data-testid={`row-recent-order-${order.id}`} className="flex items-center justify-between py-4"><div><p className="font-semibold text-white">{order.serviceName}</p><p className="mt-1 text-xs text-slate-400">{order.email} · {formatDate(order.createdAt)}</p></div><span className="font-semibold text-white">{formatPrice(order.finalPricePln)}</span></div>)}</div> : <div className="mt-6"><EmptyState title="Spokojny początek dnia" body="Nowe zamówienia pojawią się tutaj, gdy klienci wybiorą pomoc." /></div>}</section></div>;
}

function Services() {
  const queryClient = useQueryClient();
  const { data, isLoading, isError } = useListServices();
  const create = useCreateService();
  const remove = useDeleteService();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const uploadImage = async (file: File) => {
    setUploading(true);
    setUploadError('');
    try {
      const metadataResponse = await fetch('/api/storage/uploads/request-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type || 'image/jpeg' }),
      });
      if (!metadataResponse.ok) throw new Error('Nie udało się przygotować zdjęcia.');
      const uploaded = (await metadataResponse.json()) as { uploadURL: string; objectPath: string };
      const fileResponse = await fetch(uploaded.uploadURL, {
        method: 'PUT',
        headers: { 'Content-Type': file.type || 'image/jpeg' },
        body: file,
      });
      if (!fileResponse.ok) throw new Error('Nie udało się wysłać zdjęcia.');
      setImageUrl(`/api/storage${uploaded.objectPath}`);
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : 'Nie udało się wysłać zdjęcia.');
    } finally {
      setUploading(false);
    }
  };

  const submit = () => create.mutate(
    { data: { name, description, pricePln: Number(price), imageUrl, published: true } },
    { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListServicesQueryKey() }); setName(''); setDescription(''); setPrice(''); setImageUrl(null); setOpen(false); } },
  );
  const deleteService = (id: number) => { if (window.confirm('Usunąć tę usługę?')) remove.mutate({ serviceId: id }, { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListServicesQueryKey() }) }); };

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div><p className="text-sm text-slate-400">Widoczne w publicznym katalogu</p><h2 className="display text-2xl font-semibold text-white">Zarządzaj usługami</h2></div>
        <button onClick={() => setOpen(!open)} data-testid="button-add-service" className="flex items-center gap-2 rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white shadow-md shadow-cyan-900/20 transition hover:-translate-y-0.5"><Plus size={16} /> Dodaj usługę</button>
      </div>
      {open && (
        <div className="mb-5 rounded-3xl border border-slate-800 bg-slate-900 p-6">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="text-sm font-semibold text-slate-300">Nazwa<input value={name} onChange={(e) => setName(e.target.value)} data-testid="input-service-name" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label>
            <label className="text-sm font-semibold text-slate-300">Cena (PLN)<input type="number" value={price} onChange={(e) => setPrice(e.target.value)} data-testid="input-service-price" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label>
            <label className="text-sm font-semibold text-slate-300 md:col-span-2">Opis<textarea value={description} onChange={(e) => setDescription(e.target.value)} data-testid="input-service-description" className="mt-2 min-h-24 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label>
            <div className="md:col-span-2">
              <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-dashed border-slate-700 bg-slate-950 px-4 py-4 text-sm font-semibold text-slate-300 hover:border-cyan-500 hover:text-cyan-400 transition">
                <ImagePlus size={20} />
                <span>{uploading ? 'Wysyłamy zdjęcie...' : imageUrl ? 'Zdjęcie dodane — wybierz inne, aby zmienić' : 'Dodaj zdjęcie z urządzenia (opcjonalnie)'}</span>
                <input type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" disabled={uploading} onChange={(e) => { const file = e.target.files?.[0]; if (file) void uploadImage(file); }} />
              </label>
              {imageUrl && <img src={imageUrl} alt="Podgląd usługi" className="mt-3 h-28 w-44 rounded-xl object-cover border border-slate-800" />}
              {uploadError && <p className="mt-2 text-sm text-red-400">{uploadError}</p>}
            </div>
          </div>
          {create.error && <p data-testid="status-service-error" className="mt-3 text-sm text-red-400">Nie udało się dodać usługi.</p>}
          <button onClick={submit} disabled={create.isPending || uploading || name.length < 2 || description.length < 2 || !price} data-testid="button-submit-service" className="mt-4 rounded-xl gradient-ink px-5 py-3 text-sm font-bold text-white disabled:opacity-50 transition hover:-translate-y-0.5">{create.isPending ? 'Dodajemy...' : 'Zapisz usługę'}</button>
        </div>
      )}
      {isLoading ? <SkeletonBlock className="h-28" /> : isError ? <ErrorNotice /> : data?.length ? <div className="grid gap-3">{data.map((service) => <div key={service.id} data-testid={`row-service-${service.id}`} className="flex flex-col gap-4 rounded-2xl border border-slate-800 bg-slate-900 p-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-4"><div className="h-14 w-14 overflow-hidden rounded-xl bg-slate-800">{service.imageUrl ? <img src={service.imageUrl} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-slate-600"><Package size={20} /></div>}</div><div><div className="flex items-center gap-2"><h3 className="font-semibold text-white">{service.name}</h3><span className="rounded-full border border-emerald-900/50 bg-emerald-950/40 px-2 py-1 text-[10px] font-bold uppercase text-emerald-400">opublikowana</span></div><p className="mt-1 text-sm text-slate-400">{service.description}</p></div></div><div className="flex items-center justify-between gap-5"><span className="font-semibold text-white">{formatPrice(service.pricePln)}</span><button onClick={() => deleteService(service.id)} disabled={remove.isPending} data-testid={`button-delete-service-${service.id}`} className="grid h-9 w-9 place-items-center rounded-lg text-slate-500 hover:bg-red-950/40 hover:text-red-400 transition"><Trash2 size={16} /></button></div></div>)}</div> : <EmptyState title="Katalog jest pusty" body="Dodaj pierwszą usługę, aby klienci mogli ją zobaczyć." />}
    </section>
  );
}

function Promotions() {
  const queryClient = useQueryClient(); const { data, isLoading, isError } = useListPromotions(); const create = useCreatePromotion();
  const [code, setCode] = useState(''); const [discount, setDiscount] = useState(''); const [limit, setLimit] = useState('');
  const submit = () => create.mutate({ data: { code: code.toUpperCase(), discountPercent: Number(discount), usageLimit: Number(limit) } }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListPromotionsQueryKey() }); setCode(''); setDiscount(''); setLimit(''); } });
  return <section className="grid gap-6 lg:grid-cols-[.8fr_1.2fr]"><div className="rounded-3xl border border-slate-800 bg-slate-900 p-6"><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-500">Nowa promocja</p><h2 className="display mt-2 text-2xl font-semibold text-white">Daj klientom dobry powód.</h2><div className="mt-6 grid gap-4"><label className="text-sm font-semibold text-slate-300">Kod<input value={code} onChange={(e) => setCode(e.target.value)} data-testid="input-promotion-code" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 font-mono uppercase text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label><div className="grid grid-cols-2 gap-3"><label className="text-sm font-semibold text-slate-300">Rabat %<input type="number" value={discount} onChange={(e) => setDiscount(e.target.value)} data-testid="input-promotion-discount" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label><label className="text-sm font-semibold text-slate-300">Limit użyć<input type="number" value={limit} onChange={(e) => setLimit(e.target.value)} data-testid="input-promotion-limit" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" /></label></div><button onClick={submit} disabled={create.isPending || code.length < 3 || !discount || !limit} data-testid="button-submit-promotion" className="rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white disabled:opacity-50 transition hover:-translate-y-0.5">{create.isPending ? 'Tworzymy...' : 'Utwórz kod'}</button>{create.error && <p data-testid="status-promotion-error" className="text-sm text-red-400">Nie udało się utworzyć kodu.</p>}</div></div><div>{isLoading ? <SkeletonBlock className="h-28" /> : isError ? <ErrorNotice /> : data?.length ? <div className="grid gap-3">{data.map((promotion) => <div key={promotion.id} data-testid={`row-promotion-${promotion.id}`} className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900 p-5"><div><p className="font-mono font-bold text-cyan-400">{promotion.code}</p><p className="mt-1 text-xs text-slate-400">{promotion.discountPercent}% rabatu · {promotion.usedCount} / {promotion.usageLimit} użyć</p></div><span className={`rounded-full px-2.5 py-1 text-xs font-bold border ${promotion.active ? 'border-emerald-900/50 bg-emerald-950/40 text-emerald-400' : 'border-slate-800 bg-slate-950 text-slate-500'}`}>{promotion.active ? 'aktywna' : 'nieaktywna'}</span></div>)}</div> : <EmptyState title="Brak kodów promocyjnych" body="Utwórz kod, który będzie pasował do najbliższej kampanii." />}</div></section>;
}

function Tickets() {
  const queryClient = useQueryClient(); const { data, isLoading, isError } = useListAdminSupportTickets(); const join = useJoinSupportChat(); const leave = useLeaveSupportChat(); const ban = useBanSupportUser(); const remove = useDeleteSupportTicket();
  const action = (kind: 'join' | 'leave' | 'ban' | 'delete', id: number) => {
    if (kind === 'delete' && !window.confirm('Usunąć całe zgłoszenie i historię rozmowy?')) return;
    const mutation = kind === 'join' ? join : kind === 'leave' ? leave : kind === 'ban' ? ban : remove;
    mutation.mutate({ ticketId: id }, { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListAdminSupportTicketsQueryKey() }); queryClient.invalidateQueries({ queryKey: getGetAdminOverviewQueryKey() }); } });
  };
  return <section><div className="mb-5"><p className="text-sm text-slate-400">Obsługa rozmów z klientami</p><h2 className="display text-2xl font-semibold text-white">Kolejka zgłoszeń</h2></div>{isLoading ? <div className="grid gap-3"><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /></div> : isError ? <ErrorNotice /> : data?.length ? <div className="grid gap-3">{data.map((ticket) => <div key={ticket.id} data-testid={`row-admin-ticket-${ticket.id}`} className="rounded-2xl border border-slate-800 bg-slate-900 p-5"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><div className="flex items-center gap-2"><h3 className="font-semibold text-white">{ticket.subject}</h3><span className="rounded-full border border-cyan-900/50 bg-cyan-950/40 px-2 py-1 text-[10px] font-bold uppercase text-cyan-400">{ticket.status}</span></div><p className="mt-1 text-xs text-slate-400">{ticket.email} · {formatDate(ticket.createdAt)}</p><p className="mt-3 text-sm leading-6 text-slate-300">{ticket.message}</p></div><div className="flex shrink-0 gap-2"><button onClick={() => action(ticket.adminJoined ? 'leave' : 'join', ticket.id)} data-testid={`button-ticket-chat-${ticket.id}`} className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-white hover:bg-slate-700/80 transition">{ticket.adminJoined ? 'Opuść czat' : 'Dołącz do czatu'}</button><button onClick={() => action('ban', ticket.id)} data-testid={`button-ban-ticket-${ticket.id}`} className="rounded-lg border border-red-900/50 bg-red-950/40 px-3 py-2 text-xs font-bold text-red-400 transition hover:bg-red-900/50"><ShieldAlert size={14} /></button><button onClick={() => action('delete', ticket.id)} data-testid={`button-delete-ticket-${ticket.id}`} className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-slate-400 hover:bg-red-950/40 hover:text-red-400 hover:border-red-900/50 transition"><Trash2 size={14} /></button></div></div></div>)}</div> : <EmptyState title="Kolejka jest pusta" body="Żadne zgłoszenie nie czeka teraz na odpowiedź." />}</section>;
}

function Moderation() {
  const [search, setSearch] = useState('');
  const queryClient = useQueryClient();
  const { data: users, isLoading, isError } = useListAdminUsers({ search });
  const warn = useWarnAdminUser();
  const ban = useBanAdminUser();
  const unban = useUnbanAdminUser();
  
  const [reason, setReason] = useState('');
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [actionType, setActionType] = useState<'warn' | 'ban' | null>(null);

  const handleAction = () => {
    if (!selectedUser || !actionType || !reason) return;
    const mutation = actionType === 'warn' ? warn : ban;
    mutation.mutate({ userId: selectedUser, data: { reason } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminUsersQueryKey() });
        setSelectedUser(null);
        setActionType(null);
        setReason('');
      }
    });
  };

  const handleUnban = (id: number) => {
    if (!window.confirm('Czy na pewno chcesz odbanować tego użytkownika?')) return;
    unban.mutate({ userId: id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAdminUsersQueryKey() });
      }
    });
  };

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">Panel ochrony społeczności</p>
          <h2 className="display text-2xl font-semibold text-white">Zarządzanie użytkownikami</h2>
        </div>
      </div>
      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
          <input 
            type="text" 
            placeholder="Szukaj po adresie e-mail..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            data-testid="input-search-users"
            className="w-full rounded-xl border border-slate-800 bg-slate-900 py-3 pl-11 pr-4 text-sm text-white placeholder-slate-500 outline-none transition focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500" 
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-3"><SkeletonBlock className="h-20" /><SkeletonBlock className="h-20" /></div>
      ) : isError ? (
        <ErrorNotice message="Nie udało się pobrać listy użytkowników." />
      ) : users?.length ? (
        <div className="grid gap-3">
          {users.map(user => (
            <div key={user.id} data-testid={`row-user-${user.id}`} className="flex flex-col gap-4 rounded-2xl border border-slate-800 bg-slate-900 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold text-white">{user.email}</h3>
                  {user.banned && (
                    <span className="flex items-center gap-1 rounded-full border border-red-900/50 bg-red-950/40 px-2.5 py-1 text-[10px] font-bold uppercase text-red-400">
                      <ShieldBan size={12} /> Zbanowany
                    </span>
                  )}
                  {user.role === 'admin' && (
                    <span className="rounded-full border border-cyan-900/50 bg-cyan-950/40 px-2 py-1 text-[10px] font-bold uppercase text-cyan-400">
                      Admin
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-slate-400">Konto utworzone {formatDate(user.createdAt)}</p>
                {user.banned && user.banReason && (
                  <p className="mt-2 text-sm text-red-300">Powód: {user.banReason}</p>
                )}
              </div>
              
              <div className="flex shrink-0 items-center gap-2">
                {user.banned ? (
                  <button 
                    onClick={() => handleUnban(user.id)} 
                    disabled={unban.isPending}
                    data-testid={`button-unban-${user.id}`}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs font-bold text-white transition hover:bg-slate-700/80"
                  >
                    <ShieldCheckIcon size={14} /> Przywróć dostęp
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={() => { setSelectedUser(user.id); setActionType('warn'); setReason(''); }}
                      data-testid={`button-warn-${user.id}`}
                      className="rounded-lg border border-amber-900/50 bg-amber-950/20 px-3 py-2 text-xs font-bold text-amber-400 transition hover:bg-amber-950/40"
                    >
                      Ostrzeż
                    </button>
                    <button 
                      onClick={() => { setSelectedUser(user.id); setActionType('ban'); setReason(''); }}
                      data-testid={`button-ban-${user.id}`}
                      className="rounded-lg border border-red-900/50 bg-red-950/20 px-3 py-2 text-xs font-bold text-red-400 transition hover:bg-red-950/40"
                    >
                      Zbanuj
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="Brak wyników" body="Nie znaleziono użytkowników spełniających kryteria wyszukiwania." />
      )}

      {selectedUser && actionType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-3xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="display text-xl font-semibold text-white mb-2">
              {actionType === 'warn' ? 'Wyślij ostrzeżenie' : 'Zablokuj konto'}
            </h3>
            <p className="text-sm text-slate-400 mb-5">
              {actionType === 'warn' ? 'Użytkownik otrzyma powiadomienie z podanym powodem.' : 'Użytkownik straci dostęp do większości funkcji aplikacji.'}
            </p>
            <textarea 
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Podaj powód..."
              data-testid="input-moderation-reason"
              className="min-h-24 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
            />
            <div className="mt-5 flex gap-3">
              <button 
                onClick={() => { setSelectedUser(null); setActionType(null); }}
                className="flex-1 rounded-xl border border-slate-700 bg-transparent px-4 py-2.5 text-sm font-bold text-slate-300 transition hover:bg-slate-800"
              >
                Anuluj
              </button>
              <button 
                onClick={handleAction}
                disabled={!reason.trim() || warn.isPending || ban.isPending}
                data-testid="button-submit-moderation"
                className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-bold text-white transition hover:-translate-y-0.5 ${actionType === 'warn' ? 'bg-amber-600 hover:bg-amber-500' : 'bg-red-600 hover:bg-red-500'} disabled:opacity-50`}
              >
                {warn.isPending || ban.isPending ? 'Przetwarzanie...' : 'Zatwierdź'}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
function EmailInterface() {
  const queryClient = useQueryClient();
  const { data: threads, isLoading, isError } = useListEmailThreads();
  const sync = useSyncGmailInbox();
  
  const [selectedThreadId, setSelectedThreadId] = useState<number | null>(null);
  const [showCompose, setShowCompose] = useState(false);

  const handleSync = () => {
    sync.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListEmailThreadsQueryKey() });
      }
    });
  };

  return (
    <section className="grid gap-6 lg:grid-cols-[300px_1fr] xl:grid-cols-[350px_1fr]">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-400">Skrzynka odbiorcza</p>
            <h2 className="display text-xl font-semibold text-white">Wiadomości</h2>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => { setShowCompose(true); setSelectedThreadId(null); }}
              data-testid="button-compose-email"
              className="grid h-9 w-9 place-items-center rounded-xl border border-slate-700 bg-slate-800 text-slate-300 transition hover:border-cyan-500 hover:text-cyan-400"
              title="Nowa wiadomość"
            >
              <Plus size={16} />
            </button>
            <button 
              onClick={handleSync} 
              disabled={sync.isPending}
              data-testid="button-sync-gmail"
              className="grid h-9 w-9 place-items-center rounded-xl border border-slate-700 bg-slate-800 text-slate-300 transition hover:border-cyan-500 hover:text-cyan-400 disabled:opacity-50"
              title="Pobierz nowe maile"
            >
              <RefreshCw size={16} className={sync.isPending ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>
        
        <div className="flex flex-col gap-2">
          {isLoading ? (
            <><SkeletonBlock className="h-24" /><SkeletonBlock className="h-24" /></>
          ) : isError ? (
            <ErrorNotice message="Nie udało się pobrać wiadomości." />
          ) : threads?.length ? (
            threads.map(thread => (
              <button 
                key={thread.id} 
                onClick={() => { setSelectedThreadId(thread.id); setShowCompose(false); }}
                data-testid={`row-thread-${thread.id}`}
                className={`flex flex-col gap-2 rounded-2xl border p-4 text-left transition ${selectedThreadId === thread.id && !showCompose ? 'border-cyan-900/50 bg-cyan-950/20' : 'border-slate-800 bg-slate-900 hover:bg-slate-800/50'}`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="truncate text-sm font-bold text-white">{thread.customerEmail}</span>
                  <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${thread.status === 'pending' ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' : 'bg-emerald-500'}`} />
                </div>
                <p className="line-clamp-2 text-xs leading-5 text-slate-400">{thread.subject}</p>
                <p className="text-[10px] text-slate-500">{formatDate(thread.lastMessageAt)}</p>
              </button>
            ))
          ) : (
            <EmptyState title="Skrzynka jest pusta" body="Brak wiadomości od klientów." />
          )}
        </div>
      </div>

      <div className="rounded-3xl border border-slate-800 bg-slate-900 overflow-hidden flex flex-col min-h-[500px]">
        {showCompose ? (
          <EmailForm />
        ) : selectedThreadId ? (
          <ThreadDetail threadId={selectedThreadId} />
        ) : (
          <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
            <div className="mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-slate-800 text-cyan-400">
              <Mail size={24} />
            </div>
            <h3 className="display text-xl font-semibold text-white">Wybierz wątek</h3>
            <p className="mt-2 max-w-sm text-sm leading-6 text-slate-400">
              Kliknij wiadomość z listy po lewej stronie, aby zobaczyć historię korespondencji i odpowiedzieć.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function ThreadDetail({ threadId }: { threadId: number }) {
  const queryClient = useQueryClient();
  const { data: thread, isLoading, isError } = useGetEmailThread(threadId);
  const reply = useReplyEmailThread();
  const [body, setBody] = useState('');

  const handleReply = () => {
    if (!body.trim()) return;
    reply.mutate({ threadId, data: { body } }, {
      onSuccess: () => {
        setBody('');
        queryClient.invalidateQueries({ queryKey: getListEmailThreadsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetEmailThreadQueryKey(threadId) });
      }
    });
  };

  if (isLoading) return <div className="p-6 grid gap-4"><SkeletonBlock className="h-12" /><SkeletonBlock className="h-32" /></div>;
  if (isError || !thread) return <div className="p-6"><ErrorNotice message="Nie udało się załadować wątku." /></div>;

  return (
    <div className="flex flex-col h-full max-h-[700px]">
      <div className="border-b border-slate-800 bg-slate-950/50 p-5 sm:px-6 sm:py-5 shrink-0">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold text-white">{thread.subject}</h2>
          <span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase ${thread.status === 'pending' ? 'border-red-900/50 bg-red-950/40 text-red-400' : 'border-emerald-900/50 bg-emerald-950/40 text-emerald-400'}`}>
            {thread.status === 'pending' ? 'Oczekuje' : 'Obsłużone'}
          </span>
        </div>
        <p className="mt-1 text-sm text-slate-400">Klient: {thread.customerEmail}</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 flex flex-col-reverse">
        <div className="flex flex-col gap-6">
          {thread.messages.map(msg => {
            const isInbound = msg.direction === 'inbound';
            return (
              <div key={msg.id} data-testid={`message-${msg.id}`} className={`flex flex-col max-w-[85%] ${isInbound ? 'self-start' : 'self-end items-end ml-auto'}`}>
                <div className="flex items-center gap-2 mb-1.5 px-1">
                  <span className="text-[10px] font-semibold text-slate-500">{isInbound ? msg.senderEmail : 'My (Sleex)'}</span>
                  <span className="text-[10px] text-slate-600">{formatDate(msg.sentAt)}</span>
                </div>
                <div className={`rounded-2xl px-5 py-4 text-sm leading-relaxed ${isInbound ? 'rounded-tl-none border border-slate-700 bg-slate-800 text-slate-200' : 'rounded-tr-none gradient-ink text-white shadow-md'}`}>
                  {msg.body.split('\n').map((line, i) => (
                    <p key={i} className="min-h-[1em]">{line}</p>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="border-t border-slate-800 bg-slate-950/50 p-5 sm:p-6 shrink-0">
        <label className="sr-only">Twoja odpowiedź</label>
        <textarea 
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Napisz odpowiedź do klienta..."
          data-testid="input-email-reply"
          className="min-h-24 w-full resize-none rounded-xl border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
        />
        <div className="mt-3 flex items-center justify-between">
          <p className="text-xs text-slate-500">Odpowiedź zostanie wysłana na adres {thread.customerEmail}</p>
          <button 
            onClick={handleReply}
            disabled={!body.trim() || reply.isPending}
            data-testid="button-send-reply"
            className="flex items-center gap-2 rounded-xl gradient-ink px-5 py-2.5 text-sm font-bold text-white transition hover:-translate-y-0.5 disabled:opacity-50"
          >
            <Reply size={16} /> {reply.isPending ? 'Wysyłanie...' : 'Wyślij'}
          </button>
        </div>
      </div>
    </div>
  );
}

function EmailForm() {
  const queryClient = useQueryClient();
  const send = useSendCustomEmail(); 
  const [recipient, setRecipient] = useState(''); 
  const [subject, setSubject] = useState(''); 
  const [body, setBody] = useState(''); 
  const [sent, setSent] = useState(false);
  
  const submit = () => send.mutate({ data: { recipient, subject, body } }, { 
    onSuccess: () => {
      setSent(true);
      setRecipient('');
      setSubject('');
      setBody('');
      queryClient.invalidateQueries({ queryKey: getListEmailThreadsQueryKey() });
    } 
  });
  
  return (
    <div className="p-6 sm:p-8">
      <h2 className="display text-xl font-semibold text-white">Wyślij nową wiadomość.</h2>
      <p className="mt-2 text-sm leading-6 text-slate-400">Ręczny kontakt z klientem przez skonfigurowany kanał SMTP.</p>
      <div className="mt-7 grid gap-4">
        <label className="text-sm font-semibold text-slate-300">Odbiorca
          <input type="email" value={recipient} onChange={(e) => setRecipient(e.target.value)} data-testid="input-email-recipient" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" />
        </label>
        <label className="text-sm font-semibold text-slate-300">Temat
          <input value={subject} onChange={(e) => setSubject(e.target.value)} data-testid="input-email-subject" className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" />
        </label>
        <label className="text-sm font-semibold text-slate-300">Treść
          <textarea value={body} onChange={(e) => setBody(e.target.value)} data-testid="input-email-body" className="mt-2 min-h-48 w-full rounded-xl border border-slate-800 bg-slate-950 px-4 py-3 text-white outline-none focus:ring-2 focus:ring-cyan-500 transition" />
        </label>
        {send.error && <ErrorNotice message="Nie udało się wysłać wiadomości. Sprawdź konfigurację i dane odbiorcy." />}
        {sent && <p data-testid="status-email-sent" className="rounded-xl border border-emerald-900/50 bg-emerald-950/40 px-4 py-3 text-sm font-semibold text-emerald-400"><Check size={15} className="mr-2 inline" />Wiadomość została wysłana.</p>}
        <button onClick={submit} disabled={send.isPending || !recipient.includes('@') || !subject || !body} data-testid="button-send-email" className="flex items-center justify-center gap-2 rounded-xl gradient-ink px-4 py-3.5 text-sm font-bold text-white disabled:opacity-50 transition hover:-translate-y-0.5">
          <Send size={16} /> {send.isPending ? 'Wysyłamy...' : 'Wyślij wiadomość'}
        </button>
      </div>
    </div>
  );
}
export default Admin;
