import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { ArrowRight, PackageOpen, Phone, Video, Calendar, Clock, PlayCircle } from 'lucide-react';
import { getListOrdersQueryKey, getListCallsQueryKey, useGetSession, useListOrders, useListCalls, type Call } from '@workspace/api-client-react';
import { AppShell, EmptyState, ErrorNotice, PageTitle, SkeletonBlock } from '@/components/app-shell';
import { formatDate, formatPrice } from '@/components/service-visual';
import CallRoom from '@/components/call-room';

export default function Account() {
  const { data: session, isLoading: sessionLoading } = useGetSession();
  const requestedCallId = Number(new URLSearchParams(window.location.search).get('call'));
  const initialCallId = Number.isInteger(requestedCallId) && requestedCallId > 0 ? requestedCallId : null;
  const [tab, setTab] = useState<'orders' | 'calls'>(initialCallId ? 'calls' : 'orders');
  const [activeCallId, setActiveCallId] = useState<number | null>(null);

  const calls = useListCalls({ 
    query: { 
      enabled: session?.authenticated === true, 
      queryKey: getListCallsQueryKey(),
      refetchInterval: 10000 
    } 
  });

  useEffect(() => {
    if (initialCallId) {
      setTab('calls');
      if (calls.data) {
        const callExists = calls.data.some(c => c.id === initialCallId);
        if (callExists) {
          setActiveCallId(initialCallId);
        } else {
          window.history.replaceState({}, '', '/account');
        }
      }
    }
  }, [initialCallId, calls.data]);
  
  if (sessionLoading) return <AppShell><div className="mx-auto max-w-7xl px-5 py-14 lg:px-8"><SkeletonBlock className="h-16 w-72" /><SkeletonBlock className="mt-8 h-40" /></div></AppShell>;
  
  return (
    <AppShell>
      <title>Moje konto — Sleex Usługi</title>
      <meta name="description" content="Sprawdź status swoich zamówień usług edukacyjnych i połączeń w Sleex." />
      <div className="mx-auto max-w-7xl px-5 py-12 lg:px-8">
        <PageTitle 
          eyebrow="Strefa klienta" 
          title="Twoje usługi." 
          description={session?.user?.email ? `Zalogowano jako ${session.user.email}.` : 'Wszystko, co zamawiasz, w jednym spokojnym miejscu.'} 
          action={<Link href="/" data-testid="link-account-catalog" className="flex items-center gap-2 rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white shadow-lg shadow-cyan-900/20 transition hover:-translate-y-0.5">Nowa pomoc <ArrowRight size={16} /></Link>} 
        />
        
        {!session?.authenticated ? (
          <EmptyState title="Zaloguj się, aby zobaczyć zamówienia" body="Dostęp do historii zamówień jest przypisany do Twojego adresu e-mail." action={<Link href="/login" data-testid="link-account-login" className="mt-5 inline-flex rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5">Zaloguj się</Link>} />
        ) : (
          <>
            <div className="mb-8 flex gap-2 border-b border-slate-800 pb-px">
              <button onClick={() => setTab('orders')} className={`px-4 py-3 text-sm font-bold border-b-2 transition ${tab === 'orders' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400 hover:text-white'}`}>Zamówienia</button>
              <button onClick={() => setTab('calls')} className={`px-4 py-3 text-sm font-bold border-b-2 transition ${tab === 'calls' ? 'border-cyan-500 text-cyan-400' : 'border-transparent text-slate-400 hover:text-white'}`}>Rozmowy</button>
            </div>
            
            {tab === 'orders' && <OrdersTab authenticated={session.authenticated} />}
            {tab === 'calls' && <CallsTab callsQuery={calls} activeCallId={activeCallId} setActiveCallId={setActiveCallId} />}
          </>
        )}
      </div>
    </AppShell>
  );
}

function OrdersTab({ authenticated }: { authenticated: boolean }) {
  const orders = useListOrders({ query: { enabled: authenticated, queryKey: getListOrdersQueryKey() } });
  
  if (orders.isLoading) return <div className="grid gap-3"><SkeletonBlock className="h-24" /><SkeletonBlock className="h-24" /></div>;
  if (orders.isError) return <ErrorNotice message="Nie udało się pobrać zamówień. Odśwież stronę i spróbuj ponownie." />;
  if (!orders.data?.length) return <EmptyState title="Nie masz jeszcze zamówień" body="Wybierz usługę z katalogu, a potem wróć tutaj, żeby śledzić jej status." action={<Link href="/" data-testid="link-empty-catalog" className="mt-5 inline-flex items-center gap-2 rounded-xl gradient-ink px-4 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5">Przeglądaj katalog <PackageOpen size={16} /></Link>} />;
  
  return (
    <div className="overflow-hidden rounded-3xl border border-slate-800 bg-slate-900">
      <div className="hidden grid-cols-[1.2fr_.7fr_.7fr_.7fr] border-b border-slate-800 bg-slate-950/50 px-6 py-4 text-xs font-bold uppercase tracking-[.12em] text-slate-500 md:grid">
        <span>Usługa</span>
        <span>Data</span>
        <span>Status</span>
        <span className="text-right">Kwota</span>
      </div>
      {orders.data.map((order) => (
        <div key={order.id} data-testid={`row-order-${order.id}`} className="grid gap-4 border-b border-slate-800 px-5 py-5 last:border-0 md:grid-cols-[1.2fr_.7fr_.7fr_.7fr] md:items-center md:px-6 hover:bg-slate-800/30 transition">
          <div>
            <p className="font-semibold text-white">{order.serviceName}</p>
            <div className="mt-1 flex items-center gap-2">
              <p className="text-xs font-mono text-cyan-400 bg-cyan-950/30 px-2 py-0.5 rounded border border-cyan-900/30 select-all">{order.trackingId}</p>
            </div>
          </div>
          <p className="text-sm text-slate-400">{formatDate(order.createdAt)}</p>
          <p>
            <span data-testid={`status-order-${order.id}`} className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-bold ${order.status === 'completed' ? 'border-emerald-900/50 bg-emerald-950/40 text-emerald-400' : order.status === 'rejected' ? 'border-red-900/50 bg-red-950/40 text-red-400' : order.status === 'in_progress' ? 'border-cyan-900/50 bg-cyan-950/40 text-cyan-400' : 'border-amber-900/50 bg-amber-950/40 text-amber-400'}`}>
              {order.status === 'new' ? 'nowe' : order.status === 'in_progress' ? 'w realizacji' : order.status === 'completed' ? 'gotowe' : order.status === 'rejected' ? 'odrzucone' : 'przypisane'}
            </span>
          </p>
          <p className="text-right text-lg font-semibold text-white">{formatPrice(order.finalPricePln)}</p>
        </div>
      ))}
    </div>
  );
}

function CallsTab({ callsQuery, activeCallId, setActiveCallId }: { callsQuery: ReturnType<typeof useListCalls>, activeCallId: number | null, setActiveCallId: (id: number | null) => void }) {
  if (callsQuery.isLoading) return <div className="grid gap-3"><SkeletonBlock className="h-24" /><SkeletonBlock className="h-24" /></div>;
  if (callsQuery.isError) return <ErrorNotice message="Nie udało się pobrać historii rozmów." />;
  if (!callsQuery.data || !(callsQuery.data as Call[]).length) return <EmptyState title="Brak rozmów" body="Twoje nadchodzące lub przeszłe rozmowy ze specjalistami pojawią się tutaj." />;

  if (activeCallId) {
    return <CallRoom callId={activeCallId} onLeave={() => { setActiveCallId(null); window.history.replaceState({}, '', '/account'); }} />;
  }

  const callsData = callsQuery.data as Call[];
  const activeOrWaiting = callsData.filter((c: Call) => c.status === 'active' || c.status === 'waiting');
  const scheduled = callsData.filter((c: Call) => c.status === 'scheduled');
  const history = callsData.filter((c: Call) => c.status === 'ended' || c.status === 'cancelled');

  return (
    <div className="space-y-8">
      {activeOrWaiting.length > 0 && (
        <section>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-cyan-400 flex items-center gap-2"><div className="h-2 w-2 bg-cyan-500 rounded-full animate-pulse" /> Trwająca rozmowa</h3>
          <div className="grid gap-4">
            {activeOrWaiting.map((call: Call) => (
              <div key={call.id} className="rounded-3xl border border-cyan-900/50 bg-cyan-950/20 p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-5">
                <div>
                  <p className="text-lg font-semibold text-white">Połączenie dot. zamówienia #{call.orderId}</p>
                  <p className="mt-1 text-sm text-cyan-400/80">Status: {call.status === 'waiting' ? 'Ekspert na Ciebie czeka...' : 'Połączenie aktywne'}</p>
                </div>
                <button 
                  onClick={() => setActiveCallId(call.id)}
                  className="rounded-xl bg-cyan-500 px-6 py-3 font-bold text-slate-950 shadow-lg shadow-cyan-900/30 transition hover:-translate-y-0.5 hover:bg-cyan-400 flex items-center gap-2"
                >
                  <PlayCircle size={18} />
                  Dołącz do rozmowy
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {scheduled.length > 0 && (
        <section>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-500">Zaplanowane</h3>
          <div className="grid gap-4">
            {scheduled.map((call: Call) => (
              <div key={call.id} className="rounded-2xl border border-slate-800 bg-slate-900 p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="grid h-12 w-12 place-items-center rounded-xl bg-slate-800 text-cyan-400">
                    <Calendar size={20} />
                  </div>
                  <div>
                    <p className="font-semibold text-white">Zamówienie #{call.orderId}</p>
                    <p className="mt-1 text-sm text-slate-400">{formatDate(call.scheduledAt)}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setActiveCallId(call.id)}
                  className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-sm font-bold text-slate-300 transition hover:bg-slate-700 hover:text-white"
                >
                  Dołącz do poczekalni
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {history.length > 0 && (
        <section>
          <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-500">Historia</h3>
          <div className="grid gap-3">
            {history.map((call: Call) => (
              <div key={call.id} className="flex items-center justify-between rounded-xl border border-slate-800/50 bg-slate-900/30 p-4">
                <div>
                  <p className="font-medium text-slate-300">Zamówienie #{call.orderId}</p>
                  <p className="mt-1 text-xs text-slate-500">{formatDate(call.scheduledAt)}</p>
                </div>
                <span className={`text-xs font-bold uppercase ${call.status === 'ended' ? 'text-emerald-500' : 'text-slate-500'}`}>
                  {call.status === 'ended' ? 'Zakończona' : 'Anulowana'}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
