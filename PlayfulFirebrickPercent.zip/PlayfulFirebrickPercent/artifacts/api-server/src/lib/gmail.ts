import { and, desc, eq, or } from "drizzle-orm";
import { db, emailMessagesTable, emailThreadsTable, enqueueDiscordLog, notificationsTable, usersTable } from "@workspace/db";
import { logger } from "./logger";

const moduleName = "imapflow";
const parserModuleName = "mailparser";

function normalizedSubject(subject: string): string {
  return subject.replace(/^(re|fwd?):\s*/i, "").trim() || "(bez tematu)";
}

/** Imports only customer-originated plain text. Dependencies are loaded lazily so SMTP continues working without IMAP. */
export async function syncGmailInbox(): Promise<{ imported: number; skipped: number }> {
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_APP_PASSWORD;
  if (!user || !pass) throw new Error("SMTP credentials are not configured");
  const { ImapFlow } = (await import(moduleName)) as { ImapFlow: new (options: object) => any };
  const { simpleParser } = (await import(parserModuleName)) as { simpleParser: (source: Buffer) => Promise<any> };
  const client = new ImapFlow({
    host: process.env.IMAP_HOST ?? "imap.gmail.com",
    port: Number(process.env.IMAP_PORT ?? 993),
    secure: (process.env.IMAP_TLS ?? "true") !== "false",
    auth: { user, pass },
    logger: false,
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  });
  let imported = 0;
  let skipped = 0;
  try {
    await client.connect();
    const lock = await client.getMailboxLock(process.env.IMAP_MAILBOX ?? "INBOX");
    try {
      const messageCount = Number(client.mailbox?.exists ?? 0);
      const sequenceRange = messageCount > 500 ? `${messageCount - 499}:*` : "1:*";
      for await (const item of client.fetch(sequenceRange, { uid: true, source: true })) {
        const parsed = await simpleParser(item.source);
        const from = parsed.from?.value?.[0]?.address?.trim().toLowerCase();
        if (!from || from === user.trim().toLowerCase()) { skipped++; continue; }
        const messageId = typeof parsed.messageId === "string" ? parsed.messageId : null;
        const [duplicate] = await db.select({ id: emailMessagesTable.id }).from(emailMessagesTable).where(or(messageId ? eq(emailMessagesTable.messageId, messageId) : undefined, eq(emailMessagesTable.imapUid, item.uid))).limit(1);
        if (duplicate) { skipped++; continue; }
        const subject = normalizedSubject(parsed.subject ?? "(bez tematu)");
        const [customer] = await db.select().from(usersTable).where(eq(usersTable.email, from)).limit(1);
        const inReplyTo = typeof parsed.inReplyTo === "string" ? parsed.inReplyTo : null;
        let thread;
        if (inReplyTo) {
          const [referencedMessage] = await db
            .select({ threadId: emailMessagesTable.threadId })
            .from(emailMessagesTable)
            .where(eq(emailMessagesTable.messageId, inReplyTo))
            .limit(1);
          if (referencedMessage) {
            [thread] = await db
              .select()
              .from(emailThreadsTable)
              .where(eq(emailThreadsTable.id, referencedMessage.threadId))
              .limit(1);
          }
        }
        if (!thread) {
          [thread] = await db
            .select()
            .from(emailThreadsTable)
            .where(and(eq(emailThreadsTable.customerEmail, from), eq(emailThreadsTable.subject, subject)))
            .orderBy(desc(emailThreadsTable.lastMessageAt))
            .limit(1);
        }
        // Do not import unrelated messages from the connected Gmail inbox.
        if (!thread) { skipped++; continue; }
        const text = typeof parsed.text === "string" ? parsed.text.slice(0, 100_000) : "";
        await db.insert(emailMessagesTable).values({ threadId: thread.id, direction: "inbound", senderEmail: from, recipientEmail: user, subject, body: text, messageId, inReplyTo, imapUid: item.uid, sentAt: parsed.date instanceof Date ? parsed.date : new Date() });
        await db.update(emailThreadsTable).set({ status: "pending", lastMessageAt: new Date() }).where(eq(emailThreadsTable.id, thread.id));
        if (customer) await db.insert(notificationsTable).values({ userId: customer.id, type: "email_inbound", title: "Odebraliśmy Twoją wiadomość", body: subject, audible: false });
        const administrators = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.role, "admin"));
        if (administrators.length) {
          await db.insert(notificationsTable).values(
            administrators.map((administrator) => ({
              userId: administrator.id,
              type: "email_inbound",
              title: "Nowa wiadomość e-mail od klienta",
              body: `${from}: ${subject}`,
              audible: true,
            })),
          );
        }
        imported++;
        await enqueueDiscordLog("email_inbound", { title: "Odebrano odpowiedź e-mail", description: `Nadawca: ${from}; temat: ${subject.slice(0, 200)}` });
      }
    } finally { lock.release(); }
  } finally {
    await client.logout().catch((error: unknown) => logger.warn({ error }, "Gmail IMAP logout failed"));
  }
  return { imported, skipped };
}