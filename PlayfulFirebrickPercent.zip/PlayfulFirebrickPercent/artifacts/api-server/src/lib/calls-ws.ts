import type { Server } from "node:http";
import type { IncomingMessage } from "node:http";
import { WebSocketServer, WebSocket } from "ws";
import { and, eq, gt } from "drizzle-orm";
import { callEventsTable, db, enqueueDiscordLog, callsTable, ordersTable, sessionsTable, usersTable } from "@workspace/db";
import { hashValue } from "./sleex";

type Peer = WebSocket & { callId?: number; userId?: number; alive?: boolean };
const allowedTypes = new Set(["join", "presence", "offer", "answer", "ice", "mute", "hold", "camera", "leave", "end"]);
function cookieValue(header: string | undefined, name: string): string | undefined {
  return header?.split(";").map((item) => item.trim().split("=")).find(([key]) => key === name)?.slice(1).join("=");
}

export function attachCallSignaling(server: Server): void {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024, perMessageDeflate: false });
  const peers = new Map<number, Set<Peer>>();
  server.on("upgrade", (request, socket, head) => {
    const url = new URL(request.url ?? "/", "http://localhost");
    if (url.pathname !== "/api/calls/ws" || request.method !== "GET") { socket.destroy(); return; }
    const origin = request.headers.origin;
    if (origin && origin !== `http://${request.headers.host}` && origin !== `https://${request.headers.host}`) { socket.destroy(); return; }
    wss.handleUpgrade(request, socket, head, (ws) => wss.emit("connection", ws, request));
  });
  wss.on("connection", async (raw: WebSocket, request: IncomingMessage) => {
    const ws = raw as Peer;
    const url = new URL(request.url ?? "/", "http://localhost");
    const callId = Number(url.searchParams.get("callId"));
    const token = cookieValue(request.headers.cookie, "sleex_session");
    if (!Number.isInteger(callId) || !token) { ws.close(1008); return; }
    const [session] = await db.select({ user: usersTable }).from(sessionsTable).innerJoin(usersTable, eq(sessionsTable.userId, usersTable.id)).where(and(eq(sessionsTable.tokenHash, hashValue(token)), gt(sessionsTable.expiresAt, new Date()))).limit(1);
    const [call] = session && !session.user.banned ? await db.select({ ownerId: ordersTable.userId }).from(callsTable).innerJoin(ordersTable, eq(callsTable.orderId, ordersTable.id)).where(eq(callsTable.id, callId)).limit(1) : [];
    if (!session || !call || (session.user.role !== "admin" && call.ownerId !== session.user.id)) { ws.close(1008); return; }
    ws.callId = callId; ws.userId = session.user.id; ws.alive = true;
    const room = peers.get(callId) ?? new Set<Peer>();
    const hasPeer = room.size > 0;
    room.add(ws); peers.set(callId, room);
    void db.insert(callEventsTable).values({ callId, actorUserId: ws.userId, type: "join" });
    void enqueueDiscordLog("call_join", { title: "Dołączenie do rozmowy", description: `Rozmowa #${callId}; użytkownik #${ws.userId}` });
    const broadcast = (data: object, except?: Peer) => room.forEach((peer) => { if (peer !== except && peer.readyState === WebSocket.OPEN) peer.send(JSON.stringify(data)); });
    ws.send(JSON.stringify({ type: "presence", present: hasPeer, state: hasPeer ? "joined" : "waiting" }));
    broadcast({ type: "presence", present: true, userId: ws.userId, state: "joined" }, ws);
    ws.on("pong", () => { ws.alive = true; });
    let left = false;
    ws.on("message", (data, binary) => {
      if (binary || Buffer.byteLength(data.toString()) > 16 * 1024) { ws.close(1009); return; }
      let message: unknown; try { message = JSON.parse(data.toString()); } catch { ws.close(1007); return; }
      if (!message || typeof message !== "object" || !allowedTypes.has((message as { type?: string }).type ?? "")) { ws.close(1008); return; }
      const safe = message as Record<string, unknown>;
      const type = safe.type as string;
      if (type === "mute" || type === "hold" || type === "camera" || type === "leave") {
        const detail = typeof safe.enabled === "boolean" ? (safe.enabled ? "enabled" : "disabled") : "";
        void db.insert(callEventsTable).values({ callId, actorUserId: ws.userId, type, detail });
        if (type === "leave") left = true;
        if (type === "camera") void enqueueDiscordLog("call_camera", { title: "Zmiana kamery", description: `Rozmowa #${callId}; użytkownik #${ws.userId}; ${detail === "enabled" ? "włączono" : "wyłączono"}` });
        if (type === "leave") void enqueueDiscordLog("call_leave", { title: "Opuszczenie rozmowy", description: `Rozmowa #${callId}; użytkownik #${ws.userId}` });
      }
      broadcast({ ...safe, userId: ws.userId }, ws);
    });
    let disconnected = false;
    ws.on("close", () => { if (disconnected) return; disconnected = true; room.delete(ws); if (!left) { void db.insert(callEventsTable).values({ callId, actorUserId: ws.userId, type: "disconnect" }); void enqueueDiscordLog("call_leave", { title: "Rozłączenie z rozmową", description: `Rozmowa #${callId}; użytkownik #${ws.userId}` }); } broadcast({ type: "presence", present: false, userId: ws.userId, state: "left" }); if (!room.size) peers.delete(callId); });
  });
  const timer = setInterval(() => wss.clients.forEach((client) => { const ws = client as Peer; if (!ws.alive) return ws.terminate(); ws.alive = false; ws.ping(); }), 30_000);
  wss.on("close", () => clearInterval(timer));
}