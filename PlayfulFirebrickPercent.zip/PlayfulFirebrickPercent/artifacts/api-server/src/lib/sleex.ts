import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { and, eq, gt } from "drizzle-orm";
import { db, sessionsTable, usersTable } from "@workspace/db";

export type CurrentUser = typeof usersTable.$inferSelect;

const SESSION_COOKIE = "sleex_session";

export function hashValue(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export async function getCurrentUser(req: Request): Promise<CurrentUser | null> {
  const rawToken = req.cookies?.[SESSION_COOKIE] as string | undefined;
  if (!rawToken) return null;

  const [session] = await db
    .select({ user: usersTable })
    .from(sessionsTable)
    .innerJoin(usersTable, eq(sessionsTable.userId, usersTable.id))
    .where(
      and(
        eq(sessionsTable.tokenHash, hashValue(rawToken)),
        gt(sessionsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  return session?.user ?? null;
}

export function setSessionCookie(res: Response, token: string, expiresAt: Date): void {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
    path: "/",
  });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: "lax", path: "/" });
}

export function newToken(): string {
  return randomBytes(32).toString("hex");
}

export function isAdmin(user: CurrentUser | null): boolean {
  return user?.role === "admin";
}

export function isBanned(user: CurrentUser | null): boolean {
  return Boolean(user?.banned && !isAdmin(user));
}

export function configuredAdminEmail(email: string): boolean {
  const configured = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  return email.toLowerCase() === (configured || "admin@sleex.pl");
}