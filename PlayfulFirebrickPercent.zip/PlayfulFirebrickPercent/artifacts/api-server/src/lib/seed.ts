import { eq } from "drizzle-orm";
import { db, promotionsTable, servicesTable } from "@workspace/db";

export async function seedDatabase(): Promise<void> {
  const existingServices = await db.select({ id: servicesTable.id }).from(servicesTable).limit(1);
  if (existingServices.length === 0) {
    await db.insert(servicesTable).values([
      {
        name: "Konsultacja z algorytmiki",
        description: "Indywidualne spotkanie online z analizą problemu, wskazówkami i planem dalszej nauki.",
        pricePln: 89,
        published: true,
      },
      {
        name: "Pomoc w projekcie webowym",
        description: "Praktyczne wsparcie przy HTML, CSS, JavaScript i React — od błędu do działającego rozwiązania.",
        pricePln: 149,
        published: true,
      },
      {
        name: "Matematyka bez stresu",
        description: "Jasne wyjaśnienia zadań i przygotowanie do sprawdzianu lub matury krok po kroku.",
        pricePln: 79,
        published: true,
      },
    ]);
  }

  const [starterPromotion] = await db
    .select({ id: promotionsTable.id })
    .from(promotionsTable)
    .where(eq(promotionsTable.code, "START10"))
    .limit(1);
  if (!starterPromotion) {
    await db.insert(promotionsTable).values({
      code: "START10",
      discountPercent: 10,
      usageLimit: 100,
      usedCount: 0,
      active: true,
    });
  }
}