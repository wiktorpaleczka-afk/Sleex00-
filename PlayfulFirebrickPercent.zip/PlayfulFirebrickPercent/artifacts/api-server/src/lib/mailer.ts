import nodemailer from "nodemailer";

export function isSmtpConfigured(): boolean {
  return Boolean(process.env.SMTP_USER && process.env.SMTP_APP_PASSWORD);
}

export async function sendMail(input: {
  to: string;
  subject: string;
  text: string;
  html?: string;
  inReplyTo?: string | null;
  references?: string | null;
}): Promise<string | null> {
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_APP_PASSWORD;
  if (!user || !pass) {
    throw new Error("SMTP is not configured");
  }

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user, pass },
  });
  const info = await transporter.sendMail({
    from: `"Sleex Usługi" <${user}>`,
    to: input.to,
    subject: input.subject,
    text: input.text,
    html: input.html ?? brandedEmail(input.subject, input.text),
    inReplyTo: input.inReplyTo ?? undefined,
    references: input.references ?? undefined,
  });
  return typeof info.messageId === "string" ? info.messageId : null;
}

export function brandedEmail(title: string, body: string, action?: { label: string; url: string }): string {
  const escape = (value: string) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  const safeActionUrl = action && /^https?:\/\//.test(action.url) ? escape(action.url) : null;
  const actionHtml = action && safeActionUrl
    ? `<div style="margin-top:26px"><a href="${safeActionUrl}" style="display:inline-block;padding:13px 20px;border-radius:11px;background:#08b7d4;color:#041126;text-decoration:none;font-weight:800">${escape(action.label)}</a></div>`
    : "";
  return `<!doctype html><html><body style="margin:0;background:#06172d;color:#eaf8ff;font-family:Arial,sans-serif"><div style="padding:42px 16px;background:radial-gradient(circle at 85% 0,#0bc9e8 0,transparent 28%),linear-gradient(135deg,#041126,#082c4e)"><div style="max-width:580px;margin:auto;border:1px solid #167c9a;border-radius:22px;overflow:hidden;background:#071d35;box-shadow:0 18px 45px #010916"><div style="padding:28px 32px;background:linear-gradient(90deg,#07335b,#0aa9c8)"><div style="font-size:25px;font-weight:800;letter-spacing:.5px">SLEEX <span style="color:#bdf7ff">USŁUGI</span></div><div style="font-size:11px;letter-spacing:2px;margin-top:5px;color:#d1fbff">CYFROWE WSPARCIE</div></div><div style="padding:32px"><h1 style="font-size:22px;margin:0 0 18px;color:#fff">${escape(title)}</h1><div style="white-space:pre-wrap;line-height:1.65;color:#d9eef8">${escape(body)}</div>${actionHtml}</div><div style="padding:16px 32px;color:#7ccddd;font-size:12px;border-top:1px solid #123c59">Sleex Usługi · bezpieczna komunikacja z zespołem</div></div></div></body></html>`;
}