import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { getCurrentUser, isBanned } from "./lib/sleex";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(async (req, res, next) => {
  const user = await getCurrentUser(req);
  const allowedWhenBanned = req.path === "/api/auth/session" || req.path === "/api/auth/logout" || req.path === "/api/notifications" || /^\/api\/notifications\/\d+\/read$/.test(req.path);
  if (isBanned(user) && !allowedWhenBanned) {
    res.status(403).json({ error: "Twoje konto jest zablokowane. Dostępne są tylko powiadomienia i wylogowanie." });
    return;
  }
  next();
});

app.use("/api", router);

export default app;
