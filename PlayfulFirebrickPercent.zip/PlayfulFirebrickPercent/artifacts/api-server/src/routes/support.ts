import { Router, type IRouter, type Request, type Response } from "express";
import { and, asc, desc, eq } from "drizzle-orm";
import { db, supportMessagesTable, supportTicketsTable } from "@workspace/db";
import {
  BanSupportUserParams,
  BanSupportUserResponse,
  CreateSupportTicketBody,
  CreateSupportTicketResponse,
  DeleteSupportTicketParams,
  GetSupportTicketParams,
  GetSupportTicketResponse,
  JoinSupportChatParams,
  JoinSupportChatResponse,
  LeaveSupportChatParams,
  LeaveSupportChatResponse,
  ListSupportTicketsResponse,
  SendSupportMessageBody,
  SendSupportMessageParams,
  SendSupportMessageResponse,
} from "@workspace/api-zod";
import { getCurrentUser, hashValue, isAdmin, isBanned, newToken } from "../lib/sleex";

const router: IRouter = Router();

function ticketCookieName(ticketId: number): string {
  return `sleex_ticket_${ticketId}`;
}

function hasTicketAccess(req: Request, ticket: typeof supportTicketsTable.$inferSelect): boolean {
  const token = req.cookies?.[ticketCookieName(ticket.id)] as string | undefined;
  return Boolean(token && ticket.accessTokenHash && hashValue(token) === ticket.accessTokenHash);
}

async function withMessages(ticket: typeof supportTicketsTable.$inferSelect) {
  const messages = await db
    .select()
    .from(supportMessagesTable)
    .where(eq(supportMessagesTable.ticketId, ticket.id))
    .orderBy(asc(supportMessagesTable.createdAt));
  return {
    id: ticket.id,
    email: ticket.email,
    subject: ticket.subject,
    message: ticket.message,
    status: ticket.banned ? "banned" : ticket.status,
    adminJoined: ticket.adminJoined,
    createdAt: ticket.createdAt,
    messages,
  };
}

async function listTicketsForUser(userId: number) {
  const tickets = await db
    .select()
    .from(supportTicketsTable)
    .where(eq(supportTicketsTable.userId, userId))
    .orderBy(desc(supportTicketsTable.createdAt));
  return Promise.all(tickets.map(withMessages));
}

router.get("/support/tickets", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (isBanned(user)) {
    res.status(403).json({ error: "Twoje konto jest zablokowane." });
    return;
  }
  if (!user) {
    res.status(401).json({ error: "Zaloguj się, aby zobaczyć swoje zgłoszenia." });
    return;
  }
  res.json(ListSupportTicketsResponse.parse(await listTicketsForUser(user.id)));
});

router.post("/support/tickets", async (req, res): Promise<void> => {
  const parsed = CreateSupportTicketBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const user = await getCurrentUser(req);
  if (isBanned(user)) {
    res.status(403).json({ error: "Twoje konto jest zablokowane." });
    return;
  }
  const accessToken = newToken();
  const [ticket] = await db
    .insert(supportTicketsTable)
    .values({
      userId: user?.id ?? null,
      email: parsed.data.email.trim().toLowerCase(),
      subject: parsed.data.subject,
      message: parsed.data.message,
      status: "waiting",
      adminJoined: false,
      banned: false,
      accessTokenHash: hashValue(accessToken),
    })
    .returning();
  if (!ticket) {
    res.status(500).json({ error: "Nie udało się utworzyć zgłoszenia." });
    return;
  }
  await db.insert(supportMessagesTable).values({
    ticketId: ticket.id,
    sender: "customer",
    body: ticket.message,
  });
  res.cookie(ticketCookieName(ticket.id), accessToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 30 * 24 * 60 * 60 * 1000,
    path: "/",
  });
  res.status(201).json(CreateSupportTicketResponse.parse(await withMessages(ticket)));
});

router.get("/support/tickets/:ticketId", async (req, res): Promise<void> => {
  const params = GetSupportTicketParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [ticket] = await db
    .select()
    .from(supportTicketsTable)
    .where(eq(supportTicketsTable.id, params.data.ticketId))
    .limit(1);
  if (!ticket) {
    res.status(404).json({ error: "Nie znaleziono zgłoszenia." });
    return;
  }
  const user = await getCurrentUser(req);
  if (!user && !hasTicketAccess(req, ticket)) {
    res.status(401).json({ error: "Otwórz zgłoszenie z urządzenia, na którym zostało utworzone." });
    return;
  }
  if (user && (ticket.userId !== user.id && !isAdmin(user)) && !hasTicketAccess(req, ticket)) {
    res.status(403).json({ error: "Brak dostępu do tego zgłoszenia." });
    return;
  }
  res.json(GetSupportTicketResponse.parse(await withMessages(ticket)));
});

router.post("/support/tickets/:ticketId/messages", async (req, res): Promise<void> => {
  const params = SendSupportMessageParams.safeParse(req.params);
  const parsed = SendSupportMessageBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [ticket] = await db
    .select()
    .from(supportTicketsTable)
    .where(eq(supportTicketsTable.id, params.data.ticketId))
    .limit(1);
  const user = await getCurrentUser(req);
  if (!ticket || (!user && !hasTicketAccess(req, ticket)) || (user && ticket.userId !== user.id && !isAdmin(user) && !hasTicketAccess(req, ticket))) {
    res.status(403).json({ error: "Brak dostępu do tego czatu." });
    return;
  }
  if (ticket.banned) {
    res.status(403).json({ error: "To konto zostało zablokowane na tej stronie." });
    return;
  }
  const [message] = await db
    .insert(supportMessagesTable)
    .values({
      ticketId: ticket.id,
      sender: isAdmin(user) ? "admin" : "customer",
      body: parsed.data.body,
    })
    .returning();
  res.status(201).json(SendSupportMessageResponse.parse(message));
});

async function updateTicketAction(
  req: Request,
  res: Response,
  action: "join" | "leave" | "ban",
): Promise<void> {
  const user = await getCurrentUser(req);
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Dostęp tylko dla administratora." });
    return;
  }
  const schema = action === "join" ? JoinSupportChatParams : action === "leave" ? LeaveSupportChatParams : BanSupportUserParams;
  const params = schema.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const ticketId = params.data.ticketId;
  const [updated] = await db
    .update(supportTicketsTable)
    .set(
      action === "join"
        ? { adminJoined: true, status: "active" }
        : action === "leave"
          ? { adminJoined: false, status: "waiting" }
          : { banned: true, status: "banned" },
    )
    .where(eq(supportTicketsTable.id, ticketId))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Nie znaleziono zgłoszenia." });
    return;
  }
  const responseSchema =
    action === "join" ? JoinSupportChatResponse : action === "leave" ? LeaveSupportChatResponse : BanSupportUserResponse;
  res.json(responseSchema.parse(await withMessages(updated)));
}

router.post("/support/tickets/:ticketId/join", (req, res) => void updateTicketAction(req, res, "join"));
router.post("/support/tickets/:ticketId/leave", (req, res) => void updateTicketAction(req, res, "leave"));
router.post("/support/tickets/:ticketId/ban", (req, res) => void updateTicketAction(req, res, "ban"));

router.delete("/support/tickets/:ticketId", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Dostęp tylko dla administratora." });
    return;
  }
  const params = DeleteSupportTicketParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(supportTicketsTable)
    .where(eq(supportTicketsTable.id, params.data.ticketId))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Nie znaleziono zgłoszenia." });
    return;
  }
  await db.delete(supportMessagesTable).where(eq(supportMessagesTable.ticketId, deleted.id));
  res.status(204).send();
});

export { listTicketsForUser, withMessages };
export default router;