import { Router, type IRouter, type Request, type Response } from "express";
import { and, desc, eq, ilike, sql } from "drizzle-orm";
import { db, emailMessagesTable, emailThreadsTable, enqueueDiscordLog, moderationHistoryTable, notificationsTable, orderEventsTable, ordersTable, promotionsTable, servicesTable, sessionsTable, supportTicketsTable, usersTable } from "@workspace/db";
import {
  CreatePromotionBody,
  CreatePromotionResponse,
  GetAdminOverviewResponse,
  ListAdminSupportTicketsResponse,
  ListPromotionsResponse,
  SendCustomEmailBody,
  SendCustomEmailResponse,
  ValidatePromotionBody,
  ValidatePromotionResponse,
  GetEmailThreadParams,
  GetEmailThreadResponse,
  ListAdminUsersQueryParams,
  ListAdminUsersResponse,
  ListEmailThreadsResponse,
  ReplyEmailThreadBody,
  ReplyEmailThreadParams,
  ReplyEmailThreadResponse,
  SyncGmailInboxResponse,
  WarnAdminUserBody,
  WarnAdminUserParams,
  WarnAdminUserResponse,
  BanAdminUserBody,
  BanAdminUserParams,
  BanAdminUserResponse,
  UnbanAdminUserParams,
  UnbanAdminUserResponse,
  ClaimOrderParams, ClaimOrderResponse, CompleteOrderParams, CompleteOrderResponse, GetAdminOrderParams, GetAdminOrderResponse, ListAdminOrdersQueryParams, ListAdminOrdersResponse, RejectOrderBody, RejectOrderParams, RejectOrderResponse, StartOrderParams, StartOrderResponse,
} from "@workspace/api-zod";
import { brandedEmail, isSmtpConfigured, sendMail } from "../lib/mailer";
import { getCurrentUser, isAdmin } from "../lib/sleex";
import { orderDetail, readOrders } from "./orders";
import { withMessages } from "./support";
import { syncGmailInbox } from "../lib/gmail";

const router: IRouter = Router();

function userEntity(user: typeof usersTable.$inferSelect) {
  return { id: user.id, email: user.email, role: user.role === "admin" ? "admin" : "customer", banned: user.banned, banReason: user.banReason, bannedAt: user.bannedAt, unbannedAt: user.unbannedAt, createdAt: user.createdAt };
}

async function emailThreadEntity(thread: typeof emailThreadsTable.$inferSelect) {
  const messages = await db.select().from(emailMessagesTable).where(eq(emailMessagesTable.threadId, thread.id)).orderBy(desc(emailMessagesTable.sentAt));
  return { ...thread, messages: messages.reverse().map(({ imapUid: _imapUid, createdAt: _createdAt, ...message }) => message) };
}

async function requireAdmin(req: Request, res: Response): Promise<boolean> {
  const user = await getCurrentUser(req);
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Dostęp tylko dla administratora." });
    return false;
  }
  return true;
}

router.get("/promotions", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const promotions = await db.select().from(promotionsTable).orderBy(desc(promotionsTable.createdAt));
  res.json(ListPromotionsResponse.parse(promotions));
});

router.post("/promotions", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const parsed = CreatePromotionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [promotion] = await db
    .insert(promotionsTable)
    .values({
      code: parsed.data.code.trim().toUpperCase(),
      discountPercent: parsed.data.discountPercent,
      usageLimit: parsed.data.usageLimit,
    })
    .returning();
  if (!promotion) {
    res.status(500).json({ error: "Nie udało się utworzyć kodu." });
    return;
  }
  res.status(201).json(CreatePromotionResponse.parse(promotion));
});

router.post("/promotions/validate", async (req, res): Promise<void> => {
  const parsed = ValidatePromotionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [promotion] = await db
    .select()
    .from(promotionsTable)
    .where(
      and(
        eq(promotionsTable.code, parsed.data.code.trim().toUpperCase()),
        eq(promotionsTable.active, true),
        sql`${promotionsTable.usedCount} < ${promotionsTable.usageLimit}`,
      ),
    )
    .limit(1);
  res.json(
    ValidatePromotionResponse.parse(
      promotion
        ? {
            valid: true,
            code: promotion.code,
            discountPercent: promotion.discountPercent,
            message: `Kod aktywny: -${promotion.discountPercent}%`,
          }
        : { valid: false, code: null, discountPercent: null, message: "Kod jest nieprawidłowy lub wykorzystany." },
    ),
  );
});

router.get("/admin/overview", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const [services] = await db.select({ count: sql<number>`count(*)` }).from(servicesTable);
  const [tickets] = await db
    .select({ count: sql<number>`count(*)` })
    .from(supportTicketsTable)
    .where(eq(supportTicketsTable.status, "waiting"));
  const orders = await readOrders();
  const [promos] = await db.select({ count: sql<number>`coalesce(sum(${promotionsTable.usedCount}), 0)` }).from(promotionsTable);
  res.json(
    GetAdminOverviewResponse.parse({
      serviceCount: Number(services?.count ?? 0),
      openTickets: Number(tickets?.count ?? 0),
      newOrders: orders.filter((order) => order.status === "new").length,
      promoRedemptions: Number(promos?.count ?? 0),
      recentOrders: orders.slice(0, 5),
    }),
  );
});

router.post("/admin/emails", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const parsed = SendCustomEmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const messageId = await sendMail({
      to: parsed.data.recipient,
      subject: parsed.data.subject,
      text: parsed.data.body,
      html: brandedEmail(parsed.data.subject, parsed.data.body),
    });
    res.locals.outboundMessageId = messageId;
  } catch (error) {
    req.log.error({ error }, "Failed to send custom email");
    res.status(503).json({ error: "SMTP nie jest jeszcze skonfigurowane." });
    return;
  }
  const recipient = parsed.data.recipient.trim().toLowerCase();
  const [recipientUser] = await db.select().from(usersTable).where(eq(usersTable.email, recipient)).limit(1);
  const [thread] = await db
    .insert(emailThreadsTable)
    .values({ userId: recipientUser?.id ?? null, customerEmail: recipient, subject: parsed.data.subject, status: "replied" })
    .onConflictDoNothing()
    .returning();
  const emailThread = thread ?? (await db.select().from(emailThreadsTable).where(and(eq(emailThreadsTable.customerEmail, recipient), eq(emailThreadsTable.subject, parsed.data.subject))).limit(1))[0];
  if (emailThread) {
    await db.insert(emailMessagesTable).values({ threadId: emailThread.id, direction: "outbound", senderEmail: process.env.SMTP_USER ?? "admin@sleex.pl", recipientEmail: recipient, subject: parsed.data.subject, body: parsed.data.body, messageId: res.locals.outboundMessageId ?? null });
    await db.update(emailThreadsTable).set({ status: "replied", lastMessageAt: new Date() }).where(eq(emailThreadsTable.id, emailThread.id));
  }
  await enqueueDiscordLog("email_outbound", { title: "Wysłano e-mail", description: `Odbiorca: ${recipient}; temat: ${parsed.data.subject.slice(0, 200)}` });
  res.status(202).json(SendCustomEmailResponse.parse({ sent: true, message: "Wiadomość została wysłana." }));
});

router.get("/admin/emails", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const threads = await db.select().from(emailThreadsTable).orderBy(desc(emailThreadsTable.lastMessageAt));
  res.json(ListEmailThreadsResponse.parse(await Promise.all(threads.map(emailThreadEntity))));
});

router.get("/admin/emails/:threadId", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const params = GetEmailThreadParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [thread] = await db.select().from(emailThreadsTable).where(eq(emailThreadsTable.id, params.data.threadId)).limit(1);
  if (!thread) { res.status(404).json({ error: "Nie znaleziono wątku wiadomości." }); return; }
  res.json(GetEmailThreadResponse.parse(await emailThreadEntity(thread)));
});

router.post("/admin/emails/:threadId/reply", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const params = ReplyEmailThreadParams.safeParse(req.params);
  const parsed = ReplyEmailThreadBody.safeParse(req.body);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [thread] = await db.select().from(emailThreadsTable).where(eq(emailThreadsTable.id, params.data.threadId)).limit(1);
  if (!thread) { res.status(404).json({ error: "Nie znaleziono wątku wiadomości." }); return; }
  const [latest] = await db.select().from(emailMessagesTable).where(eq(emailMessagesTable.threadId, thread.id)).orderBy(desc(emailMessagesTable.sentAt)).limit(1);
  const subject = thread.subject.toLowerCase().startsWith("re:") ? thread.subject : `Re: ${thread.subject}`;
  let outboundMessageId: string | null = null;
  try {
    outboundMessageId = await sendMail({ to: thread.customerEmail, subject, text: parsed.data.body, html: brandedEmail(subject, parsed.data.body), inReplyTo: latest?.messageId, references: latest?.messageId ?? latest?.inReplyTo });
  } catch (error) { req.log.error({ error }, "Failed to send email reply"); res.status(503).json({ error: "Nie udało się wysłać odpowiedzi e-mail." }); return; }
  const sender = process.env.SMTP_USER ?? "admin@sleex.pl";
  const [message] = await db.insert(emailMessagesTable).values({ threadId: thread.id, direction: "outbound", senderEmail: sender, recipientEmail: thread.customerEmail, subject, body: parsed.data.body, messageId: outboundMessageId, inReplyTo: latest?.messageId ?? null }).returning();
  await db.update(emailThreadsTable).set({ status: "replied", lastMessageAt: new Date() }).where(eq(emailThreadsTable.id, thread.id));
  if (thread.userId) await db.insert(notificationsTable).values({ userId: thread.userId, type: "email_reply", title: "Nowa odpowiedź od Sleex", body: subject, audible: true });
  await enqueueDiscordLog("email_replied", { title: "Odpowiedziano na e-mail", description: `Odbiorca: ${thread.customerEmail}; temat: ${subject.slice(0, 200)}` });
  res.status(202).json(ReplyEmailThreadResponse.parse(message));
});

router.post("/admin/emails/sync", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  try {
    res.json(SyncGmailInboxResponse.parse(await syncGmailInbox()));
  } catch (error) {
    req.log.error({ error }, "Gmail inbox synchronization failed");
    res.status(503).json({ error: "Nie udało się zsynchronizować skrzynki Gmail. Sprawdź konfigurację IMAP." });
  }
});

router.get("/admin/users", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const query = ListAdminUsersQueryParams.safeParse(req.query);
  if (!query.success) { res.status(400).json({ error: query.error.message }); return; }
  const users = await db.select().from(usersTable).where(query.data.search ? ilike(usersTable.email, `%${query.data.search}%`) : undefined).orderBy(desc(usersTable.createdAt));
  res.json(ListAdminUsersResponse.parse(users.map(userEntity)));
});

async function moderateUser(req: Request, res: Response, action: "warning" | "ban" | "unban"): Promise<void> {
  if (!(await requireAdmin(req, res))) return;
  const params = (action === "warning" ? WarnAdminUserParams : action === "ban" ? BanAdminUserParams : UnbanAdminUserParams).safeParse(req.params);
  const body = action === "unban" ? { success: true, data: { reason: null } } : (action === "warning" ? WarnAdminUserBody : BanAdminUserBody).safeParse(req.body);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  if (!body.success) { res.status(400).json({ error: "Podaj poprawny powód moderacji." }); return; }
  const actor = await getCurrentUser(req);
  const reason = body.data.reason;
  const [user] = await db.update(usersTable).set(action === "ban" ? { banned: true, banReason: reason, bannedAt: new Date() } : action === "unban" ? { banned: false, banReason: null, unbannedAt: new Date() } : {}).where(eq(usersTable.id, params.data.userId)).returning();
  if (!user) { res.status(404).json({ error: "Nie znaleziono użytkownika." }); return; }
  if (action === "ban") await db.delete(sessionsTable).where(eq(sessionsTable.userId, user.id));
  await db.insert(moderationHistoryTable).values({ userId: user.id, adminUserId: actor?.id ?? null, action, reason });
  await db.insert(notificationsTable).values({ userId: user.id, type: action === "warning" ? "warning" : action, title: action === "warning" ? "Ostrzeżenie od administracji" : action === "ban" ? "Konto zostało zablokowane" : "Konto zostało odblokowane", body: reason ?? "Administracja zmieniła status Twojego konta.", audible: true });
  const schema = action === "warning" ? WarnAdminUserResponse : action === "ban" ? BanAdminUserResponse : UnbanAdminUserResponse;
  res.json(schema.parse(userEntity(user)));
}
router.post("/admin/users/:userId/warn", (req, res) => void moderateUser(req, res, "warning"));
router.post("/admin/users/:userId/ban", (req, res) => void moderateUser(req, res, "ban"));
router.post("/admin/users/:userId/unban", (req, res) => void moderateUser(req, res, "unban"));

router.get("/admin/support/tickets", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const tickets = await db.select().from(supportTicketsTable).orderBy(desc(supportTicketsTable.createdAt));
  res.json(ListAdminSupportTicketsResponse.parse(await Promise.all(tickets.map(withMessages))));
});

router.get("/admin/orders", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const query = ListAdminOrdersQueryParams.safeParse(req.query);
  if (!query.success) { res.status(400).json({ error: "Nieprawidłowe filtry." }); return; }
  const orders = await readOrders();
  const status = query.data.status?.trim() || undefined;
  const search = query.data.search?.trim().toLowerCase() || undefined;
  const filtered = orders.filter((order) => (!status || order.status === status) && (!search || `${order.trackingId} ${order.email} ${order.serviceName}`.toLowerCase().includes(search)));
  res.json(ListAdminOrdersResponse.parse(filtered));
});
router.get("/admin/orders/:orderId", async (req, res): Promise<void> => {
  if (!(await requireAdmin(req, res))) return;
  const params = GetAdminOrderParams.safeParse(req.params); if (!params.success) { res.status(400).json({ error: "Nieprawidłowy identyfikator zamówienia." }); return; }
  const order = await orderDetail(params.data.orderId, 0, true); if (!order) { res.status(404).json({ error: "Nie znaleziono zamówienia." }); return; }
  res.json(GetAdminOrderResponse.parse(order));
});
async function changeOrder(req: Request, res: Response, action: "claim" | "in_progress" | "completed" | "rejected"): Promise<void> {
  if (!(await requireAdmin(req, res))) return;
  const schema = action === "claim" ? ClaimOrderParams : action === "in_progress" ? StartOrderParams : action === "completed" ? CompleteOrderParams : RejectOrderParams;
  const params = schema.safeParse(req.params); const body = action === "rejected" ? RejectOrderBody.safeParse(req.body) : null;
  if (!params.success || (body && !body.success)) { res.status(400).json({ error: action === "rejected" ? "Podaj poprawny powód odrzucenia." : "Nieprawidłowy identyfikator zamówienia." }); return; }
  const actor = await getCurrentUser(req); const id = params.data.orderId; const [current] = await db.select().from(ordersTable).where(eq(ordersTable.id, id)).limit(1);
  const allowed = action === "claim" ? current?.status === "new" && !current.assignedAdminId : action === "in_progress" ? current?.status === "claimed" && current.assignedAdminId === actor!.id : action === "completed" ? current?.status === "in_progress" && current.assignedAdminId === actor!.id : ["new", "claimed"].includes(current?.status ?? "");
  if (!allowed) { res.status(409).json({ error: "Ta zmiana statusu jest niedozwolona." }); return; }
  const now = new Date();
  const status = action === "claim" ? "claimed" : action;
  const patch = action === "claim" ? { status, assignedAdminId: actor!.id, claimedAt: now } : action === "in_progress" ? { status, inProgressAt: now } : action === "completed" ? { status, completedAt: now } : { status, rejectedAt: now, rejectionReason: body!.data.reason };
  const [order] = await db.update(ordersTable).set(patch).where(and(eq(ordersTable.id, id), eq(ordersTable.status, current!.status))).returning();
  if (!order) { res.status(409).json({ error: "Zamówienie zostało już przejęte lub zmienione." }); return; }
  await db.insert(orderEventsTable).values({ orderId: id, actorUserId: actor!.id, type: action, fromStatus: current!.status, toStatus: status, note: action === "rejected" ? body!.data.reason : null });
  await enqueueDiscordLog("order_status_changed", { title: "Zmiana statusu zamówienia", fields: [{ name: "Numer śledzenia", value: order.trackingId }, { name: "Status", value: status }, { name: "Administrator", value: String(actor!.id) }] });
  await db.insert(notificationsTable).values({ userId: order.userId, type: `order_${status}`, title: "Status zamówienia zmieniony", body: `Zamówienie ${order.trackingId}: ${status}`, audible: true });
  const detail = await orderDetail(id, 0, true); const response = action === "claim" ? ClaimOrderResponse : action === "in_progress" ? StartOrderResponse : action === "completed" ? CompleteOrderResponse : RejectOrderResponse;
  if (detail && isSmtpConfigured()) {
    const labels = { claim: "przejęte przez specjalistę", in_progress: "w realizacji", completed: "zakończone", rejected: "odrzucone" } as const;
    const statusUrl = `${req.get("x-forwarded-proto")?.split(",")[0]?.trim() || req.protocol}://${req.get("host")}/status-zamowienia?id=${order.trackingId}`;
    const text = `Zamówienie ${order.trackingId} ma nowy status: ${labels[action]}.${order.rejectionReason ? `\nPowód: ${order.rejectionReason}` : ""}\n\nUsługa: ${detail.serviceName}\nKwota: ${detail.finalPricePln.toFixed(2)} PLN\nStatus: ${statusUrl}`;
    void sendMail({ to: detail.email, subject: `Sleex — status zamówienia ${order.trackingId}`, text, html: brandedEmail("Status zamówienia został zmieniony", text, { label: "Zobacz szczegóły zamówienia", url: statusUrl }) }).then(() => enqueueDiscordLog("email_outbound", { title: "Wysłano e-mail o statusie", description: `Zamówienie: ${order.trackingId}` })).catch(() => undefined);
  }
  const entity = (await readOrders()).find((item) => item.id === id);
  res.json(response.parse(entity));
}
router.post("/admin/orders/:orderId/claim", (req, res): Promise<void> => changeOrder(req, res, "claim"));
router.post("/admin/orders/:orderId/in-progress", (req, res): Promise<void> => changeOrder(req, res, "in_progress"));
router.post("/admin/orders/:orderId/complete", (req, res): Promise<void> => changeOrder(req, res, "completed"));
router.post("/admin/orders/:orderId/reject", (req, res): Promise<void> => changeOrder(req, res, "rejected"));

export default router;