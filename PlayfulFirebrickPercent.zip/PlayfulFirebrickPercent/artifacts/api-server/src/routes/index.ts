import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import servicesRouter from "./services";
import ordersRouter from "./orders";
import supportRouter from "./support";
import adminRouter from "./admin";
import storageRouter from "./storage";
import notificationsRouter from "./notifications";
import callsRouter from "./calls";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(servicesRouter);
router.use(ordersRouter);
router.use(supportRouter);
router.use(adminRouter);
router.use(storageRouter);
router.use(notificationsRouter);
router.use(callsRouter);

export default router;
