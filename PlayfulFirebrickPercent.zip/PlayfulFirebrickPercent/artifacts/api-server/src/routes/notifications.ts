import { Router, type IRouter } from "express";
import { and, desc, eq } from "drizzle-orm";
import { db, notificationsTable } from "@workspace/db";
import {
  ListNotificationsResponse,
  MarkNotificationReadParams,
  MarkNotificationReadResponse,
} from "@workspace/api-zod";
import { getCurrentUser } from "../lib/sleex";

const router: IRouter = Router();

router.get("/notifications", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!user) {
    res.status(401).json({ error: "Zaloguj się, aby zobaczyć powiadomienia." });
    return;
  }
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, user.id))
    .orderBy(desc(notificationsTable.createdAt));
  res.json(ListNotificationsResponse.parse(notifications));
});

router.post("/notifications/:notificationId/read", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  const params = MarkNotificationReadParams.safeParse(req.params);
  if (!user) {
    res.status(401).json({ error: "Zaloguj się, aby oznaczyć powiadomienie." });
    return;
  }
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [notification] = await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(and(eq(notificationsTable.id, params.data.notificationId), eq(notificationsTable.userId, user.id)))
    .returning();
  if (!notification) {
    res.status(404).json({ error: "Nie znaleziono powiadomienia." });
    return;
  }
  res.json(MarkNotificationReadResponse.parse(notification));
});

export default router;