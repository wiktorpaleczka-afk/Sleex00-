import { randomInt, timingSafeEqual } from "node:crypto";
import { Router, type IRouter } from "express";
import { and, desc, eq, gt } from "drizzle-orm";
import { db, otpCodesTable, sessionsTable, usersTable } from "@workspace/db";
import {
  GetSessionResponse,
  AdminLoginBody,
  LogoutResponse,
  RequestOtpBody,
  RequestOtpResponse,
  VerifyOtpBody,
  VerifyOtpResponse,
} from "@workspace/api-zod";
import {
  clearSessionCookie,
  configuredAdminEmail,
  getCurrentUser,
  hashValue,
  isAdmin,
  newToken,
  setSessionCookie,
} from "../lib/sleex";
import { brandedEmail, isSmtpConfigured, sendMail } from "../lib/mailer";

const router: IRouter = Router();
const OTP_TTL_SECONDS = 600;

function secureEqual(actual: string, expected: string): boolean {
  const actualBuffer = Buffer.from(actual);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

router.get("/auth/session", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  res.json(
    GetSessionResponse.parse({
      authenticated: Boolean(user),
      user: user
        ? {
            id: user.id,
            email: user.email,
            role: isAdmin(user) ? "admin" : "customer",
            banned: user.banned,
            banReason: user.banReason,
            bannedAt: user.bannedAt,
            unbannedAt: user.unbannedAt,
            createdAt: user.createdAt,
          }
        : null,
    }),
  );
});

router.post("/auth/request-otp", async (req, res): Promise<void> => {
  const parsed = RequestOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const code =
    process.env.NODE_ENV === "production" || process.env.SMTP_USER
      ? randomInt(100000, 999999).toString()
      : "000000";
  const expiresAt = new Date(Date.now() + OTP_TTL_SECONDS * 1000);

  await db.insert(otpCodesTable).values({
    email,
    codeHash: hashValue(code),
    expiresAt,
  });

  try {
    if (isSmtpConfigured()) {
      await sendMail({
        to: email,
        subject: "Twój kod logowania do Sleex Usługi",
        text: `Twój jednorazowy kod logowania to: ${code}. Kod jest ważny przez 10 minut.`,
        html: brandedEmail("Kod logowania", `Twój jednorazowy kod logowania: ${code}\n\nKod jest ważny przez 10 minut.`),
      });
    } else if (process.env.NODE_ENV === "production") {
      throw new Error("SMTP is not configured");
    }
  } catch (error) {
    req.log.error({ error }, "Failed to send OTP email");
    res.status(503).json({ error: "Nie udało się wysłać kodu. Sprawdź konfigurację SMTP." });
    return;
  }

  res.json(
    RequestOtpResponse.parse({
      message:
        process.env.NODE_ENV === "production" || process.env.SMTP_USER
          ? "Kod został wysłany na podany adres."
          : "Tryb podglądu: użyj kodu 000000. Po dodaniu SMTP kod będzie wysyłany na e-mail.",
      expiresInSeconds: OTP_TTL_SECONDS,
    }),
  );
});

router.post("/auth/verify-otp", async (req, res): Promise<void> => {
  const parsed = VerifyOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const email = parsed.data.email.trim().toLowerCase();
  const [otp] = await db
    .select()
    .from(otpCodesTable)
    .where(
      and(
        eq(otpCodesTable.email, email),
        eq(otpCodesTable.codeHash, hashValue(parsed.data.code)),
        eq(otpCodesTable.used, false),
        gt(otpCodesTable.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(otpCodesTable.createdAt))
    .limit(1);

  if (!otp) {
    res.status(400).json({ error: "Kod jest nieprawidłowy albo wygasł." });
    return;
  }

  await db.update(otpCodesTable).set({ used: true }).where(eq(otpCodesTable.id, otp.id));
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  const user =
    existing ??
    (
      await db
        .insert(usersTable)
        .values({ email, role: configuredAdminEmail(email) ? "admin" : "customer" })
        .returning()
    )[0];

  if (!user) {
    res.status(500).json({ error: "Nie udało się utworzyć konta." });
    return;
  }
  const token = newToken();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await db.insert(sessionsTable).values({
    userId: user.id,
    tokenHash: hashValue(token),
    expiresAt,
  });
  setSessionCookie(res, token, expiresAt);

  res.json(
    VerifyOtpResponse.parse({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        role: isAdmin(user) ? "admin" : "customer",
        banned: user.banned,
        banReason: user.banReason,
        bannedAt: user.bannedAt,
        unbannedAt: user.unbannedAt,
        createdAt: user.createdAt,
      },
    }),
  );
});

router.post("/auth/admin-login", async (req, res): Promise<void> => {
  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Podaj login i hasło administratora." });
    return;
  }

  const expectedLogin = process.env.ADMIN_LOGIN;
  const expectedPassword = process.env.ADMIN_PASSWORD;
  if (!expectedLogin || !expectedPassword) {
    res.status(503).json({ error: "Logowanie administratora nie zostało skonfigurowane." });
    return;
  }

  if (
    !secureEqual(parsed.data.login, expectedLogin) ||
    !secureEqual(parsed.data.password, expectedPassword)
  ) {
    res.status(401).json({ error: "Nieprawidłowy login lub hasło." });
    return;
  }

  const email = (
    process.env.ADMIN_EMAIL ??
    process.env.SMTP_USER ??
    "admin@sleex.pl"
  ).trim().toLowerCase();
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  const [user] = existing
    ? await db.update(usersTable).set({ role: "admin" }).where(eq(usersTable.id, existing.id)).returning()
    : await db.insert(usersTable).values({ email, role: "admin" }).returning();

  if (!user) {
    res.status(500).json({ error: "Nie udało się utworzyć sesji administratora." });
    return;
  }

  const token = newToken();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await db.insert(sessionsTable).values({
    userId: user.id,
    tokenHash: hashValue(token),
    expiresAt,
  });
  setSessionCookie(res, token, expiresAt);

  res.json(
    VerifyOtpResponse.parse({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        role: "admin",
        banned: user.banned,
        banReason: user.banReason,
        bannedAt: user.bannedAt,
        unbannedAt: user.unbannedAt,
        createdAt: user.createdAt,
      },
    }),
  );
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const rawToken = req.cookies?.sleex_session as string | undefined;
  if (rawToken) {
    await db.delete(sessionsTable).where(eq(sessionsTable.tokenHash, hashValue(rawToken)));
  }
  clearSessionCookie(res);
  res.status(204).send();
  void LogoutResponse;
});

export default router;