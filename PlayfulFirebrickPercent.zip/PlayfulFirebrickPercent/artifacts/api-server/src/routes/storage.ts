import { Readable } from 'stream';
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
} from '@workspace/api-zod';
import { Router, type IRouter, type Request, type Response } from 'express';

import {
  ObjectNotFoundError,
  ObjectStorageService,
} from '../lib/objectStorage';
import { getCurrentUser, isAdmin } from '../lib/sleex';
import { and, eq, isNull } from 'drizzle-orm';
import { db, enqueueDiscordLog, orderAttachmentsTable, ordersTable } from '@workspace/db';

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

/**
 * POST /storage/uploads/request-url
 *
 * Request a presigned URL for file upload.
 * The client sends JSON metadata (name, size, contentType) — NOT the file.
 * Then uploads the file directly to the returned presigned URL.
 * Requires auth middleware so public callers cannot mint write-capable URLs.
 */
router.post(
  '/storage/uploads/request-url',
  async (req: Request, res: Response) => {
    const user = await getCurrentUser(req);
    const parsed = RequestUploadUrlBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Brakuje wymaganych danych pliku lub są nieprawidłowe.' });
      return;
    }
    const purpose = parsed.data.purpose ?? 'service_image';
    if (!user || (purpose === 'service_image' && !isAdmin(user))) {
      res.status(403).json({ error: 'Brak uprawnień do przesłania tego pliku.' });
      return;
    }
    if (user.banned) {
      res.status(403).json({ error: 'Twoje konto jest zablokowane.' });

      return;
    }
    const allowed = new Set(['image/jpeg', 'image/png', 'image/webp', 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
    if (purpose === 'order_attachment' && (!allowed.has(parsed.data.contentType.toLowerCase()) || parsed.data.size > 10 * 1024 * 1024)) {
      res.status(400).json({ error: 'Załącznik musi mieć do 10 MB i dozwolony typ pliku.' });
      return;
    }

    try {
      const { name, size, contentType } = parsed.data;

      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      const objectPath =
        objectStorageService.normalizeObjectEntityPath(uploadURL);
      if (purpose === 'order_attachment') {
        await db.insert(orderAttachmentsTable).values({ userId: user.id, objectPath, filename: name.slice(0, 255), mimeType: contentType.toLowerCase(), size });
        await enqueueDiscordLog('order_attachment_upload', { title: 'Przygotowano załącznik zamówienia', description: `Użytkownik #${user.id}; plik: ${name.slice(0, 200)}; rozmiar: ${size} B` });
      }

      res.json(
        RequestUploadUrlResponse.parse({
          uploadURL,
          objectPath,
          metadata: { name, size, contentType, purpose },
        }),
      );
    } catch (error) {
      req.log.error({ err: error }, 'Error generating upload URL');
      res.status(500).json({ error: 'Failed to generate upload URL' });
    }
  },
);

/**
 * GET /storage/public-objects/*
 *
 * Serve public assets from PUBLIC_OBJECT_SEARCH_PATHS.
 * These are unconditionally public — no authentication or ACL checks.
 * IMPORTANT: Always provide this endpoint when object storage is set up.
 */
router.get(
  '/storage/public-objects/*filePath',
  async (req: Request, res: Response) => {
    try {
      const raw = req.params.filePath;
      const filePath = Array.isArray(raw) ? raw.join('/') : raw;
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        res.status(404).json({ error: 'File not found' });
        return;
      }

      const response = await objectStorageService.downloadObject(file);

      res.status(response.status);
      response.headers.forEach((value, key) => res.setHeader(key, value));

      if (response.body) {
        const nodeStream = Readable.fromWeb(
          response.body as ReadableStream<Uint8Array>,
        );
        nodeStream.pipe(res);
      } else {
        res.end();
      }
    } catch (error) {
      req.log.error({ err: error }, 'Error serving public object');
      res.status(500).json({ error: 'Failed to serve public object' });
    }
  },
);

/**
 * GET /storage/objects/*
 *
 * Serve object entities from PRIVATE_OBJECT_DIR.
 * These are served from a separate path from /public-objects and can optionally
 * be protected with authentication or ACL checks based on the use case.
 */
router.get('/storage/objects/*path', async (req: Request, res: Response) => {
  try {
    const user = await getCurrentUser(req);
    if (!user || user.banned) { res.status(user ? 403 : 401).json({ error: 'Wymagane jest aktywne konto.' }); return; }
    const raw = req.params.path;
    const wildcardPath = Array.isArray(raw) ? raw.join('/') : raw;
    const objectPath = `/objects/${wildcardPath}`;
    const [attachment] = await db.select({ attachment: orderAttachmentsTable, order: ordersTable }).from(orderAttachmentsTable).leftJoin(ordersTable, eq(orderAttachmentsTable.orderId, ordersTable.id)).where(eq(orderAttachmentsTable.objectPath, objectPath)).limit(1);
    if (attachment && !isAdmin(user) && attachment.attachment.userId !== user.id) { res.status(403).json({ error: 'Brak dostępu do załącznika.' }); return; }
    if (!attachment && !isAdmin(user)) { res.status(404).json({ error: 'Nie znaleziono pliku.' }); return; }
    const objectFile =
      await objectStorageService.getObjectEntityFile(objectPath);

    // --- Protected route example (uncomment when using replit-auth) ---
    // if (!req.isAuthenticated()) {
    //   res.status(401).json({ error: "Unauthorized" });
    //   return;
    // }
    // const canAccess = await objectStorageService.canAccessObjectEntity({
    //   userId: req.user.id,
    //   objectFile,
    //   requestedPermission: ObjectPermission.READ,
    // });
    // if (!canAccess) {
    //   res.status(403).json({ error: "Forbidden" });
    //   return;
    // }

    const response = await objectStorageService.downloadObject(objectFile);

    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));

    if (response.body) {
      const nodeStream = Readable.fromWeb(
        response.body as ReadableStream<Uint8Array>,
      );
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      req.log.warn({ err: error }, 'Object not found');
      res.status(404).json({ error: 'Object not found' });
      return;
    }
    req.log.error({ err: error }, 'Error serving object');
    res.status(500).json({ error: 'Failed to serve object' });
  }
});

export default router;
