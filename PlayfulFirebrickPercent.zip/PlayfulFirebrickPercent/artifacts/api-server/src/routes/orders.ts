import { Router, type IRouter } from "express";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db, enqueueDiscordLog, notificationsTable, orderAttachmentsTable, orderEventsTable, ordersTable, promotionsTable, servicesTable, usersTable } from "@workspace/db";
import {
  CreateOrderBody,
  CreateOrderResponse,
  GetOrderParams,
  GetOrderResponse,
  LookupOrderStatusParams,
  LookupOrderStatusResponse,
  ListOrdersResponse,
} from "@workspace/api-zod";
import { getCurrentUser, isBanned } from "../lib/sleex";
import { brandedEmail, isSmtpConfigured, sendMail } from "../lib/mailer";

const router: IRouter = Router();

function requestOrigin(req: Parameters<typeof getCurrentUser>[0]): string {
  const protocol = req.get("x-forwarded-proto")?.split(",")[0]?.trim() || req.protocol;
  return `${protocol}://${req.get("host")}`;
}

async function readOrders(userId?: number) {
  const rows = await db
    .select({
      order: ordersTable,
      serviceName: servicesTable.name,
      email: usersTable.email,
    })
    .from(ordersTable)
    .innerJoin(servicesTable, eq(ordersTable.serviceId, servicesTable.id))
    .innerJoin(usersTable, eq(ordersTable.userId, usersTable.id))
    .where(userId ? eq(ordersTable.userId, userId) : undefined)
    .orderBy(desc(ordersTable.createdAt));
  return rows.map(({ order, serviceName, email }) => ({
    id: order.id,
    serviceId: order.serviceId,
    serviceName,
    email,
    pricePln: order.finalPricePln,
    promoCode: order.promoCode,
    finalPricePln: order.finalPricePln,
    status: order.status,
    trackingId: order.trackingId, customerPhone: order.customerPhone, paymentMethod: order.paymentMethod,
    ramGb: order.ramGb, laptopAgeYears: order.laptopAgeYears, assignedAdminId: order.assignedAdminId,
    rejectionReason: order.rejectionReason, createdAt: order.createdAt, updatedAt: order.updatedAt,
  }));
}

function trackingId(): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  return [...randomBytes(16)].map((byte) => alphabet[byte % alphabet.length]).join("");
}

router.get("/orders", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!user) {
    res.status(401).json({ error: "Zaloguj się, aby zobaczyć zamówienia." });
    return;
  }
  if (isBanned(user)) {
    res.status(403).json({ error: "Twoje konto jest zablokowane." });
    return;
  }
  res.json(ListOrdersResponse.parse(await readOrders(user.id)));
});

async function orderDetail(orderId: number, userId: number, admin: boolean) {
  const [row] = await db.select({ order: ordersTable, serviceName: servicesTable.name, email: usersTable.email })
    .from(ordersTable).innerJoin(servicesTable, eq(ordersTable.serviceId, servicesTable.id)).innerJoin(usersTable, eq(ordersTable.userId, usersTable.id))
    .where(and(eq(ordersTable.id, orderId), admin ? undefined : eq(ordersTable.userId, userId))).limit(1);
  if (!row) return null;
  const events = await db.select().from(orderEventsTable).where(eq(orderEventsTable.orderId, row.order.id)).orderBy(desc(orderEventsTable.createdAt));
  const attachments = await db.select().from(orderAttachmentsTable).where(eq(orderAttachmentsTable.orderId, row.order.id));
  return { id: row.order.id, serviceId: row.order.serviceId, serviceName: row.serviceName, email: row.email, pricePln: row.order.finalPricePln, promoCode: row.order.promoCode, finalPricePln: row.order.finalPricePln, status: row.order.status, trackingId: row.order.trackingId, customerPhone: row.order.customerPhone, paymentMethod: row.order.paymentMethod, ramGb: row.order.ramGb, laptopAgeYears: row.order.laptopAgeYears, assignedAdminId: row.order.assignedAdminId, rejectionReason: row.order.rejectionReason, createdAt: row.order.createdAt, updatedAt: row.order.updatedAt, damageDescription: row.order.damageDescription, incidentDescription: row.order.incidentDescription, events: events.reverse(), attachments: attachments.map((attachment) => ({ id: attachment.id, filename: attachment.filename, mimeType: attachment.mimeType, size: attachment.size, objectPath: attachment.objectPath, downloadUrl: `/api/storage/objects/${attachment.objectPath.replace(/^\/objects\//, "")}` })) };
}
router.get("/orders/:orderId", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const params = GetOrderParams.safeParse(req.params);
  if (!user) { res.status(401).json({ error: "Zaloguj się, aby zobaczyć zamówienie." }); return; }
  if (!params.success) { res.status(400).json({ error: "Nieprawidłowy identyfikator zamówienia." }); return; }
  const order = await orderDetail(params.data.orderId, user.id, false);
  if (!order) { res.status(404).json({ error: "Nie znaleziono zamówienia." }); return; }
  res.json(GetOrderResponse.parse(order));
});
router.get("/orders/status/:trackingId", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const params = LookupOrderStatusParams.safeParse(req.params);
  if (!user) { res.status(401).json({ error: "Zaloguj się, aby sprawdzić status." }); return; }
  if (!params.success) { res.status(400).json({ error: "Nieprawidłowy numer śledzenia." }); return; }
  const [order] = await db.select({ id: ordersTable.id }).from(ordersTable).where(and(eq(ordersTable.trackingId, params.data.trackingId), eq(ordersTable.userId, user.id))).limit(1);
  if (!order) { res.status(404).json({ error: "Nie znaleziono zamówienia." }); return; }
  res.json(LookupOrderStatusResponse.parse(await orderDetail(order.id, user.id, false)));
});

router.post("/orders", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!user) {
    res.status(401).json({ error: "Zaloguj się, aby złożyć zamówienie." });
    return;
  }
  if (isBanned(user)) {
    res.status(403).json({ error: "Twoje konto jest zablokowane." });
    return;
  }
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (parsed.data.email.trim().toLowerCase() !== user.email.trim().toLowerCase()) {
    res.status(400).json({ error: "Adres e-mail musi być zgodny z zalogowanym kontem." });
    return;
  }
  const [service] = await db
    .select()
    .from(servicesTable)
    .where(and(eq(servicesTable.id, parsed.data.serviceId), eq(servicesTable.published, true)))
    .limit(1);
  if (!service) {
    res.status(404).json({ error: "Ta usługa nie jest już dostępna." });
    return;
  }

  let finalPrice = service.pricePln;
  let promoCode: string | null = null;
  if (parsed.data.promoCode) {
    const normalized = parsed.data.promoCode.trim().toUpperCase();
    const [promotion] = await db
      .select()
      .from(promotionsTable)
      .where(
        and(
          eq(promotionsTable.code, normalized),
          eq(promotionsTable.active, true),
          sql`${promotionsTable.usedCount} < ${promotionsTable.usageLimit}`,
        ),
      )
      .limit(1);
    if (!promotion) {
      res.status(400).json({ error: "Kod promocyjny jest nieprawidłowy lub wykorzystany." });
      return;
    }
    finalPrice = Math.round(service.pricePln * (1 - promotion.discountPercent / 100) * 100) / 100;
    promoCode = normalized;
    await db
      .update(promotionsTable)
      .set({ usedCount: promotion.usedCount + 1 })
      .where(eq(promotionsTable.id, promotion.id));
  }

  let order: typeof ordersTable.$inferSelect | undefined;
  for (let attempt = 0; attempt < 3 && !order; attempt += 1) {
    try {
      [order] = await db.insert(ordersTable).values({
        userId: user.id, serviceId: service.id, promoCode, finalPricePln: finalPrice, status: "new",
        trackingId: trackingId(), customerPhone: parsed.data.customerPhone.trim(), paymentMethod: parsed.data.paymentMethod,
        ramGb: parsed.data.ramGb, laptopAgeYears: parsed.data.laptopAgeYears,
        damageDescription: parsed.data.damageDescription.trim(), incidentDescription: parsed.data.incidentDescription.trim(),
      }).returning();
    } catch (error) {
      if (attempt === 2) throw error;
    }
  }
  if (!order) {
    res.status(500).json({ error: "Nie udało się utworzyć zamówienia." });
    return;
  }
  const attachmentPaths = parsed.data.attachmentPaths ?? [];
  if (attachmentPaths.length) {
    const attachments = await db.select().from(orderAttachmentsTable).where(and(eq(orderAttachmentsTable.userId, user.id), isNull(orderAttachmentsTable.orderId)));
    const selected = attachments.filter((attachment) => attachmentPaths.includes(attachment.objectPath));
    if (selected.length !== attachmentPaths.length || selected.length > 5) {
      await db.delete(ordersTable).where(eq(ordersTable.id, order.id));
      res.status(400).json({ error: "Co najmniej jeden załącznik jest nieprawidłowy lub został już użyty." });
      return;
    }
    await db.transaction(async (tx) => {
      for (const attachment of selected) await tx.update(orderAttachmentsTable).set({ orderId: order!.id, boundAt: new Date() }).where(and(eq(orderAttachmentsTable.id, attachment.id), isNull(orderAttachmentsTable.orderId)));
    });
    await db.insert(orderEventsTable).values({ orderId: order.id, actorUserId: user.id, type: "attachment_bound", note: `Dodano załączniki: ${selected.length}.` });
  }
  await db.insert(orderEventsTable).values({ orderId: order.id, actorUserId: user.id, type: "created", toStatus: "new", note: "Zamówienie zostało utworzone." });
  await enqueueDiscordLog("order_created", { title: "Nowe zamówienie", fields: [{ name: "E-mail", value: user.email }, { name: "Numer śledzenia", value: order.trackingId }, { name: "Usługa", value: service.name }, { name: "Płatność", value: order.paymentMethod }] });
  const statusUrl = `${requestOrigin(req)}/status-zamowienia?id=${order.trackingId}`;
  const summary = `Numer śledzenia: ${order.trackingId}\nUsługa: ${service.name}\nStatus: nowe\nTelefon: ${order.customerPhone}\nPłatność (preferencja): ${order.paymentMethod}\nRAM: ${order.ramGb} GB\nWiek laptopa: ${order.laptopAgeYears} lat\nOpis uszkodzenia: ${order.damageDescription}\nOpis zdarzenia: ${order.incidentDescription}\nStatus: ${statusUrl}`;
  await db.insert(notificationsTable).values({ userId: user.id, type: "order_created", title: "Przyjęliśmy zamówienie", body: `Numer śledzenia: ${order.trackingId}`, audible: true });
  const admins = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.role, "admin"));
  if (admins.length) await db.insert(notificationsTable).values(admins.map((admin) => ({ userId: admin.id, type: "order_created", title: "Nowe zamówienie", body: `Numer śledzenia: ${order!.trackingId}`, audible: true })));
  if (isSmtpConfigured()) void sendMail({ to: user.email, subject: `Sleex — zamówienie ${order.trackingId}`, text: summary, html: brandedEmail(`Zamówienie ${order.trackingId}`, summary, { label: "Sprawdź status zamówienia", url: statusUrl }) }).then(() => enqueueDiscordLog("email_outbound", { title: "Wysłano e-mail", description: `Potwierdzenie zamówienia: ${order!.trackingId}` })).catch(() => undefined);
  res.status(201).json(
    CreateOrderResponse.parse({
      id: order.id,
      serviceId: order.serviceId,
      serviceName: service.name,
      email: user.email,
      pricePln: service.pricePln,
      promoCode: order.promoCode,
      finalPricePln: order.finalPricePln,
      status: order.status,
       trackingId: order.trackingId, customerPhone: order.customerPhone, paymentMethod: order.paymentMethod, ramGb: order.ramGb, laptopAgeYears: order.laptopAgeYears, assignedAdminId: null, rejectionReason: null, createdAt: order.createdAt, updatedAt: order.updatedAt,
    }),
  );
});

export { readOrders, orderDetail };
export default router;