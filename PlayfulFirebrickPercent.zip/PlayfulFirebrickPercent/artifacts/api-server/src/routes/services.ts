import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, servicesTable } from "@workspace/db";
import {
  CreateServiceBody,
  CreateServiceResponse,
  DeleteServiceParams,
  ListServicesResponse,
} from "@workspace/api-zod";
import { getCurrentUser, isAdmin } from "../lib/sleex";

const router: IRouter = Router();

router.get("/services", async (_req, res): Promise<void> => {
  const services = await db
    .select()
    .from(servicesTable)
    .where(eq(servicesTable.published, true))
    .orderBy(desc(servicesTable.createdAt));
  res.json(ListServicesResponse.parse(services));
});

router.post("/services", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Dostęp tylko dla administratora." });
    return;
  }
  const parsed = CreateServiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [service] = await db
    .insert(servicesTable)
    .values({
      name: parsed.data.name,
      description: parsed.data.description,
      pricePln: parsed.data.pricePln,
      imageUrl: parsed.data.imageUrl ?? null,
      published: parsed.data.published ?? true,
    })
    .returning();
  res.status(201).json(CreateServiceResponse.parse(service));
});

router.delete("/services/:serviceId", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req);
  if (!isAdmin(user)) {
    res.status(403).json({ error: "Dostęp tylko dla administratora." });
    return;
  }
  const params = DeleteServiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(servicesTable)
    .where(eq(servicesTable.id, params.data.serviceId))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Nie znaleziono usługi." });
    return;
  }
  res.status(204).send();
});

export default router;