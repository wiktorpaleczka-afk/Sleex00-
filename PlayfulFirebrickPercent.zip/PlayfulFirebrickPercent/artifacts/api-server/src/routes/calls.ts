import { Router, type IRouter } from "express";
import { and, desc, eq } from "drizzle-orm";
import { db, callEventsTable, callsTable, enqueueDiscordLog, notificationsTable, ordersTable, usersTable } from "@workspace/db";
import { CancelCallParams, CancelCallResponse, EndCallParams, EndCallResponse, GetCallParams, GetCallResponse, JoinAuthorizeCallParams, JoinAuthorizeCallResponse, ListAdminCallsResponse, ListCallsResponse, ScheduleCallBody, ScheduleCallResponse, StartCallParams, StartCallResponse } from "@workspace/api-zod";
import { getCurrentUser, isAdmin } from "../lib/sleex";
import { brandedEmail, isSmtpConfigured, sendMail } from "../lib/mailer";

const router: IRouter = Router();
const entity = (call: typeof callsTable.$inferSelect) => call;
const accountUrl = (req: Parameters<typeof getCurrentUser>[0], callId: number) =>
  `${req.get("x-forwarded-proto")?.split(",")[0]?.trim() || req.protocol}://${req.get("host")}/account?call=${callId}`;

async function accessible(callId: number, userId: number, admin: boolean) {
  const [row] = await db.select({ call: callsTable, order: ordersTable, email: usersTable.email }).from(callsTable).innerJoin(ordersTable, eq(callsTable.orderId, ordersTable.id)).innerJoin(usersTable, eq(ordersTable.userId, usersTable.id)).where(eq(callsTable.id, callId)).limit(1);
  return row && (admin || row.order.userId === userId) ? row : null;
}
async function transition(callId: number, actorId: number, status: "waiting" | "active" | "ended" | "cancelled") {
  const current = (await db.select().from(callsTable).where(eq(callsTable.id, callId)).limit(1))[0];
  if (!current || ["ended", "cancelled"].includes(current.status)) return null;
  const now = new Date();
  const patch = status === "active" ? { status, startedAt: current.startedAt ?? now } : status === "ended" ? { status, endedAt: now } : { status };
  const [call] = await db.update(callsTable).set(patch).where(eq(callsTable.id, callId)).returning();
  if (call) await db.insert(callEventsTable).values({ callId, actorUserId: actorId, type: status });
  return call;
}

router.get("/calls", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); if (!user) { res.status(401).json({ error: "Zaloguj się, aby zobaczyć rozmowy." }); return; }
  const calls = await db.select({ call: callsTable }).from(callsTable).innerJoin(ordersTable, eq(callsTable.orderId, ordersTable.id)).where(eq(ordersTable.userId, user.id)).orderBy(desc(callsTable.scheduledAt));
  res.json(ListCallsResponse.parse(calls.map(({ call }) => entity(call))));
});
router.get("/calls/:callId", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const params = GetCallParams.safeParse(req.params);
  if (!user) { res.status(401).json({ error: "Zaloguj się." }); return; } if (!params.success) { res.status(400).json({ error: "Nieprawidłowy identyfikator rozmowy." }); return; }
  const row = await accessible(params.data.callId, user.id, isAdmin(user)); if (!row) { res.status(404).json({ error: "Nie znaleziono rozmowy." }); return; }
  const events = await db.select().from(callEventsTable).where(eq(callEventsTable.callId, row.call.id)).orderBy(desc(callEventsTable.createdAt));
  res.json(GetCallResponse.parse({ ...entity(row.call), events: events.reverse() }));
});
router.post("/calls/:callId/join-authorize", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const params = JoinAuthorizeCallParams.safeParse(req.params);
  if (!user) { res.status(401).json({ error: "Zaloguj się." }); return; } if (!params.success) { res.status(400).json({ error: "Nieprawidłowy identyfikator rozmowy." }); return; }
  const row = await accessible(params.data.callId, user.id, isAdmin(user)); if (!row || ["ended", "cancelled"].includes(row.call.status)) { res.status(404).json({ error: "Rozmowa jest niedostępna." }); return; }
  if (!isAdmin(user) && row.call.status === "scheduled") await transition(row.call.id, user.id, "waiting");
  await db.insert(callEventsTable).values({ callId: row.call.id, actorUserId: user.id, type: "join_authorized" });
  const call = (await db.select().from(callsTable).where(eq(callsTable.id, row.call.id)).limit(1))[0]!;
  res.json(JoinAuthorizeCallResponse.parse(entity(call)));
});
router.get("/admin/calls", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); if (!isAdmin(user)) { res.status(403).json({ error: "Dostęp tylko dla administratora." }); return; }
  res.json(ListAdminCallsResponse.parse((await db.select().from(callsTable).orderBy(desc(callsTable.scheduledAt))).map(entity)));
});
router.post("/admin/calls", async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const parsed = ScheduleCallBody.safeParse(req.body);
  if (!isAdmin(user)) { res.status(403).json({ error: "Dostęp tylko dla administratora." }); return; } if (!parsed.success || Number.isNaN(new Date(parsed.data.scheduledAt).valueOf())) { res.status(400).json({ error: "Podaj poprawny termin rozmowy." }); return; }
  const [order] = await db.select({ order: ordersTable, email: usersTable.email }).from(ordersTable).innerJoin(usersTable, eq(ordersTable.userId, usersTable.id)).where(eq(ordersTable.id, parsed.data.orderId)).limit(1);
  if (!order) { res.status(404).json({ error: "Nie znaleziono zamówienia." }); return; }
  const [call] = await db.insert(callsTable).values({ orderId: order.order.id, scheduledAt: new Date(parsed.data.scheduledAt), createdByAdminId: user!.id }).returning();
  await db.insert(callEventsTable).values({ callId: call!.id, actorUserId: user!.id, type: "scheduled" });
  await db.insert(notificationsTable).values({ userId: order.order.userId, type: "call_scheduled", title: "Zaplanowano rozmowę", body: `Termin: ${call!.scheduledAt.toLocaleString("pl-PL")}`, audible: true });
  const joinUrl = accountUrl(req, call!.id);
  const invitation = `Termin rozmowy: ${call!.scheduledAt.toLocaleString("pl-PL")}\nPo zalogowaniu możesz dołączyć do poczekalni: ${joinUrl}`;
  if (isSmtpConfigured()) void sendMail({ to: order.email, subject: "Sleex — zaproszenie na rozmowę", text: invitation, html: brandedEmail("Zaproszenie na rozmowę", invitation, { label: "Przejdź do rozmowy", url: joinUrl }) }).then(() => enqueueDiscordLog("email_outbound", { title: "Wysłano e-mail", description: `Zaproszenie do rozmowy #${call!.id}` })).catch(() => undefined);
  res.status(201).json(ScheduleCallResponse.parse(entity(call!)));
});
for (const [path, schema, status] of [["/admin/calls/:callId/start", StartCallParams, "active"], ["/admin/calls/:callId/end", EndCallParams, "ended"], ["/admin/calls/:callId/cancel", CancelCallParams, "cancelled"]] as const) router.post(path, async (req, res): Promise<void> => {
  const user = await getCurrentUser(req); const params = schema.safeParse(req.params);
  if (!isAdmin(user)) { res.status(403).json({ error: "Dostęp tylko dla administratora." }); return; } if (!params.success) { res.status(400).json({ error: "Nieprawidłowy identyfikator rozmowy." }); return; }
  const row = await accessible(params.data.callId, user!.id, true); const call = row && await transition(row.call.id, user!.id, status);
  if (!call) { res.status(409).json({ error: "Nie można zmienić stanu tej rozmowy." }); return; }
  await db.insert(notificationsTable).values({ userId: row!.order.userId, type: `call_${status}`, title: status === "active" ? "Administrator oczekuje na rozmowę" : "Status rozmowy został zmieniony", body: "Sprawdź szczegóły rozmowy.", audible: true });
  if (isSmtpConfigured()) {
    const joinUrl = accountUrl(req, call.id);
    const labels = { active: "Specjalista oczekuje już w pokoju rozmowy.", ended: "Rozmowa została zakończona.", cancelled: "Rozmowa została anulowana." } as const;
    const text = `${labels[status]}\nTermin: ${call.scheduledAt.toLocaleString("pl-PL")}${status === "active" ? `\nDołącz: ${joinUrl}` : ""}`;
    void sendMail({ to: row!.email, subject: status === "active" ? "Sleex — specjalista czeka na rozmowę" : "Sleex — zmiana statusu rozmowy", text, html: brandedEmail(status === "active" ? "Możesz dołączyć do rozmowy" : "Status rozmowy został zmieniony", text, status === "active" ? { label: "Dołącz do rozmowy", url: joinUrl } : undefined) }).then(() => enqueueDiscordLog("email_outbound", { title: "Wysłano e-mail", description: `Zmiana statusu rozmowy #${call.id}` })).catch(() => undefined);
  }
  res.json((status === "active" ? StartCallResponse : status === "ended" ? EndCallResponse : CancelCallResponse).parse(entity(call)));
});
export default router;