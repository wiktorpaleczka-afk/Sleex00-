import app from "./app";
import { logger } from "./lib/logger";
import { syncGmailInbox } from "./lib/gmail";
import { isSmtpConfigured } from "./lib/mailer";
import { seedDatabase } from "./lib/seed";
import { createServer } from "node:http";
import { attachCallSignaling } from "./lib/calls-ws";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);
let gmailSyncRunning = false;

async function runGmailSync(): Promise<void> {
  if (!isSmtpConfigured() || gmailSyncRunning) return;
  gmailSyncRunning = true;
  try {
    const result = await syncGmailInbox();
    if (result.imported > 0) {
      logger.info({ imported: result.imported, skipped: result.skipped }, "Gmail inbox synchronized");
    }
  } catch (err) {
    logger.warn({ err }, "Automatic Gmail inbox synchronization failed");
  } finally {
    gmailSyncRunning = false;
  }
}

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

seedDatabase()
  .then(() => {
    const server = createServer(app);
    attachCallSignaling(server);
    server.listen(port, () => {
      logger.info({ port }, "Server listening");
      setTimeout(() => void runGmailSync(), 10_000);
      setInterval(() => void runGmailSync(), 2 * 60 * 1000);
    });
  })
  .catch((err: unknown) => {
    logger.error({ err }, "Database seed failed");
    process.exit(1);
  });
