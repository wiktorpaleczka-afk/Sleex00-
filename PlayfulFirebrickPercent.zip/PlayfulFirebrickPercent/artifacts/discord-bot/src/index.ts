import {
  ActionRowBuilder, ChannelType, ChatInputCommandInteraction, Client, EmbedBuilder,
  GatewayIntentBits, ModalBuilder, PermissionFlagsBits, REST, Routes,
  SlashCommandBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle,
  type GuildMember, type StringSelectMenuInteraction,
} from "discord.js";
import { and, eq, isNull, lte, or } from "drizzle-orm";
import {
  db, discordLogOutboxTable, discordTicketEventsTable, discordTicketsTable,
  enqueueDiscordLog, notificationsTable, orderEventsTable, ordersTable,
  servicesTable, usersTable,
} from "@workspace/db";
import { randomBytes } from "node:crypto";

const required = ["DISCORD_BOT_TOKEN", "DISCORD_CLIENT_ID", "DISCORD_GUILD_ID", "DISCORD_TICKET_PANEL_CHANNEL_ID", "DISCORD_ORDER_TICKET_CATEGORY_ID", "DISCORD_PROBLEM_TICKET_CATEGORY_ID", "DISCORD_LOG_CHANNEL_ID", "DISCORD_SUPPORT_ROLE_IDS", "DISCORD_ADMIN_ROLE_IDS", "PUBLIC_APP_URL"] as const;
const missing = required.filter((key) => !process.env[key]?.trim());
if (missing.length) throw new Error(`Brakuje wymaganych zmiennych środowiskowych: ${missing.join(", ")}`);
const env = Object.fromEntries(required.map((key) => [key, process.env[key]!.trim()])) as Record<(typeof required)[number], string>;
const supportRoles = env.DISCORD_SUPPORT_ROLE_IDS.split(",").map((id) => id.trim()).filter(Boolean);
const adminRoles = env.DISCORD_ADMIN_ROLE_IDS.split(",").map((id) => id.trim()).filter(Boolean);
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
type State = { kind: "order" | "problem"; serviceId?: number; payment?: "BLIK" | "LTC" | "PSC"; category?: string; orderData?: { email: string; phone: string; ram: string; age: string; damage: string }; expires: number };
const state = new Map<string, State>();
const safeName = (value: string) => value.normalize("NFKD").replace(/[^\w-]/g, "").toLowerCase().slice(0, 45) || "uzytkownik";
const key = (userId: string) => userId;
const isExpired = (item?: State) => !item || item.expires < Date.now();
const isStaff = (member: GuildMember) => member.permissions.has(PermissionFlagsBits.Administrator) || [...member.roles.cache.keys()].some((id) => supportRoles.includes(id) || adminRoles.includes(id));
const isAdmin = (member: GuildMember) => member.permissions.has(PermissionFlagsBits.Administrator) || [...member.roles.cache.keys()].some((id) => adminRoles.includes(id));
const tracking = () => [...randomBytes(16)].map((n) => "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[n % 36]).join("");
const row = (menu: StringSelectMenuBuilder) => new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
async function reply(interaction: any, content: string, ephemeral = true) { if (interaction.replied || interaction.deferred) await interaction.followUp({ content, ephemeral }); else await interaction.reply({ content, ephemeral }); }
async function registered(discordUser: any, email: string) {
  const normalized = email.trim().toLowerCase();
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, normalized)).limit(1);
  if (user && !user.banned) return user;
  if (!user) await discordUser.send(`Dziękujemy za kontakt z Sleex. Aby utworzyć zgłoszenie, zarejestruj lub zaloguj się adresem **${normalized}** na ${env.PUBLIC_APP_URL}/login. Weryfikacja odbywa się bezpiecznie jednorazowym kodem OTP wysłanym na e-mail.`).catch(() => undefined);
  return null;
}
function modal(id: string, title: string, fields: Array<[string, string, TextInputStyle, number]>) {
  return new ModalBuilder().setCustomId(id).setTitle(title).addComponents(...fields.map(([field, label, style, min]) =>
    new ActionRowBuilder<TextInputBuilder>().addComponents(new TextInputBuilder().setCustomId(field).setLabel(label).setStyle(style).setRequired(true).setMinLength(min).setMaxLength(1000))));
}
async function createTicket(interaction: any, user: typeof usersTable.$inferSelect, kind: string, category: string, description: string) {
  const guild = interaction.guild!;
  const parent = kind === "order" ? env.DISCORD_ORDER_TICKET_CATEGORY_ID : env.DISCORD_PROBLEM_TICKET_CATEGORY_ID;
  const overwrites = [
    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
    ...(client.user ? [{ id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] }] : []),
    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
    ...supportRoles.map((id) => ({ id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] })),
    ...adminRoles.map((id) => ({ id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels] })),
  ];
  const channel = await guild.channels.create({ name: `${kind === "order" ? "zamowienie" : "problem"}-${safeName(interaction.user.username)}-${Date.now().toString(36).slice(-5)}`, type: ChannelType.GuildText, parent, permissionOverwrites: overwrites });
  const [ticket] = await db.insert(discordTicketsTable).values({ guildId: guild.id, channelId: channel.id, requesterDiscordId: interaction.user.id, requesterUserId: user.id, kind, category }).returning();
  await db.insert(discordTicketEventsTable).values({ ticketId: ticket!.id, actorDiscordId: interaction.user.id, type: "created" });
  const controls = row(new StringSelectMenuBuilder().setCustomId(`sleex_ticket_manage:${ticket!.id}`).setPlaceholder("Zarządzanie zgłoszeniem").addOptions(
    { label: "❌ × Zamknij Ticketa", value: "close", description: "Zamknij zgłoszenie, zapisz zdarzenie i usuń kanał." },
    { label: "🔹 × Przejmij Ticketa", value: "claim", description: "Przypisz zgłoszenie do siebie i zmień nazwę kanału." },
    { label: "⚠️ × Wezwij na ticket", value: "summon", description: "Wyślij użytkownikowi prywatne wezwanie do odpowiedzi." },
    { label: "🔒 × Zablokuj kanał", value: "lock", description: "Ukryj kanał przed niższymi rangami bez Administratora." },
  ));
  await channel.send({ embeds: [new EmbedBuilder().setColor(0x0aa9c8).setTitle(`Sleex — ${kind === "order" ? "zamówienie" : "zgłoszenie problemu"}`).setDescription(`Użytkownik: <@${interaction.user.id}>\nE-mail konta: ||${user.email}||\nKategoria: ${category}\n\n**Opis:**\n${description.slice(0, 3400)}\n\nDane kontaktowe pozostają prywatne — nie publikuj ich poza tym kanałem.`).setTimestamp()], components: [controls] });
  await enqueueDiscordLog("ticket_created", { title: "Utworzono ticket Discord", description: `Typ: ${kind}; kategoria: ${category}; kanał: ${channel.id}` });
  await reply(interaction, `Twoje prywatne zgłoszenie zostało utworzone: ${channel}.`);
}

async function submitOrder(interaction: any) {
  const current = state.get(key(interaction.user.id));
  if (!current || isExpired(current) || current.kind !== "order" || !current.serviceId || !current.payment) return reply(interaction, "Sesja formularza wygasła. Rozpocznij ją ponownie z panelu.");
  const staged = current.orderData;
  if (!staged) return reply(interaction, "Sesja formularza wygasła. Rozpocznij ją ponownie z panelu.");
  const email = staged.email.trim();
  const user = await registered(interaction.user, email);
  if (!user) return reply(interaction, "Nie znaleziono aktywnego konta dla tego adresu. Wysłaliśmy instrukcję rejestracji w wiadomości prywatnej.");
  const [service] = await db.select().from(servicesTable).where(and(eq(servicesTable.id, current.serviceId), eq(servicesTable.published, true))).limit(1);
  if (!service) return reply(interaction, "Wybrana usługa nie jest już dostępna.");
  const phone = staged.phone.trim();
  const ram = Number(staged.ram.trim());
  const age = Number(staged.age.trim());
  const damage = staged.damage.trim();
  const incident = interaction.fields.getTextInputValue("incident").trim();
  if (phone.length < 5 || !Number.isInteger(ram) || ram < 1 || !Number.isInteger(age) || age < 0 || damage.length < 50 || incident.length < 30) return reply(interaction, "Uzupełnij poprawnie wszystkie pola: telefon, RAM, wiek oraz wymaganej długości opisy.");
  let order: typeof ordersTable.$inferSelect | undefined;
  for (let attempt = 0; attempt < 3 && !order; attempt++) {
    try { [order] = await db.insert(ordersTable).values({ userId: user.id, serviceId: service.id, trackingId: tracking(), customerPhone: phone, paymentMethod: current.payment, ramGb: ram, laptopAgeYears: age, damageDescription: damage, incidentDescription: incident, finalPricePln: service.pricePln }).returning(); } catch (error) { if (attempt === 2) throw error; }
  }
  await db.insert(orderEventsTable).values({ orderId: order!.id, actorUserId: user.id, type: "created_discord", toStatus: "new", note: "Zamówienie utworzono przez Discord." });
  await db.insert(notificationsTable).values({ userId: user.id, type: "order_created", title: "Przyjęliśmy zamówienie", body: `Numer śledzenia: ${order!.trackingId}`, audible: true });
  await enqueueDiscordLog("order_created", { title: "Nowe zamówienie", fields: [{ name: "E-mail", value: user.email }, { name: "Numer śledzenia", value: order!.trackingId }, { name: "Usługa", value: service.name }, { name: "Płatność (preferencja)", value: current.payment }] });
  state.delete(key(interaction.user.id));
  await createTicket(interaction, user, "order", "Zamówienie", `Numer śledzenia: ${order!.trackingId}\nUsługa: ${service.name}\nPreferencja płatności: ${current.payment}\nRAM: ${ram} GB\nWiek laptopa: ${age} lat\n\nOpis uszkodzenia:\n${damage}\n\nOpis zdarzenia:\n${incident}`);
}

async function manageTicket(interaction: StringSelectMenuInteraction) {
  const member = interaction.member as GuildMember | null;
  if (!member || !isStaff(member)) return reply(interaction, "Tą funkcją może zarządzać wyłącznie zespół wsparcia.");
  const ticketId = Number(interaction.customId.split(":")[1]);
  const [ticket] = await db.select().from(discordTicketsTable).where(eq(discordTicketsTable.id, ticketId)).limit(1);
  if (!ticket || ticket.channelId !== interaction.channelId || ticket.status === "closed") return reply(interaction, "To zgłoszenie jest niedostępne.");
  const action = interaction.values[0];
  if (action === "claim") {
    if (ticket.claimedByDiscordId) return reply(interaction, "To zgłoszenie zostało już przejęte.");
    await db.update(discordTicketsTable).set({ claimedByDiscordId: interaction.user.id, claimedByName: interaction.user.username, status: "claimed" }).where(and(eq(discordTicketsTable.id, ticketId), isNull(discordTicketsTable.claimedByDiscordId)));
    const fresh = (await db.select().from(discordTicketsTable).where(eq(discordTicketsTable.id, ticketId)).limit(1))[0];
    if (fresh?.claimedByDiscordId !== interaction.user.id) return reply(interaction, "To zgłoszenie zostało właśnie przejęte przez innego członka zespołu.");
    await (interaction.channel as any)?.setName(`przejete-${safeName(interaction.user.username)}`);
  } else if (action === "summon") {
    await client.users.fetch(ticket.requesterDiscordId).then((user) => user.send(`⚠️ ***Zostałeś Wezwany***\n\n***Zostałeś Wezwany przez:***\n***${interaction.user.username}***.\n\nWróć do prywatnego kanału ticketu Sleex i odpowiedz, abyśmy mogli kontynuować pomoc.`)).catch(() => undefined);
  } else if (action === "lock") {
    if (!ticket.claimedByDiscordId) return reply(interaction, "Najpierw przejmij zgłoszenie.");
    if (ticket.claimedByDiscordId !== interaction.user.id && !isAdmin(member)) return reply(interaction, "Zgłoszenie może zablokować administrator, który je przejął.");
    const channel = interaction.channel;
    if (channel?.isTextBased() && "permissionOverwrites" in channel) {
      await channel.permissionOverwrites.edit(ticket.requesterDiscordId, { ViewChannel: false });
      await Promise.all(supportRoles.map((id) => channel.permissionOverwrites.edit(id, { ViewChannel: false })));
      await channel.permissionOverwrites.edit(ticket.claimedByDiscordId, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
      await db.update(discordTicketsTable).set({ status: "locked" }).where(eq(discordTicketsTable.id, ticketId));
    }
  } else if (action === "close") {
    await db.update(discordTicketsTable).set({ status: "closed", closedAt: new Date() }).where(eq(discordTicketsTable.id, ticketId));
    await enqueueDiscordLog("ticket_closed", { title: "Zamknięto ticket Discord", description: `Ticket #${ticketId}; kanał: ${ticket.channelId}; przez: ${interaction.user.username}` });
    await (interaction.channel as any)?.send("Zgłoszenie zostało zamknięte. Kanał zostanie usunięty za chwilę.");
    setTimeout(() => interaction.channel?.delete("Zamknięte zgłoszenie Sleex").catch(() => undefined), 10_000).unref();
  }
  await db.insert(discordTicketEventsTable).values({ ticketId, actorDiscordId: interaction.user.id, type: action });
  await enqueueDiscordLog(`ticket_${action}`, { title: "Akcja ticketu Discord", description: `Ticket #${ticketId}: ${action}; wykonawca: ${interaction.user.username}` });
  await reply(interaction, "Akcja została wykonana.");
}

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const member = interaction.member as GuildMember | null;
      if (interaction.commandName === "ticket-status") return reply(interaction, "Panel Sleex działa prawidłowo. Zgłoszenia są obsługiwane przez zespół.");
      if (!member || !isAdmin(member)) return reply(interaction, "Komenda jest dostępna wyłącznie dla administratorów.");
      if (interaction.channelId !== env.DISCORD_TICKET_PANEL_CHANNEL_ID) return reply(interaction, "Panel można opublikować wyłącznie na skonfigurowanym kanale.");
      const selector = row(new StringSelectMenuBuilder().setCustomId("sleex_ticket_create").setPlaceholder("Wybierz rodzaj zgłoszenia").addOptions(
        { label: "📩 × Stwórz zamówienie", value: "order", description: "Wybierz usługę, preferencję płatności i przekaż szczegóły zlecenia." },
        { label: "❗ × Problem z Botem/stroną", value: "problem", description: "Utwórz prywatne zgłoszenie dotyczące działania bota lub strony Sleex." },
      ));
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x0aa9c8).setTitle("Sleex — centrum zgłoszeń").setDescription("Witaj w prywatnym centrum obsługi Sleex.\n\n**Prywatność:** po utworzeniu zgłoszenia dostęp mają wyłącznie Ty i upoważniony zespół. Nie wysyłaj haseł, kodów OTP ani danych karty.\n\n**Konto:** do zamówienia lub zgłoszenia potrzebujesz zarejestrowanego adresu e-mail. Logowanie potwierdzamy jednorazowym kodem OTP.\n\n**Zamówienia:** wybierz usługę, preferencję płatności i podaj pełne informacje techniczne. Płatność jest wyłącznie preferencją — szczegóły potwierdzi zespół.\n\n**Odpowiedź:** opisz sprawę konkretnie; odpowiadamy możliwie szybko. Po utworzeniu ticketu zespół może go przejąć, wezwać Cię do odpowiedzi, zablokować dostęp po zakończeniu lub zamknąć zgłoszenie.").setFooter({ text: "Sleex Usługi · bezpieczna komunikacja" })], components: [selector] });
    } else if (interaction.isStringSelectMenu()) {
      if (interaction.customId.startsWith("sleex_ticket_manage:")) await manageTicket(interaction);
      else if (interaction.customId === "sleex_ticket_create") {
        const kind = interaction.values[0] as "order" | "problem"; state.set(key(interaction.user.id), { kind, expires: Date.now() + 15 * 60_000 });
        if (kind === "order") {
          const services = await db.select().from(servicesTable).where(eq(servicesTable.published, true)).limit(25);
          if (!services.length) return reply(interaction, "Aktualnie nie ma dostępnych usług.");
          await interaction.reply({ content: "Wybierz usługę:", ephemeral: true, components: [row(new StringSelectMenuBuilder().setCustomId("sleex_order_service").setPlaceholder("Usługa").addOptions(services.map((s) => ({ label: s.name.slice(0, 100), value: String(s.id), description: `${s.pricePln.toFixed(2)} PLN · ${s.description}`.slice(0, 100) }))))] });
        } else await interaction.reply({ content: "Wybierz kategorię problemu:", ephemeral: true, components: [row(new StringSelectMenuBuilder().setCustomId("sleex_problem_category").setPlaceholder("Kategoria").addOptions({ label: "Problem z Botem", value: "bot", description: "Błąd lub trudność w działaniu bota Discord." }, { label: "Problem ze stroną", value: "site", description: "Błąd lub trudność na stronie Sleex." }))] });
      } else {
        const current = state.get(key(interaction.user.id)); if (isExpired(current)) return reply(interaction, "Sesja formularza wygasła. Rozpocznij ponownie.");
        if (interaction.customId === "sleex_order_service" && current?.kind === "order") { current.serviceId = Number(interaction.values[0]); await interaction.update({ content: "Wybierz preferencję płatności:", components: [row(new StringSelectMenuBuilder().setCustomId("sleex_order_payment").setPlaceholder("Preferencja płatności").addOptions({ label: "BLIK", value: "BLIK" }, { label: "LTC", value: "LTC" }, { label: "PSC", value: "PSC" }))] }); }
        else if (interaction.customId === "sleex_order_payment" && current?.kind === "order") { current.payment = interaction.values[0] as State["payment"]; await interaction.showModal(modal("sleex_order_modal", "Szczegóły zamówienia", [["email", "E-mail zarejestrowanego konta", TextInputStyle.Short, 5], ["phone", "Telefon kontaktowy", TextInputStyle.Short, 5], ["ram", "Pamięć RAM (GB)", TextInputStyle.Short, 1], ["age", "Wiek laptopa (lata)", TextInputStyle.Short, 1], ["damage", "Opis uszkodzenia (min. 50 znaków)", TextInputStyle.Paragraph, 50]])); }
        else if (interaction.customId === "sleex_order_continue" && current?.kind === "order") await interaction.showModal(modal("sleex_order_incident_modal", "Opis zdarzenia", [["incident", "Opis zdarzenia (min. 30 znaków)", TextInputStyle.Paragraph, 30]]));
        else if (interaction.customId === "sleex_problem_category" && current?.kind === "problem") { current.category = interaction.values[0]; await interaction.showModal(modal("sleex_problem_modal", "Opis problemu", [["email", "E-mail zarejestrowanego konta", TextInputStyle.Short, 5], ["description", "Opis problemu", TextInputStyle.Paragraph, 20]])); }
      }
    } else if (interaction.isModalSubmit()) {
      if (interaction.customId === "sleex_order_modal") { const current = state.get(key(interaction.user.id)); if (!current) return; current.orderData = { email: interaction.fields.getTextInputValue("email"), phone: interaction.fields.getTextInputValue("phone"), ram: interaction.fields.getTextInputValue("ram"), age: interaction.fields.getTextInputValue("age"), damage: interaction.fields.getTextInputValue("damage") }; current.expires = Date.now() + 15 * 60_000; await interaction.reply({ content: "Dziękujemy. Wybierz kontynuację, aby opisać zdarzenie.", ephemeral: true, components: [row(new StringSelectMenuBuilder().setCustomId("sleex_order_continue").setPlaceholder("Kontynuuj formularz").addOptions({ label: "Kontynuuj", value: "continue", description: "Przejdź do opisu zdarzenia." }))] }); }
      else if (interaction.customId === "sleex_order_incident_modal") await submitOrder(interaction);
      else if (interaction.customId === "sleex_problem_modal") { const current = state.get(key(interaction.user.id)); if (isExpired(current) || current?.kind !== "problem") return reply(interaction, "Sesja formularza wygasła."); const user = await registered(interaction.user, interaction.fields.getTextInputValue("email")); if (!user) return reply(interaction, "Nie znaleziono aktywnego konta. Wysłaliśmy instrukcję rejestracji w wiadomości prywatnej."); await createTicket(interaction, user, "problem", current.category === "bot" ? "Problem z Botem" : "Problem ze stroną", interaction.fields.getTextInputValue("description")); state.delete(key(interaction.user.id)); }
    }
  } catch (error) { console.error("Discord interaction failure", error); if (interaction.isRepliable()) await reply(interaction, "Wystąpił błąd podczas obsługi zgłoszenia. Spróbuj ponownie.").catch(() => undefined); }
});

async function flushOutbox() {
  const channel = await client.channels.fetch(env.DISCORD_LOG_CHANNEL_ID).catch(() => null);
  if (!channel?.isTextBased()) return;
  const messages = await db.select().from(discordLogOutboxTable).where(and(isNull(discordLogOutboxTable.sentAt), or(isNull(discordLogOutboxTable.nextAttemptAt), lte(discordLogOutboxTable.nextAttemptAt, new Date())))).limit(20);
  for (const message of messages) {
    try {
      const payload = message.payload as { title?: string; description?: string; fields?: Array<{ name: string; value: string; inline?: boolean }>; color?: number };
      await (channel as any).send({ embeds: [new EmbedBuilder().setColor(payload.color ?? 0x0aa9c8).setTitle(payload.title ?? "Sleex").setDescription(payload.description ?? message.text ?? "Zdarzenie systemowe").addFields(payload.fields ?? []).setFooter({ text: message.eventType }).setTimestamp(message.createdAt)] });
      await db.update(discordLogOutboxTable).set({ sentAt: new Date(), nextAttemptAt: null, attempts: message.attempts + 1, lastError: null }).where(eq(discordLogOutboxTable.id, message.id));
    } catch (error) {
      const attempts = message.attempts + 1;
      const retryAt = new Date(Date.now() + Math.min(60 * 60_000, 30_000 * 2 ** Math.min(attempts, 8)));
      await db.update(discordLogOutboxTable).set({ attempts, lastError: String(error).slice(0, 500), nextAttemptAt: retryAt }).where(eq(discordLogOutboxTable.id, message.id));
    }
  }
}
client.once("ready", async () => {
  const commands = [new SlashCommandBuilder().setName("ticket-panel").setDescription("Publikuje panel zgłoszeń Sleex."), new SlashCommandBuilder().setName("ticket-status").setDescription("Sprawdza dostępność panelu Sleex.")].map((command) => command.toJSON());
  await new REST({ version: "10" }).setToken(env.DISCORD_BOT_TOKEN).put(Routes.applicationGuildCommands(env.DISCORD_CLIENT_ID, env.DISCORD_GUILD_ID), { body: commands });
  await flushOutbox().catch((error) => console.error("Discord outbox failure", error));
  setInterval(() => void flushOutbox().catch((error) => console.error("Discord outbox failure", error)), 30_000).unref();
  console.info("Sleex Discord bot is ready.");
});
void client.login(env.DISCORD_BOT_TOKEN);