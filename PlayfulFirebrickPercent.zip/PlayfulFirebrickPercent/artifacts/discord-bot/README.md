# Sleex Discord Bot

Set `DISCORD_BOT_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`,
`DISCORD_TICKET_PANEL_CHANNEL_ID`, `DISCORD_ORDER_TICKET_CATEGORY_ID`,
`DISCORD_PROBLEM_TICKET_CATEGORY_ID`, `DISCORD_LOG_CHANNEL_ID`,
`DISCORD_SUPPORT_ROLE_IDS`, `DISCORD_ADMIN_ROLE_IDS` and `PUBLIC_APP_URL`.
Role IDs are comma-separated. The bot intentionally refuses to start while any
of these are absent.

Invite the application with scopes **bot** and **applications.commands**. Grant
only the permissions needed to manage the configured ticket categories:
View Channels, Send Messages, Manage Channels, Manage Roles, Read Message
History, Embed Links and Attach Files. Run `pnpm --filter @workspace/discord-bot
dev`, then use `/ticket-panel` in the configured panel channel. The command is
limited to configured Discord administrator roles (or Discord Administrator).