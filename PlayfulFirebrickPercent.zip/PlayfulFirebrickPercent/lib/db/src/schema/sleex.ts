import {
  boolean,
  integer,
  jsonb,
  index,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable(
  "sleex_users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    role: text("role").notNull().default("customer"),
    banned: boolean("banned").notNull().default(false),
    banReason: text("ban_reason"),
    bannedAt: timestamp("banned_at", { withTimezone: true }),
    unbannedAt: timestamp("unbanned_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ emailUnique: uniqueIndex("sleex_users_email_idx").on(table.email) }),
);

export const otpCodesTable = pgTable("sleex_otp_codes", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  used: boolean("used").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessionsTable = pgTable("sleex_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const servicesTable = pgTable("sleex_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  pricePln: real("price_pln").notNull(),
  imageUrl: text("image_url"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const promotionsTable = pgTable(
  "sleex_promotions",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull(),
    discountPercent: real("discount_percent").notNull(),
    usageLimit: integer("usage_limit").notNull(),
    usedCount: integer("used_count").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ codeUnique: uniqueIndex("sleex_promotions_code_idx").on(table.code) }),
);

export const ordersTable = pgTable("sleex_orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  serviceId: integer("service_id").notNull(),
  trackingId: text("tracking_id").notNull().default(sql`upper(substr(md5(random()::text || clock_timestamp()::text), 1, 16))`),
  customerPhone: text("customer_phone").notNull().default("nie podano — zamówienie historyczne"),
  paymentMethod: text("payment_method").notNull().default("BLIK"),
  ramGb: integer("ram_gb").notNull().default(1),
  laptopAgeYears: integer("laptop_age_years").notNull().default(0),
  damageDescription: text("damage_description").notNull().default("Brak opisu uszkodzenia — zamówienie zostało złożone przed rozszerzeniem formularza."),
  incidentDescription: text("incident_description").notNull().default("Brak opisu zdarzenia — zamówienie historyczne."),
  promoCode: text("promo_code"),
  finalPricePln: real("final_price_pln").notNull(),
  status: text("status").notNull().default("new"),
  assignedAdminId: integer("assigned_admin_id"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  claimedAt: timestamp("claimed_at", { withTimezone: true }),
  inProgressAt: timestamp("in_progress_at", { withTimezone: true }),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  rejectedAt: timestamp("rejected_at", { withTimezone: true }),
}, (table) => ({ trackingIdUnique: uniqueIndex("sleex_orders_tracking_id_idx").on(table.trackingId) }));

export const orderEventsTable = pgTable("sleex_order_events", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  actorUserId: integer("actor_user_id"),
  type: text("type").notNull(),
  fromStatus: text("from_status"),
  toStatus: text("to_status"),
  note: text("note"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Files are private until their owner binds them to an order. */
export const orderAttachmentsTable = pgTable(
  "sleex_order_attachments",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id"),
    userId: integer("user_id").notNull(),
    objectPath: text("object_path").notNull(),
    filename: text("filename").notNull(),
    mimeType: text("mime_type").notNull(),
    size: integer("size").notNull(),
    boundAt: timestamp("bound_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    objectPathUnique: uniqueIndex("sleex_order_attachments_object_path_idx").on(table.objectPath),
    orderIndex: index("sleex_order_attachments_order_idx").on(table.orderId),
    ownerUnboundIndex: index("sleex_order_attachments_owner_unbound_idx").on(table.userId, table.boundAt),
  }),
);

export const discordTicketsTable = pgTable(
  "sleex_discord_tickets",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    channelId: text("channel_id").notNull(),
    requesterDiscordId: text("requester_discord_id").notNull(),
    requesterUserId: integer("requester_user_id"),
    kind: text("kind").notNull(),
    category: text("category"),
    status: text("status").notNull().default("open"),
    claimedByDiscordId: text("claimed_by_discord_id"),
    claimedByName: text("claimed_by_name"),
    closedAt: timestamp("closed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => ({
    channelUnique: uniqueIndex("sleex_discord_tickets_channel_idx").on(table.channelId),
    requesterIndex: index("sleex_discord_tickets_requester_idx").on(table.requesterDiscordId),
  }),
);

export const discordTicketEventsTable = pgTable(
  "sleex_discord_ticket_events",
  {
    id: serial("id").primaryKey(),
    ticketId: integer("ticket_id").notNull(),
    actorDiscordId: text("actor_discord_id"),
    type: text("type").notNull(),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ ticketIndex: index("sleex_discord_ticket_events_ticket_idx").on(table.ticketId) }),
);

/** SDK-independent durable delivery queue consumed by the Discord worker. */
export const discordLogOutboxTable = pgTable(
  "sleex_discord_log_outbox",
  {
    id: serial("id").primaryKey(),
    eventType: text("event_type").notNull(),
    payload: jsonb("payload").notNull(),
    text: text("text"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    sentAt: timestamp("sent_at", { withTimezone: true }),
    nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true }),
    attempts: integer("attempts").notNull().default(0),
    lastError: text("last_error"),
  },
  (table) => ({ pendingIndex: index("sleex_discord_log_outbox_pending_idx").on(table.sentAt, table.createdAt) }),
);

export const callsTable = pgTable("sleex_calls", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("scheduled"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  createdByAdminId: integer("created_by_admin_id").notNull(),
  customerOnHold: boolean("customer_on_hold").notNull().default(false),
  adminOnHold: boolean("admin_on_hold").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const callEventsTable = pgTable("sleex_call_events", {
  id: serial("id").primaryKey(),
  callId: integer("call_id").notNull(),
  actorUserId: integer("actor_user_id"),
  type: text("type").notNull(),
  detail: text("detail"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const supportTicketsTable = pgTable("sleex_support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("waiting"),
  adminJoined: boolean("admin_joined").notNull().default(false),
  banned: boolean("banned").notNull().default(false),
  accessTokenHash: text("access_token_hash"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const supportMessagesTable = pgTable("sleex_support_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull(),
  sender: text("sender").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notificationsTable = pgTable("sleex_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  audible: boolean("audible").notNull().default(false),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const emailThreadsTable = pgTable(
  "sleex_email_threads",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id"),
    customerEmail: text("customer_email").notNull(),
    subject: text("subject").notNull(),
    status: text("status").notNull().default("pending"),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({ customerEmailIndex: uniqueIndex("sleex_email_threads_email_subject_idx").on(table.customerEmail, table.subject) }),
);

export const emailMessagesTable = pgTable(
  "sleex_email_messages",
  {
    id: serial("id").primaryKey(),
    threadId: integer("thread_id").notNull(),
    direction: text("direction").notNull(),
    senderEmail: text("sender_email").notNull(),
    recipientEmail: text("recipient_email").notNull(),
    subject: text("subject").notNull(),
    body: text("body").notNull(),
    messageId: text("message_id"),
    inReplyTo: text("in_reply_to"),
    imapUid: integer("imap_uid"),
    sentAt: timestamp("sent_at", { withTimezone: true }).notNull().defaultNow(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    messageIdUnique: uniqueIndex("sleex_email_messages_message_id_idx").on(table.messageId),
    imapUidUnique: uniqueIndex("sleex_email_messages_imap_uid_idx").on(table.imapUid),
  }),
);

export const moderationHistoryTable = pgTable("sleex_moderation_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  adminUserId: integer("admin_user_id"),
  action: text("action").notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertServiceSchema = createInsertSchema(servicesTable).omit({
  id: true,
  createdAt: true,
});
export const insertPromotionSchema = createInsertSchema(promotionsTable).omit({
  id: true,
  createdAt: true,
  usedCount: true,
  active: true,
});
export const insertSupportTicketSchema = createInsertSchema(supportTicketsTable).omit({
  id: true,
  createdAt: true,
});

export type User = typeof usersTable.$inferSelect;
export type Service = typeof servicesTable.$inferSelect;
export type Promotion = typeof promotionsTable.$inferSelect;
export type Order = typeof ordersTable.$inferSelect;
export type OrderEvent = typeof orderEventsTable.$inferSelect;
export type OrderAttachment = typeof orderAttachmentsTable.$inferSelect;
export type DiscordTicket = typeof discordTicketsTable.$inferSelect;
export type DiscordTicketEvent = typeof discordTicketEventsTable.$inferSelect;
export type DiscordLogOutbox = typeof discordLogOutboxTable.$inferSelect;
export type Call = typeof callsTable.$inferSelect;
export type CallEvent = typeof callEventsTable.$inferSelect;
export type SupportTicket = typeof supportTicketsTable.$inferSelect;
export type SupportMessage = typeof supportMessagesTable.$inferSelect;
export type Notification = typeof notificationsTable.$inferSelect;
export type EmailThread = typeof emailThreadsTable.$inferSelect;
export type EmailMessage = typeof emailMessagesTable.$inferSelect;
export type ModerationHistory = typeof moderationHistoryTable.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type InsertPromotion = z.infer<typeof insertPromotionSchema>;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;