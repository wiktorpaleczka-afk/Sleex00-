import { db } from "./index";
import { discordLogOutboxTable } from "./schema";

export type DiscordLogPayload = {
  title: string;
  description?: string;
  fields?: Array<{ name: string; value: string; inline?: boolean }>;
  color?: number;
};

/** Adds a bounded, secret-free operational message for the Discord worker. */
export async function enqueueDiscordLog(
  eventType: string,
  payload: DiscordLogPayload,
  text?: string,
): Promise<void> {
  await db.insert(discordLogOutboxTable).values({
    eventType: eventType.slice(0, 100),
    payload: {
      title: payload.title.slice(0, 256),
      description: payload.description?.slice(0, 4096),
      fields: payload.fields?.slice(0, 25).map((field) => ({
        name: field.name.slice(0, 256),
        value: field.value.slice(0, 1024),
        inline: Boolean(field.inline),
      })),
      color: payload.color,
    },
    text: text?.slice(0, 2000),
  });
}